create procedure       csbg_repair_time(trev in varchar2
												  ,tnow in date
												  ,tres out varchar2) is
	couttime   date;
	crecid     number;
	ccnt       number;
	cprocessid number;
begin
	--檢查SN 是否有Defect
	begin
		select out_process_time, process_id
		into   couttime, cprocessid
		from   sajet.g_sn_status
		where  nvl(current_status, '1') = '1' and work_flag = '0' and serial_number = trev;
	exception
		when others then
			tres := 'SN Not Fail';
			goto endp;
	end;
	--檢查SN 是否已經有刷入收到時間
	select count(*)
	into   ccnt
	from   sajet.g_sn_defect
	where  serial_number = trev and process_id = cprocessid and rec_time >= couttime and receive_time is not null and
		   rownum = 1;
	if ccnt > 0 then
		tres := 'Receive Time already Input !!';
		goto endp;
	end if;
	--檢查是否已有維修紀錄
	select count(*)
	into   ccnt
	from   sajet.g_sn_repair
	where  recid in (select recid
					 from   sajet.g_sn_defect
					 where  serial_number = trev and process_id = cprocessid and rec_time >= couttime);
	if ccnt > 0 then
		tres := 'SN Had Repaired !!';
		goto endp;
	end if;
	update sajet.g_sn_defect
	set    receive_time = tnow
	where  serial_number = trev and process_id = cprocessid and rec_time >= couttime;
	tres := 'OK';
	<<endp>>
	null;
exception
	when others then
		tres := 'CSBG_REPAIR_TIME error';
end;


/

