create procedure        cus_amazon_transfer(tterminalid in varchar2, tsn in varchar2, tdefect in varchar2, tnow in date, temp in varchar2, tres out varchar2, tnextproc out varchar2, tcommand out varchar2) is
begin
	if tdefect = 'N/A' then
		sajet.sj_go(tterminalid, tsn, tnow, tres, temp);
		tnextproc := '';
	else
		sajet.sj_nogo(tterminalid, tsn, tdefect, tnow, tres, tnextproc, temp);
		tnextproc := '';
	end if;
	tcommand := 'CHTSN';
exception
	when others then
		tres      := 'sj_transfer error';
		tnextproc := '';
		tcommand  := 'CHTSN';
end;


/

