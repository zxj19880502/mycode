create trigger TG_ROUTE_SETTING
  before insert or update or delete
  on CSYS_ROUTE_SETTING
  for each row
declare
  -- local variables here
begin
  if updating then
    insert into csys_route_setting_log
    values (:new.route_id,:new.part_id,:new.pdline_id,'Update',:new.update_empid,sysdate);
 /* elsif deleting then
    insert into csys_route_setting_log
    values (:old.route_id,:old.part_id,:old.pdline_id,'Delete',:old.update_empid,sysdate);*/
  elsif inserting then
    insert into csys_route_setting_log
    values (:new.route_id,:new.part_id,:new.pdline_id,'Insert',:new.update_empid,sysdate);
  end if;
end tg_route_setting;


/

