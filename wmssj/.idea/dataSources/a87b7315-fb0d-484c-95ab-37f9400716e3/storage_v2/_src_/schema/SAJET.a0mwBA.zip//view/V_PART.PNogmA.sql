create view V_PART as
select a.part_id, part_no, material_type, part_type, spec1, spec2, upc, ean, route_name, version, a.burnin_time,
       cust_part_no, mfger_part_no, uom, vendor_part_no, sampling_type, a.enabled, e.weight, e.error, label_file,
       rule_set, option1, option2, nvl(customer, option3) option3, option4, option5, option6, option7, option8, option9,
       option10, option11, option12, option13, option14, option15, rohs_flag, special_flag
from   sajet.sys_part a, sajet.sys_route b, sajet.sys_qc_sampling_default c, sajet.sys_qc_sampling_plan d,
       sajet.sys_part_weight e,
       (select customer_id, customer_code || '-' || customer_name customer from sajet.sys_customer) f
where  a.route_id = b.route_id(+) and a.part_id = c.part_id(+) and c.sampling_id = d.sampling_id(+) and
       a.part_id = e.part_id(+) and a.option3 = to_char(f.customer_id(+))
/

