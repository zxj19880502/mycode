create procedure       csbg_assy_ver(trev        in varchar2
											   ,tsn         in varchar2
											   ,tprocessid  in varchar2
											   ,tterminalid in varchar2
											   ,tnow        in date
											   ,temp        in varchar2
											   ,u_partid    in varchar2
											   ,u_partsn    in varchar2
											   ,tres        out varchar2) is
	c_kpver      sajet.g_wo_bom.version%type;
	v_partid     sajet.g_wo_bom.part_id%type;
	v_work_order sajet.g_sn_status.work_order%type;
begin
	select work_order, part_id
	into   v_work_order, v_partid
	from   sajet.g_sn_status
	where  serial_number = tsn and rownum = 1;
	--檢查版本是否正確     
	select version
	into   c_kpver
	from   sajet.g_wo_bom
	where  work_order = v_work_order and part_id = v_partid and item_part_id = u_partid and process_id = tprocessid;
	tres := 'OK';
	if c_kpver <> trev then
		tres := 'VER ERR';
	end if;
	if tres = 'OK' then
		sajet.sj_go(tterminalid, tsn, tnow, tres, temp);
	end if;
	if tres = 'OK' then
		sajet.sj_assy_insert_r108_1(u_partsn, temp, tsn, tprocessid, u_partid, tnow, tterminalid, tres);
	end if;
	if tres <> 'OK' then
		rollback;
	else
		commit;
	end if;
exception
	when others then
		tres := 'CSBG_ASSY_VER ERR';
		rollback;
end;


/

