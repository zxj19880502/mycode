create PROCEDURE       BITLAND_CHK_COA(TCOANO in varchar2,TRES out varchar2)IS
ssn sajet.g_sn_coa.serial_number%type;
curstatus sajet.g_sn_coa.status%type;
BEGIN
  TRES:='OK';
  ssn:=null;

  if TCOANO is null then
    TRES:='Coa No is null';
    return;
  end if;
   select sc.serial_number,sc.status into ssn,curstatus from sajet.g_sn_coa sc where sc.coa_no=TCOANO;

   if ssn is not null then--？？？？coa no
       TRES:='This coa no('||TCOANO||') has been used';
   elsif curstatus!=0 then --？？？？？？
       TRES:='This coa no('||TCOANO||') not in warehouse';
    end if;
exception
  when NO_DATA_FOUND then--？？？？coa no
     TRES:='No this coa no('||TCOANO||')record';
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

