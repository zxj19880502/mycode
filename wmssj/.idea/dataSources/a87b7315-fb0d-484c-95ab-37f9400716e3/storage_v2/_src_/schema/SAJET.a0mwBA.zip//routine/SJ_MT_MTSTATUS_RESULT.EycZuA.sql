create function       
       SJ_MT_MTStatus_Result(svalue in varchar2) return varchar2 is
str varchar2(16);
begin
  if svalue = '0' then
    str := 'Prepare';  --？？
  elsif svalue = '1' then
    str := 'Start';    --？？
  elsif svalue = '2' then
    str := 'Submit';   --？？
  elsif svalue = '3' then
    str := 'Reject';   --？？
  elsif svalue = '4' then
    str := 'Approve';  --？？
  else
    str := 'N/A';
  end if;

  return str;
end;


/

