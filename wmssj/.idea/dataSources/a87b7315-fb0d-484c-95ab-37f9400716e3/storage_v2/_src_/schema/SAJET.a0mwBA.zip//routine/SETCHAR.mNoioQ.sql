create function SetChar(i_num in number) return varchar2 is
  v_format varchar2(20);
  v_idx    number;
begin
  v_idx    := 0;
  v_format := 'fm999990.99999';
  select instr(to_char(i_num), '.') into v_idx from dual;
  if v_idx = 0 then
    return to_char(i_num);
  else
    return to_char(i_num, v_format);
  end if;
end;


/

