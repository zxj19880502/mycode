create function get_number_10to32(p_num    number
											,p_length number) return varchar2 is
	l_result varchar2(20);
	l_num    number := p_num;
begin
	--P_NUM为十进制数值
	--若LENGTH为负数则返回'0'，若为0则返回实际长度的三十四进制字符串
	--若LENGTH大于0则返回长度为@length的三十四进制字符串（从低位起，位数不够高位补'0'，超过位数则高位被截断）
	l_result := '';

	if l_num <= 0 or p_length < 0 then
		l_result := '';
	else
		while l_num <> 0 loop
			l_result := substr('0123456789ABCEFGHIJKLMNOSTUVWXYZ', mod(l_num, 32) + 1, 1) || l_result;
			l_num    := trunc(l_num / 32);
		end loop;
		if (length(l_result) < p_length) then
			l_result := lpad(l_result, p_length, 0);
		else
			l_result := substr(l_result, -p_length, p_length);
		end if;
	end if;
	return l_result;
end ;


/

