create procedure       csbg_sn_replace(tres out varchar2) is
	cursor sn_cursor is
		select serial_number, nvl(customer_sn, 'N/A') customer_sn
		from   sajet.g_sn_status
		where  out_pdline_time is not null and serial_number <> nvl(customer_sn, 'N/A');
	sn_record     sn_cursor%rowtype;
	c_customer_sn sajet.g_sn_status.customer_sn%type;
	c_sn          sajet.g_sn_status.serial_number%type;
	sno           varchar2(5);
begin
	sno := '0';
	--SN 產出後把CUSTOMER SN 替代掉SN
	--沒有CUSTOMER SN 的序號直接刪除記錄
	for sn_record in sn_cursor loop
		c_customer_sn := sn_record.customer_sn;
		c_sn          := sn_record.serial_number;
		if sn_record.customer_sn = 'N/A' then
			sno := '1';
			--G_QC_SN
			delete sajet.g_qc_sn where serial_number = c_sn;
			sno := '2';
			--G_QC_SN_DEFECT
			delete sajet.g_qc_sn_defect where serial_number = c_sn;
			sno := '3';
			--G_REWORK_LOG
			delete sajet.g_rework_log where serial_number = c_sn;
			sno := '4';
			--G_SHIPPING_SN
			delete sajet.g_shipping_sn where serial_number = c_sn;
			sno := '5';
			--G_SN_DEFECT
			delete sajet.g_sn_defect where serial_number = c_sn;
			sno := '6';
			--G_SN_KEYPARTS
			delete sajet.g_sn_keyparts where serial_number = c_sn;
			sno := '7';
			--G_SN_REPAIR
			delete sajet.g_sn_repair where serial_number = c_sn;
			sno := '8';
			--G_SN_REPAIR_REPLACE_KP
			delete sajet.g_sn_repair_replace_kp where serial_number = c_sn;
			sno := '9';
			--G_SN_TOOLING
			delete sajet.g_sn_tooling where serial_number = c_sn;
			sno := '10';
			--G_SN_TRAVEL
			delete sajet.g_sn_travel where serial_number = c_sn;
			sno := '11';
			--G_SPC
			delete sajet.g_spc where serial_number = c_sn;
			sno := '12';
			--G_SN_STATUS
			delete sajet.g_sn_status where serial_number = c_sn;
			commit;
		else
			sno := '13';
			--G_QC_SN
			update sajet.g_qc_sn set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '14';
			--G_QC_SN_DEFECT
			update sajet.g_qc_sn_defect set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '15';
			--G_REWORK_LOG
			update sajet.g_rework_log set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '16';
			--G_SHIPPING_SN
			update sajet.g_shipping_sn set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '17';
			--G_SN_DEFECT
			update sajet.g_sn_defect set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '18';
			--G_SN_KEYPARTS
			update sajet.g_sn_keyparts set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '19';
			--G_SN_REPAIR
			update sajet.g_sn_repair set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '20';
			--G_SN_REPAIR_REPLACE_KP
			update sajet.g_sn_repair_replace_kp set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '21';
			--G_SN_TOOLING
			update sajet.g_sn_tooling set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '22';
			--G_SN_TRAVEL
			update sajet.g_sn_travel set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '23';
			--G_SPC
			update sajet.g_spc set serial_number = c_customer_sn where serial_number = c_sn;
			sno := '24';
			--G_SN_STATUS
			update sajet.g_sn_status set serial_number = c_customer_sn where serial_number = c_sn;
			commit;
		end if;
	end loop;
	tres := 'OK';
exception
	when others then
		tres := 'SN_REPLACE ERR(' || sno || '):' || 'SN:' || c_sn || ';CSN:' || c_customer_sn || '(' || sqlerrm || ')';
		rollback;
end;


/

