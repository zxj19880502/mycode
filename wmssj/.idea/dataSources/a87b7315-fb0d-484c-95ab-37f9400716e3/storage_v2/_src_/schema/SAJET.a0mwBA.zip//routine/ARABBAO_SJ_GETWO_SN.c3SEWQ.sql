create procedure arabbao_sj_getwo_sn(trev in varchar2
													 ,tres out varchar2) is
	wo   varchar2(20);
	v_sn varchar2(100);
begin
	select nvl((select s.serial_number from sajet.g_sn_status s where s.serial_number = trev or s.customer_sn = trev),
				'')
	into   v_sn
	from   dual;
	select work_order into wo from sajet.g_sn_status where serial_number = v_sn;
	tres := wo;
exception
	when others then
		tres := '0:SN ERR';
end;


/

