create view VV_REWORK as
select a.sizespec,to_char(a.WIP_OUT_TIME-8.5/24,'yyyy-mm-dd') times
from sajet.base_sn_travel a,sajet.g_wo_base b
where a.process_id='100026' and a.WORK_ORDER=b.work_order and b.wo_type in ('正常工单','内返工单') and
a.current_status=4


/

