create view V_NG_BASE as
select a.wip_out_time,a.serial_number,a.sizespec
from sajet.base_sn_travel a where
a.work_flag = 1
and a.process_id=100026


/

