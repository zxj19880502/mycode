create trigger TG_CUS_MAC_ALLOCATION
  before insert
  on CUS_MAC_ALLOCATION
  for each row
declare
	-- local variables here
begin
	select sys_guid() into :new.keyid from dual;
end tg_cus_mac_allocation;


/

