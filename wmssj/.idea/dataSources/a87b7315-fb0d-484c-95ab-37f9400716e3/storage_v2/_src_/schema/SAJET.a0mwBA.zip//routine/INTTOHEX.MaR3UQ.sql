create FUNCTION       inttohex(v_hex number) return varchar2
is
hex varchar2(12);
stemp varchar2(16);
num1 number;
num2 number;
num3 number;
len number;
begin
   stemp := '0123456789ABCDEF';
   hex := '';
   num1 := trunc(v_hex/16);
   num2 := v_hex-(num1*16);
   num3 := num1;
   if ( num2 >= 0 and num2 <= 9 ) then
   hex := to_char(num2)||hex;
   end if;
   if num2 = 10 then hex := 'A'||hex; end if;
   if num2 = 11 then hex := 'B'||hex; end if;
   if num2 = 12 then hex := 'C'||hex; end if;
   if num2 = 13 then hex := 'D'||hex; end if;
   if num2 = 14 then hex := 'E'||hex; end if;
   if num2 = 15 then hex := 'F'||hex; end if;
   while (num3 > 0) loop
      num1 := trunc(num3/16);
      num2 := num3-(num1*16);
      if ( num2 >= 0 and num2 <= 9 ) then
      hex := to_char(num2)||hex;
      end if;
      if num2 = 10 then hex := 'A'||hex; end if;
      if num2 = 11 then hex := 'B'||hex; end if;
      if num2 = 12 then hex := 'C'||hex; end if;
      if num2 = 13 then hex := 'D'||hex; end if;
      if num2 = 14 then hex := 'E'||hex; end if;
      if num2 = 15 then hex := 'F'||hex; end if;
      num3 := num1;
   end loop;
   hex := lpad(hex,12,'0');
   return hex;
end;


/

