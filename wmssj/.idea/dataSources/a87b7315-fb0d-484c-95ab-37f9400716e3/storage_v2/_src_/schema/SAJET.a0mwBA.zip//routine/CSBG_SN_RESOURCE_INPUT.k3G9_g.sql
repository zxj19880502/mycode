create procedure       csbg_sn_resource_input(two         varchar2
														,tsn         varchar2
														,tprocessid  number
														,tterminalid number
														,tttesterid  number
														,tmachineid  number
														,tmoldid     number
														,tslot       varchar2
														,tnow        date
														,tempid      number
														,tqty        in number
														,tres        out varchar2) is
	c_maxcnt  number;
	c_usedcnt number;
begin
	tres := 'OK';
	--檢查Machine次數
	if tmachineid <> 0 then
		begin
			select nvl(max_used_count, 0), used_count
			into   c_maxcnt, c_usedcnt
			from   sajet.sys_machine
			where  machine_id = tmachineid and enabled = 'Y' and rownum = 1;
			if (c_maxcnt > 0) and (c_usedcnt + tqty > c_maxcnt) then
				tres := 'MACHINE OVER USED COUNT';
			else
				update sajet.sys_machine set used_count = used_count + tqty where machine_id = tmachineid;
			end if;
		exception
			when others then
				tres := 'MACHINE ERROR';
		end;
	end if;
	--檢查Mold次數
	if (tres = 'OK') and (tmoldid <> 0) then
		begin
			select nvl(max_used_count, 0), used_count
			into   c_maxcnt, c_usedcnt
			from   sajet.sys_mold
			where  mold_id = tmoldid and enabled = 'Y' and rownum = 1;
			if (c_maxcnt > 0) and (c_usedcnt + tqty > c_maxcnt) then
				tres := 'MOLD OVER USED COUNT';
			else
				update sajet.sys_mold set used_count = used_count + tqty where mold_id = tmoldid;
			end if;
		exception
			when others then
				tres := 'MOLD ERROR';
		end;
	end if;
	if tres = 'OK' then
		insert into sajet.g_sn_resource
			(work_order, serial_number, process_id, terminal_id, tester_id, machine_id, mold_id, slot, update_time,
			 update_userid)
		values
			(two, tsn, tprocessid, tterminalid, tttesterid, tmachineid, tmoldid, tslot, tnow, tempid);
	end if;
	if tres = 'OK' then
		commit;
	else
		rollback;
	end if;
exception
	when others then
		tres := 'CSBG_SN_RESRC_INPUT ERR';
		rollback;
end;


/

