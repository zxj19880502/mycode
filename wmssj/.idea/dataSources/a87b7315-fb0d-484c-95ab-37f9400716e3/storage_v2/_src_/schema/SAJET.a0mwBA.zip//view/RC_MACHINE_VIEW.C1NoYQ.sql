create view RC_MACHINE_VIEW as
select rc_no,process_name,to_char(wm_concat(machine_code)
                       over(partition by rc_no,
                            process_name order by machine_code)) r
          from (select distinct a.rc_no, b.machine_code, d.process_name
                  from sajet.g_rc_travel_machine    a,
                       sajet.sys_machine            b,
                       sajet.sys_rc_process_machine c,
                       sajet.sys_process            d
                 WHERE a.MACHINE_ID = b.MACHINE_ID(+)
                   and a.machine_id = c.machine_id
                   and c.process_id = d.process_id
                   )


/

