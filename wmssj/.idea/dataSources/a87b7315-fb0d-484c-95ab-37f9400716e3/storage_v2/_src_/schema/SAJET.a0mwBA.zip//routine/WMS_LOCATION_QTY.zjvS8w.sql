create FUNCTION       Wms_Location_Qty(TPART     IN NUMBER,
                                            TLOCATION IN NUMBER,
                                            TDATECODE IN VARCHAR2,
                                            C_FLAG    IN VARCHAR2,
                                            TPARAM    IN VARCHAR2)
  RETURN STRING IS
  STR   VARCHAR2(100);
  C_SQL VARCHAR2(1000);
  TYPE CV_TYPE IS REF CURSOR;
  CV CV_TYPE;
BEGIN
  C_SQL := 'SELECT SUM(BOX_QTY)' ||
           'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
           'WHERE A.LOCATION_ID = :TLOCATION AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' ||
           'AND PART_ID = :TPART ' ||
           'AND B.OPERATION_TYPE = :OPERATION_TYPE ' ||
           'AND DATECODE = :TDATECODE ' || C_FLAG ;

  OPEN CV FOR C_SQL
    USING TLOCATION, TPART, TPARAM, TDATECODE;

  LOOP
    FETCH CV
      INTO STR;
    EXIT WHEN STR IS NOT NULL;
  END LOOP;
  RETURN STR;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'e';
END;


/

