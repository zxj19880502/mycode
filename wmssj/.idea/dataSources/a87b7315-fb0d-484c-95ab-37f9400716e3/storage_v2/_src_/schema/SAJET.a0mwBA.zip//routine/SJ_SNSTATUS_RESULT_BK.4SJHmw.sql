create function 
             SJ_SNStatus_Result_bk(svalue in varchar2) return varchar2 is
str varchar2(100); s number; i number;
begin
  if svalue = '0' then
    str := 'Queue';
  elsif svalue = '1' then
    str := 'Runnung';
  elsif svalue = '2' then
    str := 'Hold';
  elsif svalue = '7' then
    str := 'merge';
  elsif svalue = '8' then
    str := 'Scrap';
  elsif svalue = '9' then
    str := 'Finish';	    	
  else
    str := '';
  end if;
  return str;
end;


/

