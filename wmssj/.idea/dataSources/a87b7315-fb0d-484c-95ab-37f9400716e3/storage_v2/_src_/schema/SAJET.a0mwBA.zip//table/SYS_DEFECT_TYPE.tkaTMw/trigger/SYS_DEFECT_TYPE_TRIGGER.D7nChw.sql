create trigger SYS_DEFECT_TYPE_TRIGGER
  after insert or update or delete
  on SYS_DEFECT_TYPE
  for each row
declare
    ncount number;
begin
    if inserting then
        insert into sajet.g_tri_data
            (data_id, data_table, update_user, update_time)
        values
            (:new.DEFECT_TYPE_ID, 'SAJET.SYS_DEFECT_TYPE', :new.update_userid, sysdate);

    end if;

exception
    when others then
        insert into sajet.g_tri_log
            (table_name, param1, param2, param3, clog, row_id, update_time)
        values
            ('sajet.SYS_DEFECT_TYPE', 'DEFECT_TYPE_ID', :new.DEFECT_TYPE_ID, null, 'SYS_DEFECT_trigger error', null, sysdate);

end;

/

