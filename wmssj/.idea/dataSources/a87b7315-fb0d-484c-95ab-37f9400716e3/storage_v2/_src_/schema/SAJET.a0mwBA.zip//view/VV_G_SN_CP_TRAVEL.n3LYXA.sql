create view VV_G_SN_CP_TRAVEL as
select to_char(a.out_process_time-8.5/24,'yyyy-mm-dd') times,a.SERIAL_NUMBER,max(a.out_process_time) out_process_time from
sajet.g_sn_travel a
where a.process_id=100026
group by to_char(a.out_process_time-8.5/24,'yyyy-mm-dd'),a.SERIAL_NUMBER


/

