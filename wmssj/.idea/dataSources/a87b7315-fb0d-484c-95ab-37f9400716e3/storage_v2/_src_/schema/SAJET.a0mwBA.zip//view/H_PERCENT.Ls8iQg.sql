create view H_PERCENT as
select shiftid,lv from (
select m.shift shiftid,
       to_char(round(nvl(m.okqty, 0) / (nvl(n.ngqty, 0) + nvl(m.okqty, 0)), 4) * 100) lv
  from (select sum(h.ok_qty) okqty,
               sajet.worksshifet_param(g.out_process_time) shift
          from sajet.g_rc_travel g,
               ( --混料sn及其分料重量和
                select c.rc_no sn, sum(c.merge_rc_qty) ok_qty
                  from sajet.g_rc_merge c,
                        ( --分料及其ok坩埚重量
                         select b.rc_no, b.merge_rc_qty
                           from sajet.g_sn_travel a, sajet.g_rc_merge b
                          where a.process_id = '100026'
                            and a.work_flag = 0
                            and a.current_status in ('0', '2')
                            and to_char(a.out_process_time, 'yyyy-mm-dd') =
                                to_char(sysdate, 'yyyy-mm-dd')
                            and b.process_id = '100011'
                            and b.merge_rc_no = a.serial_number
                            and b.rc_no not in
                                (select rc_no
                                   from sajet.g_rc_travel
                                  where process_id = 100007)) d
                 where d.rc_no = c.merge_rc_no
                 group by c.rc_no
                union all
                --直接混料
                select e.merge_rc_no sn, sum(e.merge_rc_qty) ok_qty
                  from sajet.g_rc_merge e,
                        ( --混料及其坩埚重量
                         select b.rc_no, b.merge_rc_qty
                           from sajet.g_sn_travel a, sajet.g_rc_merge b
                          where a.process_id = '100026'
                            and a.work_flag = 0
                            and a.current_status in ('0', '2')
                            and to_char(a.out_process_time, 'yyyy-mm-dd') =
                                to_char(sysdate, 'yyyy-mm-dd')
                            and b.process_id = '100011'
                            and b.merge_rc_no = a.serial_number
                            and b.rc_no in
                                (select rc_no
                                   from sajet.g_rc_travel
                                  where process_id = 100007)) f
                 where e.merge_rc_no = f.rc_no
                 group by e.merge_rc_no) h
         where g.rc_no = h.sn
           and g.process_id = 100007
         group by sajet.worksshifet_param(g.out_process_time)) m,
       ( --终检、制成检NG
        select sum(h.ng_qty) ngqty,
                sajet.worksshifet_param(g.out_process_time) shift
          from sajet.g_rc_travel g,
                (select c.rc_no sn, sum(c.merge_rc_qty) ng_qty
                   from sajet.g_rc_merge c,
                        ( --分料
                         select b.rc_no
                           from sajet.g_sn_travel a, sajet.g_rc_merge b
                          where a.work_flag = 1
                            and to_char(a.out_process_time, 'yyyy-mm-dd') =
                                to_char(sysdate, 'yyyy-mm-dd')
                            and b.process_id = '100011'
                            and b.merge_rc_no = a.serial_number
                            and b.rc_no not in
                                (select rc_no
                                   from sajet.g_rc_travel
                                  where process_id = 100007)) d
                  where d.rc_no = c.merge_rc_no
                  group by c.rc_no
                 union all
                 --直接混料
                 select e.merge_rc_no sn, sum(e.merge_rc_qty) ng_qty
                   from sajet.g_rc_merge e,
                        ( --混料
                         select b.rc_no
                           from sajet.g_sn_travel a, sajet.g_rc_merge b
                          where a.work_flag = 1
                            and to_char(a.out_process_time, 'yyyy-mm-dd') =
                                to_char(sysdate, 'yyyy-mm-dd')
                            and b.process_id = '100011'
                            and b.merge_rc_no = a.serial_number
                            and b.rc_no in
                                (select rc_no
                                   from sajet.g_rc_travel
                                  where process_id = 100007)) f
                  where e.merge_rc_no = f.rc_no
                  group by e.merge_rc_no) h
         where g.rc_no = h.sn
           and g.process_id = 100007
         group by sajet.worksshifet_param(g.out_process_time)) n
 where m.shift = n.shift(+)

union all
select '制程名称' shiftid,'百分比值' lv from dual)


/

