create function fn_split_t(p_str           in varchar2
									 ,p_delimiter     in varchar2
									 ,p_delimiter_end in varchar2)
--return varchar2 is
 return ty_str_split
	pipelined is
	j   int := 0;
	i   int := 1;
	len int := 0;

	len1 int := 0;
	len2 int := 0;
	str  varchar2(4000);

	aa      int := 0;
	bb      int := 0;
	m       int := 1;
	abegin  int := 0;
	bend    int := 0;
	lastend int := 0;
	onestr  varchar2(5);

	temp varchar2(4000);
begin
	len  := length(p_str);
	len1 := length(p_delimiter);
	len2 := length(p_delimiter_end);
	while m <= len loop
		onestr := substr(p_str, m, len1);
		if onestr = p_delimiter then
			if aa = 0 then
				if lastend <> m and m <> 1 then
					str := substr(p_str, lastend, m - lastend);
					pipe row(str);
				end if;
				abegin := m;
			end if;
			aa := aa + 1;
		end if;
		--(a*b)&&(b*c)||((a1*b1)||(b1*c1))
		onestr := substr(p_str, m, len2);
		if onestr = p_delimiter_end then
			bb := bb + 1;
		end if;
	
		if aa = bb and aa <> 0 then
			str := substr(p_str, abegin, m - abegin + 1);
			pipe row(str);
			--temp := temp || ',' || str;
			aa      := 0;
			bb      := 0;
			lastend := m + 1;
		end if;
		m := m + 1;
	end loop;
	--return temp;
	return;
end;


/

