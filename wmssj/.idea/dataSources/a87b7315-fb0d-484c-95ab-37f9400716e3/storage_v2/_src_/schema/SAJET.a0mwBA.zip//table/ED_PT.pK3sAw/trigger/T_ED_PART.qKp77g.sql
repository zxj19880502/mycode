create trigger T_ED_PART
  before insert
  on ED_PT
  for each row
DECLARE
  C_PARTID NUMBER;
  C_PARTNO VARCHAR2(50);
  C_DATE   VARCHAR2(50);
BEGIN
  :NEW.LOG := 'OK';
  BEGIN
    SELECT TO_CHAR(UPDATE_TIME, 'yyyy/mm/dd')
      INTO C_DATE
      FROM SAJET.SYS_PART
     WHERE PART_NO = :NEW.PT_PART;
    BEGIN
      IF C_DATE <> :NEW.PT_UPDATETIME THEN
        UPDATE SAJET.SYS_PART
           SET SPEC1       = :NEW.PT_SPEC1,
               SPEC2       = :NEW.PT_SPEC2,
               PART_TYPE   = :NEW.PT_TYPE,
               UOM         = :NEW.PT_UNIT,
               UPDATE_TIME = TO_DATE(:NEW.PT_UPDATETIME, 'yyyy/mm/dd')
         WHERE PART_NO = :NEW.PT_PART;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        :NEW.LOG := SQLERRM;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        SELECT NVL(MAX(PART_ID), 10000000) + 1
          INTO C_PARTID
          FROM SAJET.SYS_PART;
      
        INSERT INTO SAJET.SYS_PART
          (PART_ID, PART_NO, SPEC1, SPEC2, PART_TYPE, UOM, UPDATE_TIME)
        VALUES
          (C_PARTID,
           :NEW.PT_PART,
           :NEW.PT_SPEC1,
           :NEW.PT_SPEC2,
           :NEW.PT_TYPE,
           :NEW.PT_UNIT,
           TO_DATE(:NEW.PT_UPDATETIME, 'yyyy/mm/dd'));
      EXCEPTION
        WHEN OTHERS THEN
          :NEW.LOG := SQLERRM;
          RETURN;
      END;
  END;
EXCEPTION
  WHEN OTHERS THEN
    :NEW.LOG := SQLERRM;
END;


/

