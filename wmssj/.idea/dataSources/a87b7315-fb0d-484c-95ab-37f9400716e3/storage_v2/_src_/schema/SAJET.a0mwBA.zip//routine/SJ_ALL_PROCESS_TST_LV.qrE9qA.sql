create FUNCTION sj_all_process_tst_lv(flag in VARCHAR2,size_spec in VARCHAR2,times_date in VARCHAR2) return Varchar2 IS

v_day_lv                   VARCHAR2(50);
v_month_lv                   VARCHAR2(50);
v_shift_name                   VARCHAR2(50);
v_qty                   NUMBER(38);
v_qty1                   NUMBER(38);
v_qty2                   NUMBER(38);

begin
--1 当天，2当月
  if flag='1' then

  select t.lv
  into v_day_lv
  from
  (
  select times,sizespec,to_char(round(nvl(qty1,0)/sum_qty,4)*100) lv from
  (select nvl(x.times,y.times) times,nvl(x.sizespec,y.sizespec) sizespec,x.qty1,y.ng_qty,
  (nvl(x.qty1,0)+nvl(y.ng_qty,0)) sum_qty from
  (select to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') times,a.sizespec,count(1) qty1 from
   sajet.base_sn_travel a,sajet.g_wo_base b,
  (select m.SERIAL_NUMBER,m.WIP_OUT_TIME from
  (select max(a.WIP_OUT_TIME) WIP_OUT_TIME,a.SERIAL_NUMBER from
   sajet.base_sn_travel a
   where a.PROCESS_ID='100026' and a.CURRENT_STATUS in (0,2)
   and to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') =times_date
   group by a.SERIAL_NUMBER)m,
   sajet.g_sn_status a
   where m.SERIAL_NUMBER=a.SERIAL_NUMBER and a.CURRENT_STATUS in (0,2))m
   where a.SERIAL_NUMBER=m.SERIAL_NUMBER and a.WIP_OUT_TIME=m.WIP_OUT_TIME and a.PROCESS_ID='100026'
   and a.WORK_ORDER=b.work_order and b.wo_type ='实验工单'
   group by to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd'),a.sizespec)x
   full outer join
  (select nvl(y.times,z.times) times,nvl(y.sizespec,z.sizespec) sizespec,
  (nvl(y.qty2,0)+nvl(z.qty3,0)) ng_qty from
  (select to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') times,a.sizespec,count(1) qty2 from
  sajet.base_sn_travel a,sajet.g_wo_base b,
  (select max(a.WIP_OUT_TIME) WIP_OUT_TIME,a.SERIAL_NUMBER from
  sajet.base_sn_travel a
  where a.PROCESS_ID='100026' and a.CURRENT_STATUS in (1)
  and to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') =times_date
  group by a.SERIAL_NUMBER)m
  where a.SERIAL_NUMBER=m.SERIAL_NUMBER and a.WIP_OUT_TIME=m.WIP_OUT_TIME and a.PROCESS_ID='100026'
  and a.WORK_ORDER=b.work_order and b.wo_type ='实验工单'
  group by to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd'),a.sizespec)y
  full outer join
  (select to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') times,a.sizespec,count(1) qty3 from
  sajet.base_sn_travel a,sajet.g_wo_base b
  where a.PROCESS_ID in (100012,100013,100014,100015,100016,100017,100031,100018,100019,100020,100022,100023,100029,100024)
  and a.CURRENT_STATUS=1 and a.WORK_FLAG=1 and a.WORK_ORDER=b.work_order and b.wo_type ='实验工单'
  and to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') =times_date
  group by to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd'),a.sizespec)z
  on y.times=z.times and y.sizespec=z.sizespec)y
  on x.times=y.times and x.sizespec=y.sizespec)
  )t
  where t.sizespec=size_spec;

  return v_day_lv;
  end if;

  if flag='2' then

  select t.lv
  into  v_month_lv
  from
  (
  select '月合计' 月合计,sizespec,to_char(round(nvl(qty1,0)/sum_qty,4)*100) lv from
  (select nvl(x.sizespec,y.sizespec) sizespec,x.qty1,y.ng_qty,
  (nvl(x.qty1,0)+nvl(y.ng_qty,0)) sum_qty from
  (select m.sizespec,sum(m.qty1) qty1 from
  (select to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') times,a.sizespec,count(1) qty1 from
  sajet.base_sn_travel a,sajet.g_wo_base b,
  (select m.SERIAL_NUMBER,m.WIP_OUT_TIME from
  (select max(a.WIP_OUT_TIME) WIP_OUT_TIME,a.SERIAL_NUMBER from
  sajet.base_sn_travel a
  where a.PROCESS_ID='100026' and a.CURRENT_STATUS in (0,2)
  and to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm') =times_date
  group by a.SERIAL_NUMBER)m,
  sajet.g_sn_status a
  where m.SERIAL_NUMBER=a.SERIAL_NUMBER and a.CURRENT_STATUS in (0,2))m
  where a.SERIAL_NUMBER=m.SERIAL_NUMBER and a.WIP_OUT_TIME=m.WIP_OUT_TIME and a.PROCESS_ID='100026'
  and a.WORK_ORDER=b.work_order and b.wo_type ='实验工单'
  group by to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd'),a.sizespec)m
  group by m.sizespec)x
  full outer join
  (select n.sizespec,sum(n.ng_qty) ng_qty from
  (select nvl(y.times,z.times) times,nvl(y.sizespec,z.sizespec) sizespec,
  (nvl(y.qty2,0)+nvl(z.qty3,0)) ng_qty from
  (select to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') times,a.sizespec,count(1) qty2 from
  sajet.base_sn_travel a,sajet.g_wo_base b,
  (select max(a.WIP_OUT_TIME) WIP_OUT_TIME,a.SERIAL_NUMBER from
  sajet.base_sn_travel a
  where a.PROCESS_ID='100026' and a.CURRENT_STATUS in (1)
  and to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm') =times_date
  group by a.SERIAL_NUMBER)m
  where a.SERIAL_NUMBER=m.SERIAL_NUMBER and a.WIP_OUT_TIME=m.WIP_OUT_TIME and a.PROCESS_ID='100026'
  and a.WORK_ORDER=b.work_order and b.wo_type ='实验工单'
  group by to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd'),a.sizespec)y
  full outer join
  (select to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd') times,a.sizespec,count(1) qty3 from
  sajet.base_sn_travel a,sajet.g_wo_base b
  where a.PROCESS_ID in (100012,100013,100014,100015,100016,100017,100031,100018,100019,100020,100022,100023,100029,100024)
  and a.CURRENT_STATUS=1 and a.WORK_FLAG=1 and a.WORK_ORDER=b.work_order and b.wo_type ='实验工单'
  and to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm') =times_date
  group by to_char(a.WIP_OUT_TIME - 8.5/24, 'yyyy-mm-dd'),a.sizespec)z
  on y.times=z.times and y.sizespec=z.sizespec)n
  group by n.sizespec)y
  on x.sizespec=y.sizespec)
  )t
  where t.sizespec=size_spec;

  return v_month_lv;
  end if;

EXCEPTION
WHEN OTHERS THEN
RETURN '0';

end ;


/

