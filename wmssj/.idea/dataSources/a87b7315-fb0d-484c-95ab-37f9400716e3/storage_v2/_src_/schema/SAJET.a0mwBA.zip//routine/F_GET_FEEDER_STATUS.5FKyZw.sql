create function f_get_feeder_status(cfeeder_status in varchar2) return varchar2 is
	result varchar2(50);
begin
	--'I', '入库 ','P','领用 ','U','上线','D','下线','R','维修','M','保养'
	if cfeeder_status = 'I' then
		result := '入库';
	elsif cfeeder_status = 'P' then
		result := '领用';
	elsif cfeeder_status = 'U' then
		result := '上线';
	elsif cfeeder_status = 'D' then
		result := '下线';
	elsif cfeeder_status = 'R' then
		result := '维修';
	elsif cfeeder_status = 'M' then
		result := '保养';
	else
		result := cfeeder_status;
	end if;
	return(result);
exception
	when others then
		result := '';
		return result;
end;


/

