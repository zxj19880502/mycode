create view BASE_SN_TRAVEL as
select t."WORK_ORDER",
       t."SERIAL_NUMBER",
       t."PART_ID",
       t."VERSION",
       t."ROUTE_ID",
       t."FACTORY_ID",
       t."PDLINE_ID",
       t."STAGE_ID",
       t."NODE_ID",
       t."PROCESS_ID",
       t."SHEET_NAME",
       t."TERMINAL_ID",
       t."TRAVEL_ID",
       t."NEXT_NODE",
       t."NEXT_PROCESS",
       t."CURRENT_STATUS",
       t."GOOD_QTY",
       t."SCRAP_QTY",
       t."IN_PROCESS_EMPID",
       t."IN_PROCESS_TIME",
       t."WIP_IN_EMPID",
       t."WIP_IN_MEMO",
       t."WIP_IN_TIME",
       t."WIP_OUT_EMPID",
       t."WIP_OUT_MEMO",
       t."WIP_OUT_TIME",
       t."OUT_PROCESS_EMPID",
       t."OUT_PROCESS_TIME",
       t."PRIORITY_LEVEL",
       t."UPDATE_USERID",
       t."UPDATE_TIME",
       t."RC_NO",
       t."PRE_SN",
       t."BATCH_ID",
       t."SEQ",
       t."CREATE_TIME",
       t."CASSETTE_NO",
       t."CASSETTE_SEQ",
       t."RP_ROUTE",
       t."OUT_PDLINE_TIME",
       t."IN_PDLINE_TIME",
       t."LASER_NO",
       t."LOT_NO",
       t."CUSTOMER_SN",
       t."CARTON_NO",
       t."PALLET_NO",
       t."BOX_NO",
       t."SHIPPING_ID",
       t."QC_NO",
       t."WORK_FLAG",
       t."REWORK_NO",
       t."QC_RESULT",
       t."CONTAINER",
       t."IN_PROCESS_SHIFT",
       t."OUT_PROCESS_SHIFT",
       case
         when t.out_process_time <
              to_date(to_char(out_process_time, 'yyyy-mm-dd ') || '8:30:00',
                      'yyyy-mm-dd hh24:mi:ss') then
          to_date(TO_CHAR(t.out_process_time, 'yyyy-mm-dd'), 'yyyy-mm-dd') - 1
         else
          to_date(TO_CHAR(t.out_process_time, 'yyyy-mm-dd'), 'yyyy-mm-dd')
       end riqi,
       case
         when t.in_process_time <
              to_date(to_char(t.in_process_time, 'yyyy-mm-dd ') || '8:30:00',
                      'yyyy-mm-dd hh24:mi:ss') then
          to_date(TO_CHAR(t.in_process_time, 'yyyy-mm-dd'), 'yyyy-mm-dd') - 1
         else
          to_date(TO_CHAR(t.in_process_time, 'yyyy-mm-dd'), 'yyyy-mm-dd')
       end input_date,
       case
         when to_date(to_char(out_process_time, 'hh24:mi:ss '), 'hh24:mi:ss') <
              to_date(to_char(out_process_time, 'hh24') || ' :30:00',
                      'hh24:mi:ss') then
          DECODE(to_number(to_char(out_process_time, 'hh24')) - 1,
                 '-1',
                 '23',
                 to_char(abs(to_number(to_char(out_process_time, 'hh24')) - 1),
                         'FM09')) /* */
          || ':30 - ' || to_char(out_process_time, 'hh24') || ':30'

         else
          to_char(out_process_time, 'hh24') || ':30 - ' ||
          decode(to_number(to_char(out_process_time, 'hh24')) + 1,
                 '24',
                 '00',
                 to_char(to_number(to_char(out_process_time, 'hh24')) + 1,
                         'FM09')) || ':30'

       end shiduan,
       c.part_no,
       c.spec1,
       b.model_name,
       substr(b.model_name, 4, 4) sizespec,
       p.process_name,
       substr(B.MODEL_NAME, 1, 2) sepctype
  from sajet.g_sn_travel t,
       sajet.sys_part    c,
       sajet.sys_model   b,
       sajet.sys_process p
 where t.out_process_time is not null
   and c.part_id = t.part_id
   and b.model_id(+) = c.model_id
   and t.process_id = p.process_id(+)


/

