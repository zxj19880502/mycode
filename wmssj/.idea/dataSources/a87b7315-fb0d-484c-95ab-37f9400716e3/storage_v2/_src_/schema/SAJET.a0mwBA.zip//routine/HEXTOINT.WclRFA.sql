create FUNCTION       hextoint(shex in varchar2) return number is
str varchar2(16); s number; i number;
begin
  str := '0123456789ABCDEF';
  s := 0;
  for i in 1..length(shex) loop
    s := s * 16 + instr(str, substr(shex, i, 1), 1, 1) - 1;
  end loop;
  return s;
end;


/

