create trigger T_DN_INFO_NEW
  before insert
  on CUS_SHIPPING_NO_INFO
  for each row
declare
  -- local variables here
  shippingId         number;
begin
  select dn_id into shippingId from g_dn_base a where a.dn_no=ltrim(:new.dn,0);
  select shippingId,ltrim(:new.dn,0) into :new.shipping_id,:new.dn from dual;
end t_dn_info_new;

/

