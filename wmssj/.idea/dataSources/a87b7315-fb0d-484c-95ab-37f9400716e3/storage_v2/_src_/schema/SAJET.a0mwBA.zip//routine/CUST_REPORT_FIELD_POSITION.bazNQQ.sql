create FUNCTION       CUST_REPORT_FIELD_POSITION(svalue in varchar2) return varchar2 is
STR VARCHAR2(25);
BEGIN
  IF SVALUE = '0' THEN
    STR := 'None';
  ELSIF SVALUE = '1' THEN
    STR := 'Right';
  ELSIF SVALUE = '2' THEN
    STR := 'Center';
  ELSIF SVALUE = '3' THEN
    STR := 'Left';
  ELSE
    STR := 'Unknown';
  END IF;
  RETURN STR;
END;


/

