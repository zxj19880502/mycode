create FUNCTION       SJ_f_ReleaseCustody_NO(sWO in varchar2) return varchar2 is
sResult varchar2(50);
C_RWSEQ number;
begin
  select SJ_ReleaseCustody_NO.Nextval into C_RWSEQ from dual;

  sResult:='RC'||to_char(sysdate,'yyyymmdd')||LPAD(C_RWSEQ,5,'0');
  return sResult;
end;


/

