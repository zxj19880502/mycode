create view PRODUCT_DAY_REPORT_V as
select a."QUERY_DATE",a."SIZESPEC",a."PLAN_INPUT",a."浇注_数量",a."浇注_报废数量",a."浇注_返工数量",a."脱模_数量",a."脱模_报废数量",a."脱模_返工数量",a."养护_数量",a."养护_报废数量",a."养护_返工数量",a."喷砂_数量",a."喷砂_报废数量",a."喷砂_返工数量",a."切边_数量",a."切边_报废数量",a."切边_返工数量",a."修坯_数量",a."修坯_报废数量",a."修坯_返工数量",a."半检_数量",a."半检_报废数量",a."半检_返工数量",a."烘干_数量",a."烘干_报废数量",a."烘干_返工数量",a."烧结_数量",a."烧结_报废数量",a."烧结_返工数量",a."质检_数量",a."质检_报废数量",a."质检_返工数量",a."清洗_数量",a."清洗_报废数量",a."清洗_返工数量",a."喷涂_数量",a."喷涂_报废数量",a."喷涂_返工数量",a."终检_数量",a."终检_报废数量",a."终检_返工数量",a."包装_数量",a."包装_报废数量",a."包装_返工数量", b.stock_qty, b.plan_stock,c.shipping_qty
  from (select *
          from (select *
                  from sajet.v_daily_in_scrap_rework
                 where sizespec in ('1044','1200','1060'))
        pivot(max(qty) as 数量, max(scrap_qty) as 报废数量, max(rework_qty) as 返工数量
           for process_name in('浇注' 浇注,'脱模' 脱模,'养护' 养护,'喷砂' 喷砂,
                              '切边' 切边,'修坯' 修坯,'半检' 半检,'烘干' 烘干,
                              '烧结' 烧结,'成品检' 质检,'清洗' 清洗,'喷涂' 喷涂,
                              '出厂检' 终检,'包装' 包装))) a,
       sajet.v_daily_stock b,
       sajet.v_daily_shipping c
 where a.query_date = b.query_date(+)
   and a.query_date = c.query_date(+)
   and a.sizespec = b.sizespec(+)
   and a.sizespec = c.sizespec(+)


/

