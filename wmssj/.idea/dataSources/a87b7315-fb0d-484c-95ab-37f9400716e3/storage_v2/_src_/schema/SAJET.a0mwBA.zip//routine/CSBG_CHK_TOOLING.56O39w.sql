create procedure       csbg_chk_tooling(tsn         in varchar2
												  ,tterminalid in number
												  ,tres        out varchar2
												  ,stoolres    out varchar2) is
	cempid        number;
	c_tool_id     number;
	c_usedcount   number;
	c_max_count   number;
	c_limit_count number;
	c_tooling     varchar2(50);
	swarning      varchar2(50);
	c_toolsnid    number;
	c_toolsn      sajet.sys_tooling_sn.tooling_sn%type;
	cwo           sajet.g_wo_base.work_order%type;
	cursor tool_cursor is
		select tooling_sn_id
		from   sajet.g_tooling_sn_status
		where  (work_order = cwo and terminal_id = tterminalid) or serial_number = tsn;
	tool_record tool_cursor%rowtype;
begin
	select work_order into cwo from sajet.g_sn_status where serial_number = tsn;
	begin
		select tooling_sn_id
		into   c_toolsnid
		from   sajet.g_tooling_sn_status
		where  ((work_order = cwo and terminal_id = tterminalid) or (serial_number = tsn)) and rownum = 1;
	exception
		when others then
			tres := 'NO GET TOOLING';
			goto endp;
	end;
	--Check Tooling Used Count
	stoolres := 'N/A';
	open tool_cursor;
	loop
		fetch tool_cursor
			into tool_record;
		exit when tool_cursor%notfound;
		csbg_chk_tooling_used(tool_record.tooling_sn_id, tres, swarning, c_toolsn);
		if tres <> 'OK' then
			tres := tres || '(' || c_toolsn || ')';
			close tool_cursor;
			goto endp;
		end if;
		--次數達警告限制
		if swarning <> 'N/A' then
			if stoolres = 'N/A' then
				stoolres := swarning || '(' || c_toolsn || ');';
			else
				stoolres := stoolres || swarning || '(' || c_toolsn || ');';
			end if;
		end if;
	end loop;
	close tool_cursor;
	tres := 'OK';
	<<endp>>
	null;
end;


/

