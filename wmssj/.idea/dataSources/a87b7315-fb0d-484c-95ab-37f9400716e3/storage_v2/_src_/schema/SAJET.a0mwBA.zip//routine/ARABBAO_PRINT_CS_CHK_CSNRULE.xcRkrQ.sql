create procedure arabbao_print_cs_chk_csnrule(wo   in varchar2
														,csn  in varchar2
														,tres out varchar2) is
begin
	--tres := 'OK';
	tres := sajet.jackcheckcsnrule(wo, csn);
end;


/

