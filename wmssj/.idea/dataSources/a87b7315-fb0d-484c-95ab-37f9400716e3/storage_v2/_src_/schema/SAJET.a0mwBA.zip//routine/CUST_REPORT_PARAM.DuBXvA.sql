create FUNCTION       CUST_REPORT_PARAM(svalue in varchar2) return varchar2 is
str varchar2(25); s number; i number;
begin
  if svalue = '0' then
    str := 'Empty';
  elsif svalue = '1' then
    str := 'SQL(Single)';
  elsif svalue = '2' then
    str := 'SQL(Multi)';
  elsif svalue = '3' then
    str := 'Fixed';
  elsif svalue = '4' then
    str := 'Unvisible';
  elsif svalue = '5' then
    str := 'Date';
  elsif svalue = '6' then
    str := 'Ref(Single)';
  elsif sValue = '7' then
    str := 'Field';
  elsif sValue = '8' then
    str := 'Week';
  elsif sValue = '9' then
    str := 'Month';
  elsif sValue = '10' then
    str := 'Quarter';
  elsif sValue = '11' then
    str := 'Year';
  elsif sValue = '12' then
    str := 'DateTime';
  elsif sValue = '13' then
    str := 'Input(Multi)';
  else
    str := 'Unknown';
  end if;
  return str;
end;


/

