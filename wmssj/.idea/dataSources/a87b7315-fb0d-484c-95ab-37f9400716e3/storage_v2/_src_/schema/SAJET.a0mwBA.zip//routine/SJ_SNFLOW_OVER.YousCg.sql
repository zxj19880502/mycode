create function sj_snflow_over(csn in varchar2,cCURRENT_STATUS in varchar2 ) return varchar2 is
	str varchar2(100);
	ccount   number;
	i   number;
begin
    str := '';
	if cCURRENT_STATUS = '0' then
		 select count(a.serial_number) into ccount from sajet.g_sn_status a where a.serial_number=csn
         and a.out_pdline_time is not null
         and a.next_process=0;
         if ccount=1 then
           str:='complete';
         else
           str:='';
         end if;

	end if;
	return str;
end;
/

