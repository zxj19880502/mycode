create function       f_cus_formatstr(tparm   in varchar2
												,tlen    in number
												,tchar   in varchar2
												,tisleft in varchar2) return varchar2 is
	tres varchar2(64);
begin
	if length(tparm) >= tlen then
		tres := tparm;
	else
		tres := tparm;
		for i in length(tparm) + 1 .. tlen loop
			if tisleft = 'Y' then
				tres := tchar || tres;
			else
				tres := tres || tchar;
			end if;
		end loop;
	end if;
	return(tres);
end f_cus_formatstr;


/

