create function f_get_dayfep(ctype in varchar2) return number is

	ctime number;


	--根据当前时间，获取白夜班的开始时间
begin
	ctime := to_number(to_char(sysdate, 'hh24'));

	if ctype = 'day' then
		if (ctime > 8) and (ctime < 20) then
			ctime := 1;
		else
			ctime := 0;
		end if;
	end if;


	if ctype = 'night' then
		if (ctime > 8) and (ctime < 20) then
			ctime := 0;
		else
			ctime := 1;
		end if;
	end if;


	<<endp>>
	return ctime;
exception
	when others then
		return 0;
end;
/

