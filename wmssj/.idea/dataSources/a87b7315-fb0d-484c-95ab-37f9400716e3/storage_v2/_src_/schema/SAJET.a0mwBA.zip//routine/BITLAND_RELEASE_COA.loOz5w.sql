create PROCEDURE       BITLAND_RELEASE_COA(TSTART in number,TEND in number,TPARTID in varchar2,TMPART in varchar2,TEMPID in varchar2,TRES out varchar2)IS
sncount number;
--ssn varchar2(30);
--curstatus number;
--empid number;
--startcoa number;
--nextprocess varchar2(30);
BEGIN
  TRES:='OK';
  sncount:=0;
  --ssn:='N/A';
--  curstatus:=-1;
  --nextprocess:='N/A';
  --empid:=0;
  if TSTART is null then
    TRES:='Start COA is null';
    return;
    elsif TSTART=TEND then
    TRES:='Start COA=End COA';
    return;
    elsif TSTART<=0 then
    TRES:='Start COA<=0';
    return;
    elsif TEND<=0 then
    TRES:='End COA<=0';
    return;
    elsif TSTART>TEND then
    TRES:='Start COA>End COA';
    return;
    elsif TPARTID is null then
    TRES:='Part ID Is Null';
    return;
    elsif TMPART is null then
    TRES:='Microsoft Part No is Null';
    return;
  end if;
/*  sajet.Sj_Get_Empid(TEMP,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMP||')';
    return;
  end if;*/
  select count(*) into sncount from sajet.g_sn_coa ss where to_number(ss.coa_no) between TSTART and TEND;
  if sncount>0 then --？？？？sn
    TRES:='There Are '||to_char(sncount)||' COA No Already Exist Between['||lpad(to_char(TSTART),14,'0')||']And['||lpad(to_char(TEND),14,'0')||']';
    return ;
  end if;
   for coa in TSTART..TEND
     loop
       insert into sajet.g_sn_coa(coa_no,part_id,m_part_no,status,update_user_id)values(lpad(to_char(coa),14,'0'),TPARTID,TMPART,0,TEMPID);
        insert into sajet.g_ht_sn_coa(coa_no,part_id,m_part_no,status,update_user_id)values(lpad(to_char(coa),14,'0'),TPARTID,TMPART,0,TEMPID);
    end loop;
    commit;
exception
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

