create procedure       arabbao_pallet_status_check(pallet in varchar2
															 ,tres   out varchar2) is
	cflag varchar2(10);
begin
	tres := 'pallet no close';
	select close_flag into cflag from sajet.g_pack_pallet where pallet_no = pallet and rownum = 1;
	if cflag = 'N' then
		tres := 'pallet is not close';
	elsif cflag = 'Y' then
		tres := 'OK';
	end if;
exception
	when others then
		tres := 'Please Input Correct pallet';
end;


/

