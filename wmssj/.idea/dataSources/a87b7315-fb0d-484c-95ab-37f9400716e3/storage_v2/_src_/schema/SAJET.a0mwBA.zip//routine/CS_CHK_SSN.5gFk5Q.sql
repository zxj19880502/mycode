create procedure       cs_chk_ssn(tlineid     in number
											,tstageid    in number
											,tprocessid  in number
											,tterminalid in number
											,tsn         in varchar2
											,tnow        in date
											,tres        out varchar2
											,tempid      in varchar2
											,trev        in varchar2
											,tdefect     in varchar2) is
	ccount number;
begin
	select count(*) into ccount from sajet.g_sn_ssn_map b where b.shipping_sn = trev and rownum = 1;
	if ccount <> 0 then
		tres := 'DUP SSN';
	else
		select count(*) into ccount from sajet.g_sn_status b where b.customer_sn = trev and rownum = 1;
		if ccount <> 0 then
			select count(*) into ccount from sajet.g_sn_status where serial_number = trev and rownum = 1;
			if ccount <> 0 then
				tres := 'KPS NG';
			else
				tres := 'OK';
			end if;
		end if;
	end if;
exception
	when others then
		tres := 'cs_chk_ssn error';
end;


/

