create procedure       csbg_wip_repair_go(tterminalid in number
													,two         in varchar2
													,tsn         in varchar2
													,tpassqty    in number
													,tfailqty    in number
													,tempid      in number
													,tdefectdata in varchar2
													,tres        out varchar2) is
	-----TERMINAL---------------
	clineid     number;
	cstageid    number;
	cprocessid  number;
	cterminalid number;
	--------------------------------------
	c_model_id        number;
	crouteid          number;
	inflag            boolean;
	outflag           boolean;
	c_out_pdline_time date;
	c_in_pdline_time  date;
	-----------DEFECT--------------
	istart         number;
	iend           number;
	inum           number;
	c_defectid     number;
	c_defectqty    number;
	c_defectcode   sajet.sys_defect.defect_code%type;
	c_sumdefectqty number;
	tnow           date;
begin
	tres := 'OK';
	tnow := sysdate;
	--再次檢查工單的狀態
	sajet.sj_chk_wo_input(two, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	sajet.sj_get_place(tterminalid, clineid, cstageid, cprocessid);
	if tres <> 'OK' then
		goto endp;
	end if;
	select part_id, route_id into c_model_id, crouteid from sajet.g_wo_base where work_order = two and rownum = 1;
	--良品數記102 REPASS QTY
	sajet.csbg_transation_count(clineid, cstageid, cprocessid, tempid, tnow, tsn, two, c_model_id, 0, tpassqty,
								tpassqty, '1', tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	--不良數記102 REFAIL QTY
	sajet.csbg_transation_count(clineid, cstageid, cprocessid, tempid, tnow, tsn, two, c_model_id, 1, tfailqty,
								tpassqty, '1', tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	--============DEFECT=============================================================================
	c_sumdefectqty := 0;
	if (tdefectdata <> 'N/A') then
		begin
			istart := 0;
			iend   := 0;
			loop
				istart := iend + 1;
				iend   := instr(tdefectdata, '@', istart, 1);
				exit when(iend = 0) or tres <> 'OK';
				c_defectid     := substr(tdefectdata, istart, iend - istart);
				istart         := iend + 1;
				iend           := instr(tdefectdata, '@', istart, 1);
				c_defectcode   := substr(tdefectdata, istart, iend - istart);
				istart         := iend + 1;
				iend           := instr(tdefectdata, '@', istart, 1);
				c_defectqty    := substr(tdefectdata, istart, iend - istart);
				c_sumdefectqty := c_sumdefectqty + c_defectqty;
				begin
					sajet.csbg_defect_input(clineid, cstageid, cprocessid, tterminalid, tsn, c_defectcode, tnow, tempid,
											two, c_model_id, c_defectqty);
				exception
					when others then
						tres := 'INSERT SN DEFECT ERROR';
						goto endp;
				end;
			end loop;
		exception
			when others then
				tres := 'GET DEFECT DATA ERROR';
				goto endp;
		end;
	end if;
	--將SCRAP QTY從WIP 中扣除
	sajet.csbg_update_sn(two, c_model_id, crouteid, clineid, cstageid, cprocessid, tterminalid, tsn, '0', tnow, tempid,
						 -tfailqty, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	insert into sajet.g_sn_travel
		(work_order, serial_number, part_id, version, route_id, pdline_id, stage_id, process_id, terminal_id,
		 next_process, current_status, work_flag, in_process_time, out_process_time, in_pdline_time, out_pdline_time,
		 enc_cnt, pallet_no, carton_no, container, qc_no, qc_result, customer_id, warranty, rework_no, emp_id,
		 shipping_id, customer_sn, wip_process, wip_qty)
		select work_order, serial_number, part_id, version, route_id, pdline_id, stage_id, process_id, terminal_id,
			   next_process, current_status, '1', in_process_time, out_process_time, in_pdline_time, out_pdline_time,
			   enc_cnt, pallet_no, carton_no, container, qc_no, qc_result, customer_id, warranty, rework_no, emp_id,
			   shipping_id, customer_sn, wip_process, tfailqty
		from   sajet.g_sn_status
		where  serial_number = tsn and rownum = 1;
	--INSERT 工單報廢數
	update sajet.g_wo_base set scrap_qty = scrap_qty + tfailqty where work_order = two;
	<<endp>>
	null;
	if tres = 'OK' then
		commit;
	else
		rollback;
	end if;
exception
	when others then
		tres := 'CSBG_WIP_REPAIR_GO Error';
		rollback;
end;


/

