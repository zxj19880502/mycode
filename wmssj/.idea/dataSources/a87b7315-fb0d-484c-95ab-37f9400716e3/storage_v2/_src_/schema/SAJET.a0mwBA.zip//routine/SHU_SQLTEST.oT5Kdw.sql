create function shu_sqltest(SS in VARCHAR2) return varchar2 is SS1
  SAJET.G_WO_BASE.WORK_ORDER%TYPE;
begin
 BEGIN
     SELECT A.WORK_ORDER INTO SS1
       FROM SAJET.G_WO_BASE A, SAJET.SYS_PART B
      WHERE A.PART_ID = B.PART_ID
        AND A.WORK_ORDER= SS
        AND ROWNUM = 1;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
      SS1 :='';
   END;
   RETURN Upper(SS1);
EXCEPTION
  WHEN OTHERS THEN
     RETURN  'SHU_WO_ERR:'||SQLERRM;
end shu_sqltest;
/

