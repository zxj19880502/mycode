create procedure       csbg_chk_container(trev in varchar2
													,tres out varchar2) is
	cshippingid number;
begin
	select shipping_id
	into   cshippingid
	from   sajet.g_shipping_sn
	where  (container = trev or vehicle_no = trev) and rownum = 1;
	tres := 'OK';
exception
	when no_data_found then
		tres := 'Container(Vehicle) Error!!';
	when others then
		tres := 'CSBG_CHK_CONTAINER err';
end;


/

