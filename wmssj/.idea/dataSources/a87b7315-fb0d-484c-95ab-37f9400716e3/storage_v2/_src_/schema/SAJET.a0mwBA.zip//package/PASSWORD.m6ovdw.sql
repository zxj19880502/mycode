create PACKAGE       PASSWORD AS
FUNCTION encrypt(i_password VARCHAR2) RETURN RAW;
FUNCTION decrypt(encrypted_raw RAW) RETURN VARCHAR2;
FUNCTION compare (i_password VARCHAR2,encrypted_raw RAW) RETURN VARCHAR2;
END PASSWORD;


/

