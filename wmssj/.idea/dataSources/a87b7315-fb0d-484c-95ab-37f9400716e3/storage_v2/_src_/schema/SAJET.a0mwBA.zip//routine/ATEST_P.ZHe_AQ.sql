create PROCEDURE       atest_p(res out varchar2)
is
SS date;
begin
    /* SS:=12.3456789;
     RES:=ROUND(SS,3);*/


     SELECT
           nvl ((select min(update_time) from SAJET.G_TERMINAL_REEL
                    where  REEL_NO = 'MP0111A095438' ),sysdate) into ss
       FROM SAJET.G_MATERIAL A
      WHERE A.REEL_NO = 'MP0111A095438';
      res:=ss;
  end;


/

