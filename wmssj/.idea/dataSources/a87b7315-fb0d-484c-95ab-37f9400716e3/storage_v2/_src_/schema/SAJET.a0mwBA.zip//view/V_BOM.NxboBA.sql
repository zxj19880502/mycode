create view V_BOM as
SELECT e.part_id, b.part_no part_no, a.item_part_id, c.part_no item_part_no,
       a.process_id, d.process_name, a.item_group, a.item_count, a.enabled,
       a.VERSION
  FROM sajet.SYS_BOM a,
       sajet.SYS_PART b,
       sajet.SYS_PART c,
       sajet.SYS_PROCESS d,
       sajet.SYS_BOM_INFO e
 WHERE e.part_id = b.part_id
   AND e.bom_id = a.bom_id
   AND a.item_part_id = c.part_id
   AND d.process_id(+) = a.process_id


/

