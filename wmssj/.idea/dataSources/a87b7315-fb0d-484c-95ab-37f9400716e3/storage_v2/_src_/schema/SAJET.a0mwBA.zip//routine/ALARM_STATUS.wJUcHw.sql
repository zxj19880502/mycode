create FUNCTION       ALARM_STATUS(svalue in varchar2) return varchar2 is
str varchar2(16); s number; i number;
begin
  if svalue = '0' then
    str := 'Initial';
  elsif svalue = '1' then
    str := 'Hold';
  elsif svalue = '2' then
    str := 'Finish';
  --elsif svalue = '2' then
  --  str := 'Confirm';
  else
    str := '';
  end if;
  return str;
end;


/

