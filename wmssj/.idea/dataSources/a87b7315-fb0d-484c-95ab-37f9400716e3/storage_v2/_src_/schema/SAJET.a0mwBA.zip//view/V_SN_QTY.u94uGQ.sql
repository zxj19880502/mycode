create view V_SN_QTY as
  select work_order,
       part_id,
       pdline_id,
       stage_id,
       process_id,
       shift_name,
       TO_CHAR(work_date,'YYYYMMDD') work_date,
        wip_in_qty,
        pass_qty,
        fail_qty  from (
select work_order,
       part_id,
       pdline_id,
       stage_id,
       process_id,
       search_worksshifet(in_process_time) shift_name,
     in_process_time work_date,
      1 wip_in_qty,
       0 pass_qty,
       0 fail_qty
  from sajet.g_sn_travel
  where PROCESS_ID<>'100011'
union all
select work_order,
       part_id,
       pdline_id,
       stage_id,
       process_id,
       search_worksshifet(in_process_time) shift_name,
       in_process_time work_date,
        1 wip_in_qty,
       0 pass_qty,
       0 fail_qty
  from sajet.g_sn_status
 where in_process_time is not null
   and out_process_time is null
   and PROCESS_ID<>'100011')
   union all
   select work_order,
       part_id,
       pdline_id,
       stage_id,
       process_id,
       shift_name,
        work_date,
       0 wip_in_qty,
        pass_qty,
        fail_qty
        from sajet.g_sn_count


/

