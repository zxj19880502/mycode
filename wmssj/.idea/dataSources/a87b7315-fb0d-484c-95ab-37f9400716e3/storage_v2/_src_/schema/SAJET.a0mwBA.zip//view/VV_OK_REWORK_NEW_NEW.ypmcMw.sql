create view VV_OK_REWORK_NEW_NEW as
select distinct SERIAL_NUMBER,sizespec,times from
(select a.SERIAL_NUMBER,a.sizespec,to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd') times
from sajet.base_sn_travel a,sajet.g_wo_base b,
sajet.v_g_re_log m
where a.process_id='100026' and a.WORK_ORDER=b.work_order and b.wo_type in ('正常工单','内返工单') and
(to_date(m.ti,'yyyy-mm-dd')<to_date(to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd'),'yyyy-mm-dd') or (to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd')=m.ti and m.qty>1))
and a.current_status in (0,2) and a.SERIAL_NUMBER=m.serial_number
union all
select m.SERIAL_NUMBER,m.sizespec,m.times from
(select a.SERIAL_NUMBER,a.sizespec,to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd') times
from sajet.base_sn_travel a,sajet.g_wo_base b,
sajet.v_g_re_log m
where a.process_id='100026' and a.WORK_ORDER=b.work_order and b.wo_type in ('正常工单','内返工单') and
to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd')=m.ti and m.qty=1
and a.current_status in (0,2) and a.SERIAL_NUMBER=m.serial_number
group by a.SERIAL_NUMBER,a.sizespec,to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd'))m,
(select a.SERIAL_NUMBER,to_char(a.WIP_OUT_TIME-8.5/24,'yyyy-mm-dd') times,count(1) qty1
from sajet.base_sn_travel a,sajet.g_wo_base b
where a.PROCESS_ID=100026 and a.WORK_ORDER=b.work_order and b.wo_type in ('正常工单','内返工单')
and a.CURRENT_STATUS=4
group by a.SERIAL_NUMBER,to_char(a.WIP_OUT_TIME-8.5/24,'yyyy-mm-dd'))n
where m.SERIAL_NUMBER=n.SERIAL_NUMBER and n.qty1>1 and
m.times=n.times
union all
select m.SERIAL_NUMBER,m.sizespec,m.times from
(select a.SERIAL_NUMBER,a.sizespec,to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd') times
from sajet.base_sn_travel a,sajet.g_wo_base b,
sajet.v_g_re_log m
where a.process_id='100026' and a.WORK_ORDER=b.work_order and b.wo_type in ('正常工单','内返工单') and
to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd')=m.ti and m.qty=1
and a.current_status in (0,2) and a.SERIAL_NUMBER=m.serial_number
group by a.SERIAL_NUMBER,a.sizespec,to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd'))m,
(select a.SERIAL_NUMBER,to_char(a.WIP_OUT_TIME-8.5/24,'yyyy-mm-dd') times,count(1) qty1
from sajet.base_sn_travel a,sajet.g_wo_base b
where a.PROCESS_ID=100026 and a.WORK_ORDER=b.work_order and b.wo_type in ('正常工单','内返工单')
and a.CURRENT_STATUS=4
group by a.SERIAL_NUMBER,to_char(a.WIP_OUT_TIME-8.5/24,'yyyy-mm-dd'))n
where m.SERIAL_NUMBER=n.SERIAL_NUMBER and n.qty1=1 and
m.times=n.times)


/

