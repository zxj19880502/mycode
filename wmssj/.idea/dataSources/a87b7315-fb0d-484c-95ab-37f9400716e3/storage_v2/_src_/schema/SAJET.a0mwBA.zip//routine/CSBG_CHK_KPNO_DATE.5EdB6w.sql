create procedure       csbg_chk_kpno_date(trev in varchar2
													,tres out varchar2) as
	c_date date;
begin
	--條碼上的到期日
	sajet.csbg_get_date(trev, c_date, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	--檢查此日期是否在期限內
	if sysdate > c_date then
		tres := 'EXPIRED';
		goto endp;
	end if;
	tres := 'OK';
	<<endp>>
	null;
exception
	when others then
		tres := 'CSBG_CHK_KPNO_DATE ERR';
end;


/

