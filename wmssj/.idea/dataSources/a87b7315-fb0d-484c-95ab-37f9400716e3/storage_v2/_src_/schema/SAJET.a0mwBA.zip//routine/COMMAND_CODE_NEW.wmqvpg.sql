create procedure command_code_new(tlineid     in number
											,tstageid    in number
											,tprocessid  in number
											,tterminalid in number
											,tnow        in date
											,trev        in varchar2
											,tres        out varchar2
											,tnextproc   out varchar2) is
	tsajet1 varchar2(25);
	tsajet2 varchar2(40);
	tsajet3 varchar2(256);
	tsajet4 varchar2(256);
	--tsajet4ton   varchar2(4096);
	tsajet5ton   varchar2(4096);
	c_buffer     varchar2(4096);
	c_head       number;
	cmd          number;
	c_number     number;
	c_start      number;
	c_end        number;
	c_psn        varchar2(35);
	c_temp       varchar2(255);
	c_item       sajet.sys_spc.spc_item%type;
	c_value      sajet.g_spc.spc_value%type;
	c_defect     sajet.sys_defect.defect_code%type;
	c_wo         sajet.g_sn_status.work_order%type;
	c_wo_seq     smt.g_wo_msl.wo_sequence%type;
	c_datecode   smt.g_smt_status.datecode%type;
	c_dbid       varchar2(20);
	c_type       number;
	c_eventid    number;
	t_type       varchar2(25);
	check_status varchar2(10);
	msl_status   varchar2(30);
	c_factory    number;
	cnt          number;
	cnt2         number;
	cvalue       number;
	ctempid      number;
	ccommand     varchar2(200);
	cpanel_no    varchar2(50);
	tcommand     varchar2(50);
begin
	tres := 'Fail,Command fail';

	select count(*) into cnt from table(f_cus_split(trev, ';'));
	cmd := to_number(trim(f_cus_splitstr(trev, 1, ';'))); --獲取cmd

	if cmd = 1 --檢查用戶
	 then
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;PWD]' || trev || '[' || cnt || ']';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';'));
		
			sajet.sj_cksys_emp(tsajet2, tres);
			if tres = 'OK' then
				select password.decrypt(passwd) into cvalue from sajet.sys_emp where emp_no = tsajet2;
				if cvalue <> tsajet3 then
					tres := 'NG;密碼錯誤!';
				else
					tres := 'OK;OK;';
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 2 --檢查工單,并檢查投入數是否已滿
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![WO]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --WO
			hipro_wo_input_chk_wo(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				select input_qty, target_qty into cnt, cnt2 from g_wo_base where work_order = tsajet2;
				if cnt >= cnt2 then
					tres := 'NG;工單投入數已滿!';
				end if;
			end if;
		end if;
	elsif cmd = 3 then
		if cnt < 3 then
			tres := 'NG格式錯誤![WO;連板數]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';'));
			cus_wo_buildsn(tsajet2, tsajet3, tterminalid, tres);
		end if;
	elsif cmd = 4 then
		if cnt < 5 then
			tres := 'NG格式錯誤![WO;工號;板數;SNList]';
		else
			tsajet2    := trim(f_cus_splitstr(trev, 2, ';')); --wo
			tsajet3    := trim(f_cus_splitstr(trev, 3, ';')); --emp
			tsajet4    := trim(f_cus_splitstr(trev, 4, ';')); --板數
			tsajet5ton := trim(f_cus_splitstr(trev, 5, ';')); --SN List
			cus_sn_automapping(tterminalid, tsajet2, tsajet3, tsajet4, tsajet5ton, tres);
		end if;
	elsif cmd = 5 --檢查SN
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
			if tres = 'OK' then
				sajet.sj_ckrt_route(tterminalid, tsajet2, tres);
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 6 --联想sn link
	 then
		if cnt < 4 then
			tres := 'NG;格式錯誤![EMP;WO;PANELNO]';
			goto endpcmd6;
		end if;
		tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --EMP
		tsajet3 := trim(f_cus_splitstr(trev, 3, ';')); --WO
		tsajet4 := trim(f_cus_splitstr(trev, 4, ';')); --panel_no
		sajet.sj_cksys_emp(tsajet2, tres);
		if substr(tres, 1, 2) <> 'OK' then
			tres := 'NG;工号错误';
			goto endpcmd6;
		end if;
	
		sajet.hipro_wo_input_chk_wo2(tsajet3, tres);
		if substr(tres, 1, 2) <> 'OK' then
			goto endpcmd6;
		end if;
		sajet.cus_input2_map_material(tterminalid, tsajet4, tsajet3, tlineid, tprocessid, tsajet2, sysdate, tres,
									  ccommand);
	
		<<endpcmd6>>
		if substr(tres, 1, 2) <> 'OK' then
			rollback;
		else
			commit;
		end if;
	elsif cmd = 7 then
		--过站
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;SN]';
			goto endpcmd7;
		end if;
		tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --EMP
		tsajet3 := trim(f_cus_splitstr(trev, 3, ';')); --SN
	
		sajet.sj_cksys_emp(tsajet2, tres);
		if substr(tres, 1, 2) <> 'OK' then
			tres := 'NG;工号错误';
			goto endpcmd7;
		end if;
	
		--检查流程
		sajet.sj_ckrt_sn_psn(tsajet3, tres, c_psn);
		if substr(tres, 1, 2) <> 'OK' then
			tres := tres || ' [' || tsajet3 || ']';
			goto endpcmd7;
		end if;
	
		sajet.sj_ckrt_route(tterminalid, tsajet3, tres);
		if substr(tres, 1, 2) <> 'OK' then
			tres := tres || ' [' || tsajet3 || ']';
			goto endpcmd7;
		end if;
	
		select a.panel_no into cpanel_no from g_sn_status a where a.serial_number = tsajet3 and rownum = 1;
		if cpanel_no = 'N/A' then
			tres := 'PANEL_NO 不能为空' || ' [' || tsajet3 || ']';
			goto endpcmd7;
		end if;
	
		sajet.sj_smt_ckrt_panel_new(tterminalid, cpanel_no, tres, tcommand);
		if substr(tres, 1, 2) <> 'OK' then
			tres := tres || ' [' || tsajet3 || ']';
			goto endpcmd7;
		end if;
	
		--panel过站         
		sajet.sj_panel_go(tterminalid, cpanel_no, sysdate, tsajet2, tres);
		<<endpcmd7>>
		if substr(tres, 1, 2) <> 'OK' then
			rollback;
		else
			commit;
		end if;
	elsif cmd = 8 then
		if cnt < 5 then
			tres := 'NG格式錯誤![工號;WO;板數;SNList]';
		else
			tsajet2    := trim(f_cus_splitstr(trev, 2, ';')); --emp
			tsajet3    := trim(f_cus_splitstr(trev, 3, ';')); --wo
			tsajet4    := trim(f_cus_splitstr(trev, 4, ';')); --板數
			tsajet5ton := trim(f_cus_splitstr(trev, 5, ';')); --SN List
			sajet.cus_sn_automapping_normal(tterminalid, tsajet3, tsajet2, tsajet4, tsajet5ton, tres);
		end if;
	
		if substr(tres, 1, 2) <> 'OK' then
			rollback;
		else
			commit;
		end if;
	
	
	else
		tres := 'NG;[EC102] COMMAND NOT DEFINE.;';
	end if;

	if substr(tres, 1, 2) = 'OK' and length(tres) < 5 then
		tres := 'OK;' || tres;
	end if;
exception
	when others then
		tres := trev || '[' || sqlerrm || ']';
end;


/

