create function tst(sdate in varchar2) return number is
  Result number;
 
begin
  Result:=sdate;
 /* declare strsql varchar2(2000);
  begin
  sdate:='WHERE t.query_date >= ''20171031'' AND t.query_date < ''20171101''';
\*  strsql:='select count(1) from sajet.PRODUCT_DAY_REP t where 1=1 and ' ||sdate into result;
   execute immediate 'select dname, loc from dept where deptno = :1'
       into l_nam, l_loc
       using l_dept ;*\
  execute immediate 'select count(1) from sajet.PRODUCT_DAY_REP t :1' into result using sdate;*/
  return(Result);
/*  end;*/
  
 /* SELECT SAJET.TST( WHERE t.query_date >= to_char(:PARAM1_1,'yyyymmdd') AND t.query_date < to_char(:PARAM1_2 ,'yyyymmdd')) FROM DUAL
*/
 
/* exception
    when others then*/
     /* result:=0;*/
end tst;


/

