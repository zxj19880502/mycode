create function       cust_report_datamain(svalue in varchar2) return varchar2 is
	str varchar2(25);
begin
	if svalue = '0' then
		str := 'Text Box';
	elsif svalue = '1' then
		str := 'SQL';
	elsif svalue = '2' then
		str := 'Fixed';
	elsif svalue = '3' then
		str := 'Date';
	elsif svalue = '4' then
		str := 'Label';
	elsif svalue = '5' then
		str := 'Check Box';
	elsif svalue = '6' then
		str := 'Numeric';
	elsif svalue = '7' then
		str := 'Rich Text Box';
	elsif svalue = '8' then
		str := 'Unvisible';
	elsif svalue = '9' then
		-- 穦陪ボLabel, ぃ穦Τ逆の夹肈
		str := 'Explain';
	else
		str := 'Unknown';
	end if;
	return str;
end;


/

