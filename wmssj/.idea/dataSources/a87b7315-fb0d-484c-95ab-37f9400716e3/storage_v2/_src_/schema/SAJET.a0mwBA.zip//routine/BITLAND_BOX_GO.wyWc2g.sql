create PROCEDURE       BITLAND_BOX_GO(TSN in varchar2,TTREMINALID in varchar2,TEMPNO in varchar2,TRES out varchar2)IS
nextprocess varchar2(30);
empid number;
psn varchar2(80);
BEGIN
  TRES:='OK';
  nextprocess:='N/A';
  if TSN is null then
    TRES:='sn is null';
    elsif TTREMINALID is null then
    TRES:='Terminal ID is null';
  end if;
  if TRES!='OK' then
    return;
    end if;
  sajet.Sj_Get_Empid(TEMPNO,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMPNO||')';
    return;
    end if;
    sajet.sj_ckrt_sn_psn(TSN,TRES,psn);--？？sn？？？？
    if TRES!='OK'then
      return;
    end if;
   /* begin
    select ms.mo_no into TMO from sajet.g_mo_sn ms where ms.serial_number=TSN;
    exception
      when NO_DATA_FOUND then
        TRES:='SN['||TSN||']No MO';
        return;
      when others then
        TRES:=SQLERRM;
        return;
      end;*/
      if TRES='OK' then
      -- update sajet.g_sn_status ss set ss.box_no=TBOX,ss.customer_sn=TSN||TMO where ss.serial_number=TSN;
      update sajet.g_sn_status ss set ss.box_no=ss.customer_sn where ss.serial_number=TSN;
      -- insert into sajet.g_label_record(LABEL_TYPE,SN1,USER_ID)values('BOX_LABEL',TSN,empid);
        sajet.sj_transfer2(TTREMINALID,TSN,'N/A',sysdate,TEMPNO,TRES,nextprocess);
        if TRES='OK' then
          --SAJET.SJ_CHK_XCSA_OOB3(TSN,TTREMINALID,TEMPNO,TRES);-- 判断下一站是否为XCSA/OOB3,并跳站
          if substr(TRES,0,2)='OK' then
          commit;
          else
            rollback;
          end if;
        else
           rollback;
        end if;
      end if;
exception
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

