create PACKAGE BODY       PASSWORD AS

     raw_key      RAW (128)    := UTL_RAW.cast_to_raw ('sajettech');

     FUNCTION encrypt (i_password VARCHAR2)
          RETURN RAW IS
          input_string    VARCHAR2 (16) := RPAD (i_password, (TRUNC (LENGTH (i_password) / 8) + 1) * 8, ' ');
          raw_input       RAW (128)     := UTL_RAW.cast_to_raw (input_string);
          encrypted_raw   RAW (2048);
     BEGIN
          DBMS_OBFUSCATION_TOOLKIT.desencrypt (input => raw_input, KEY => raw_key, encrypted_data => encrypted_raw);
          RETURN encrypted_raw;
     END encrypt;

     FUNCTION decrypt (encrypted_raw RAW)
          RETURN VARCHAR2 IS
          v_decrypted_val   VARCHAR2 (38);
          decrypted_raw     RAW (2048);
     BEGIN
          DBMS_OBFUSCATION_TOOLKIT.desdecrypt (input => encrypted_raw, KEY => raw_key, decrypted_data => decrypted_raw);
          v_decrypted_val := UTL_RAW.cast_to_varchar2 (decrypted_raw);
          RETURN v_decrypted_val;
     END decrypt;

     FUNCTION compare (i_password VARCHAR2,encrypted_raw RAW)
          RETURN VARCHAR2 IS
          v_decrypted_val   VARCHAR2 (38);
          decrypted_raw     RAW (2048);
      v_result VARCHAR2(10);
     BEGIN

          DBMS_OBFUSCATION_TOOLKIT.desdecrypt (input =>encrypted_raw, KEY => raw_key, decrypted_data => decrypted_raw);
          v_decrypted_val := UTL_RAW.cast_to_varchar2 (decrypted_raw);
      IF TRIM(i_password)=TRIM(v_decrypted_val) THEN
         v_result:='OK';
      ELSE
          v_result:='FAIL';
      END IF;
          RETURN v_result;
     END compare;
END PASSWORD;
/

