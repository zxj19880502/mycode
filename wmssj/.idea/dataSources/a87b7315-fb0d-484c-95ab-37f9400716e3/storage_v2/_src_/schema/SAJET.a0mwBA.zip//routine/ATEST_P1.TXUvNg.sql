create PROCEDURE       atest_p1(res out varchar2)
is

begin
  atest_p(res);
  rollback;
  end;


/

