create view V_G_RE_LOG as
select b.serial_number,to_char(b.wip_out_time-8.5/24,'yyyy-mm-dd') ti,count(b.serial_number) qty
from sajet.g_rework_log b
where b.process_id='100026'
group by b.serial_number,to_char(b.wip_out_time-8.5/24,'yyyy-mm-dd')


/

