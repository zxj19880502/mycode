create trigger SYS_TERMINAL_TRIGGER
  after insert or update or delete
  on SYS_TERMINAL
  for each row
declare
  ncount number;
begin
  if inserting then
    insert into sajet.g_tri_data
      (data_id, data_table, update_user, update_time)
    values
      (:new.terminal_id, 'SAJET.SYS_TERMINAL', :new.update_userid, sysdate);

  end if;

exception
  when others then
    insert into sajet.g_tri_log
      (table_name, param1, param2, param3, clog, row_id, update_time)
    values
      ('sajet.SYS_TERMINAL', 'terminal_id', :new.terminal_id, null, 'Sys_Terminal_trigger error', null, sysdate);

end;

/

