create procedure arabbao_sj_getpartno_sn(trev in varchar2
														 ,tres out varchar2) is
	part varchar2(80);
	v_sn varchar2(100);
begin
	select nvl((select s.serial_number from sajet.g_sn_status s where s.serial_number = trev or s.customer_sn = trev),
				'')
	into   v_sn
	from   dual;
	select part_no
	into   part
	from   sajet.sys_part
	where  part_id = (select part_id from sajet.g_sn_status where serial_number = v_sn);
	tres := part;
exception
	when others then
		tres := '0:SN ERR';
end;


/

