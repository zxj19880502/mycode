create FUNCTION ADLINK_SPECIAL_CHAR(sValue in varchar2)
  return Varchar2 is

BEGIN

  RETURN '-';

EXCEPTION
  WHEN OTHERS THEN
    RETURN SQLERRM;
END;


/

