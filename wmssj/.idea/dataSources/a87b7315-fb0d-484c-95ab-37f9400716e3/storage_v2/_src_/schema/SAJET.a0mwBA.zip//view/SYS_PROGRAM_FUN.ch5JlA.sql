create view SYS_PROGRAM_FUN as
SELECT   b.program,
            b.FUNCTION,
            c.auth_seq,
            c.authoritys,
            b.dll_filename,
            b.fun_idx,
            b.fun_param,
            b.fun_tw,
            b.show_flag,
            b.fun_type,
            b.fun_type_idx,
            b.fun_type_tw,
            b.fun_type_cn,
            b.web_flag,
            b.enabled,
            b.form_name,
            b.fun_type_eng,
            b.fun_eng,
            b.fun_desc_eng,
            b.fun_desc_tw,
            b.fun_desc_cn,
            b.fun_cn
     FROM   sajet.sys_program_fun_name b, sajet.sys_program_fun_authority c
    WHERE   b.program = c.program(+) AND b.FUNCTION = c.FUNCTION(+)


/

