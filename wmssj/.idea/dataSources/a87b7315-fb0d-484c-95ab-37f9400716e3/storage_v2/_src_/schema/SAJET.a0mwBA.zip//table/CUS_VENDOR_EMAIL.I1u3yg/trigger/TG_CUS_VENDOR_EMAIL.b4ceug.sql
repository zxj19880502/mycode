create trigger TG_CUS_VENDOR_EMAIL
  before insert
  on CUS_VENDOR_EMAIL
  for each row
declare
	-- local variables here
begin
	select sys_guid() into :new.keyid from dual;
	select replace(:new.mail_addr, ',', ';') into :new.mail_addr from dual;
end tg_cus_vendor_email;


/

