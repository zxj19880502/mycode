create function       CHECK_COA_STATUS(coa_no_status in number) return varchar2 is
  Result varchar2(40);
begin
  Result:='N/A';
  select case
  when coa_no_status=0 then 'In Warehouse'
  when coa_no_status=1 then 'Out Warehouse'
  when coa_no_status=2 then 'Used'
    when coa_no_status =3 then 'Scrap'
  else 'Unknow coa_no_status'
  end case into Result
  from dual;
  return(Result);

end CHECK_COA_STATUS;


/

