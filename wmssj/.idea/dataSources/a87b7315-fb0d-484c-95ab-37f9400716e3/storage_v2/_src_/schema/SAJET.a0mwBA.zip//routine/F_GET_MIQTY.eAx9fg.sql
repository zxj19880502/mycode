create function f_get_miqty(swo            in varchar2
									  ,sline_id       in varchar2
									  ,sprocess_id    in varchar2
									  ,sitem_location in varchar2
									  ,sterminal      in varchar2) return number is
	result        number;
	ccount        number;
	rest_allline  number;
	rest_terminal number;
begin
	--这个制程有没有全线使用的上料
	select count(a.part_id)
	into   ccount
	from   sajet.g_mi_input a, sajet.sys_terminal b
	where  a.work_order = swo and a.status = '1' and a.terminal_id = b.terminal_id and b.pdline_id = sline_id and
		   a.all_line = 'Y' and b.process_id = sprocess_id;
	if ccount <> 0 then
		--    -10000就是没有上料
		select nvl(sum(a.qty_rest), -10000)
		into   rest_allline
		from   sajet.g_mi_input a, sajet.sys_terminal b
		where  a.work_order = swo and a.status = '1' and a.item_location = sitem_location and
			   a.terminal_id = b.terminal_id and b.pdline_id = sline_id and a.all_line = 'Y' and
			   b.process_id = sprocess_id and a.qty_rest > 0;
		result := rest_allline;
	else
		select nvl(sum(a.qty_rest), -10000)
		into   rest_terminal
		from   sajet.g_mi_input a
		where  a.work_order = swo and a.status = '1' and a.item_location = sitem_location and a.terminal_id = sterminal and
			   a.qty_rest > 0;
		result := rest_terminal;
	end if;

	return(result);
exception
	when others then
		result := 0;
		return result;
end;


/

