create procedure       csbg_qc_update_lot(tterminalid   in number
													,tqclotno      in varchar2
													,tqccnt        in varchar2
													,tlotsize      in number
													,tsamplingsize in number
													,tpassqty      in number
													,tfailqty      in number
													,tsamplingid   in number
													,tdate         in date
													,two           in varchar2
													,tmodelid      in number
													,tempid        in number
													,tqcresult     in varchar2
													,tqcline       in varchar2
													,tres          out varchar2) is
	c_endtime date;
	v_qty     number;
	/*---------------------------------
    DATE : 2005/07/19  PDLINE 填QC 設定的
    ----------------------------------*/
begin
	c_endtime := tdate;
	select count(*) into v_qty from sajet.g_qc_lot where qc_lotno = tqclotno and ng_cnt = tqccnt and rownum = 1;
	if v_qty = 0 then
		insert into sajet.g_qc_lot
			(qc_lotno, part_id, work_order, pdline_id, stage_id, process_id, terminal_id, insp_empid, ng_cnt, lot_size,
			 sampling_size, pass_qty, fail_qty, start_time, end_time, sampling_plan_id, qc_result)
			select tqclotno, tmodelid, two, tqcline, stage_id, process_id, terminal_id, tempid, tqccnt, tlotsize,
				   tsamplingsize, tpassqty, tfailqty, tdate, tdate, tsamplingid, tqcresult
			from   sajet.sys_terminal
			where  terminal_id = tterminalid and rownum = 1;
	else
		update sajet.g_qc_lot
		set    lot_size = tlotsize, sampling_size = tsamplingsize, pass_qty = tpassqty, fail_qty = tfailqty,
			   part_id = tmodelid, work_order = two, sampling_plan_id = tsamplingid, end_time = c_endtime,
			   qc_result = tqcresult
		where  qc_lotno = tqclotno and ng_cnt = tqccnt;
	end if;
	tres := 'OK';
exception
	when others then
		tres := 'UPDATE QC LOT ERROR' || sqlerrm;
end;


/

