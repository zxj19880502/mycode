create function f_get_itemdata(slotno   in varchar2
										 ,stest_id in number) return varchar2 is
	cresult varchar2(50);
	cdata   varchar2(200);
	ccount  number;
begin


	select count(d.insp_result)
	into   ccount
	from   sajet.g_qc_sn a, sajet.g_qc_lot b, sajet.g_sn_testitem_header c, sajet.g_sn_testitem_detail d
	where  b.qc_lotno = slotno and a.qc_lotno = b.qc_lotno and a.recid = c.recid and c.recid = d.recid and
		   d.item_id = stest_id and d.insp_result = 'NG';
	if ccount > 0 then
		cresult := 'NG';
	else
		cresult := 'OK';
	
	end if;

	--先判定这个测试项目是否是需要输入数值的

	select count(has_value) into ccount from sajet.sys_test_item a where a.item_id = stest_id and a.has_value = 'Y';

	if ccount = '0' then
		cdata := cresult;
	
	else
		--是，就抓对应的测试值 
	
		select to_char(wm_concat(insp_value))
		into   cdata
		from   (select d.insp_value, d.insp_result
				 from   sajet.g_qc_sn a, sajet.g_qc_lot b, sajet.g_sn_testitem_header c, sajet.g_sn_testitem_detail d
				 where  b.qc_lotno = slotno and a.qc_lotno = b.qc_lotno and a.recid = c.recid and c.recid = d.recid and
						d.item_id = stest_id
				 order  by insp_result)
		where  rownum <= 5;
	end if;


	return cdata;
exception
	when others then
		return '';
end;
/

