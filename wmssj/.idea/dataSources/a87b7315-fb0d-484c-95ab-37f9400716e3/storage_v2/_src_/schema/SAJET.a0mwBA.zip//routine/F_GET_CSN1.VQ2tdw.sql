create function f_get_csn1(spallet_no in varchar2
									 ,srownum1   in number
									 ,srownum    in number) return varchar2 is
	csn1    varchar2(50);
	carton1 varchar2(50);
	ccount  number;
	ccount1 number;
	ccount2 number;
begin
	select count(*) into ccount from sajet.g_sn_status a where pallet_no = spallet_no;
	if srownum > ccount then
		csn1 := '';
		goto endp;
	end if;
	select distinct count(distinct carton_no) into ccount1 from sajet.g_sn_status where pallet_no = spallet_no;
	if srownum1 > ccount1 then
		csn1 := '';
		goto endp;
	end if;
	select carton_no
	into   carton1
	from   (select rownum as rm, b.carton_no
			 from   (select distinct carton_no from sajet.g_sn_status a where pallet_no = spallet_no order by carton_no) b)
	
	where  rm = srownum1;

	select count(*) into ccount2 from sajet.g_sn_status a where carton_no = carton1;
	if srownum > ccount2 then
		csn1 := '';
		goto endp;
	end if;
	select customer_sn
	into   csn1
	from   (select rownum as rn, b.*
			 from   (select a.*
					  from   sajet.g_sn_status a
					  where  pallet_no = spallet_no and carton_no = carton1
					  order  by carton_no, customer_sn) b)
	
	where  rn = srownum;
	<<endp>>
	return csn1;
exception
	when others then
		return sqlerrm;
end;
/

