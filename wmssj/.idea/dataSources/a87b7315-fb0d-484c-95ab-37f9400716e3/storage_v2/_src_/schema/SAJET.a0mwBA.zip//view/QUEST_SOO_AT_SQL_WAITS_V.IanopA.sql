create view QUEST_SOO_AT_SQL_WAITS_V as
SELECT "EVENT_ID","TRACE_FILE_ID","SQL_ID","PARSE_ID","EXECUTION_ID","WAIT_ID","OBJ#","WAIT_COUNT","SUM_ELAPSED","SUMSQUARES_ELAPSED","NAM"
  FROM quest_soo_at_sql_waits
  JOIN quest_soo_at_wait_names USING (event_id)


/

