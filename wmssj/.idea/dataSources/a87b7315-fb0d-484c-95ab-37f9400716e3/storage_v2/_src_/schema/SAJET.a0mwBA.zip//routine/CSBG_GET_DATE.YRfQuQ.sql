create procedure       csbg_get_date(trev     in varchar2
											   ,toutdate out date
											   ,tres     out varchar2) as
	c_year  varchar2(4);
	c_month varchar2(2);
	c_date  varchar2(2);
begin
	if length(trev) <> 3 then
		tres := 'LENGTH ERROR';
		goto endp;
	end if;
	c_year  := substr(trev, 1, 1);
	c_month := substr(trev, 2, 1);
	c_date  := substr(trev, 3, 1);
	--年
	c_year := substr(to_char(sysdate, 'YYYY'), 1, 3) || c_year;
	--月
	case c_month
		when 'A' then
			c_month := '10';
		when 'B' then
			c_month := '11';
		when 'C' then
			c_month := '12';
		else
			c_month := '0' || c_month;
	end case;
	--日
	case c_date
		when 'A' then
			c_date := '10';
		when 'B' then
			c_date := '11';
		when 'C' then
			c_date := '12';
		when 'D' then
			c_date := '13';
		when 'E' then
			c_date := '14';
		when 'F' then
			c_date := '15';
		when 'G' then
			c_date := '16';
		when 'H' then
			c_date := '17';
		when 'I' then
			c_date := '18';
		when 'J' then
			c_date := '19';
		when 'K' then
			c_date := '20';
		when 'L' then
			c_date := '21';
		when 'M' then
			c_date := '22';
		when 'N' then
			c_date := '23';
		when 'O' then
			c_date := '24';
		when 'P' then
			c_date := '25';
		when 'Q' then
			c_date := '26';
		when 'R' then
			c_date := '27';
		when 'S' then
			c_date := '28';
		when 'T' then
			c_date := '29';
		when 'U' then
			c_date := '30';
		when 'V' then
			c_date := '31';
		else
			c_date := '0' || c_date;
	end case;
	toutdate := to_date(c_year || c_month || c_date, 'YYYYMMDD');
	tres     := 'OK';
	<<endp>>
	null;
exception
	when others then
		tres := 'DATE FORMAT ERR';
end;


/

