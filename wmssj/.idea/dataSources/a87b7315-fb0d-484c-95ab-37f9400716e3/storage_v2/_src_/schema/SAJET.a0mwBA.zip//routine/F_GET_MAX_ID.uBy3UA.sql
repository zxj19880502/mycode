create function       F_GET_MAX_ID
(
   V_TABLE IN VARCHAR2
  ,V_FIELD IN VARCHAR2
  ,V_LENGTH IN NUMBER
)
return NUMBER
is

TYPE cur_typ IS REF CURSOR;
c           cur_typ;
sQueryStr VARCHAR2(254);
T_ID NUMBER;

begin

   sQueryStr:= 'SELECT NVL(Max(' || V_FIELD || '),0) + 1 MaxID  FROM ' || V_TABLE ;

   OPEN c FOR sQueryStr;
   FETCH c INTO T_ID;

   IF T_ID = 1 THEN
      close c;
      sQueryStr:= 'Select RPAD(NVL(PARAM_VALUE,1),' || TO_CHAR(V_LENGTH - 1) || ',0) || 1 MaxID ' ||
                  'From SAJET.SYS_BASE ' ||
                 'Where PARAM_NAME = ''DBID'' ' ;
      OPEN c FOR sQueryStr;
      FETCH c INTO T_ID;

   END IF;

   close c;

   return T_ID;
EXCEPTION
  WHEN OTHERS THEN
     return 999;
END;


/

