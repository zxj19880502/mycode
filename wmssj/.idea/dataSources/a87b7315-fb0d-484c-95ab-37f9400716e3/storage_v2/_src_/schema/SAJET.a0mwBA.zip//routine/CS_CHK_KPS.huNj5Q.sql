create procedure        cs_chk_kps(tlineid in number, tstageid in number, tprocessid in number, tterminalid in number, tsn in varchar2, tnow in date, tres out varchar2, tempid in varchar2, trev in varchar2, tdefect in varchar2) is
	ccount number;
begin
	select count(*) into ccount from sajet.g_sn_status b where b.customer_sn = trev and rownum = 1;
	if ccount <> 0 then
		tres := 'KPS 重複';
	else
		select count(*) into ccount from sajet.g_sn_status where serial_number = trev and rownum = 1;
		if ccount <> 0 then
			tres := 'KPS 錯誤';
		else
			tres := 'OK';
		end if;
	end if;
end;


/

