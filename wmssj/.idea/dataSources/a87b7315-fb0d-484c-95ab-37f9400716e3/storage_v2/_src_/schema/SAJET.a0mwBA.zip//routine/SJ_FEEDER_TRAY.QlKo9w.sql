create FUNCTION       Sj_Feeder_Tray(svalue IN VARCHAR2) RETURN VARCHAR2 IS
str VARCHAR2(16);
BEGIN
  IF svalue = '0' THEN
    str := 'Feeder';
  ELSIF svalue = '2' THEN
    str := 'Tray';
  ELSE
    str := 'Unknown';
  END IF;
  RETURN str;
END;


/

