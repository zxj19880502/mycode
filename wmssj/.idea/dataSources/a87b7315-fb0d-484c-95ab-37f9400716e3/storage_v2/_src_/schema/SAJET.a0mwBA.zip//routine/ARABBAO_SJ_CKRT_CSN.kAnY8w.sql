create procedure arabbao_sj_ckrt_csn(trev in varchar2
													 ,tres out varchar2) is
	cwo   sajet.g_wo_base.work_order%type;
	wflag varchar2(10);
	v_sn  varchar2(100);
begin
	tres := 'SN ERR';
	select nvl((select s.serial_number from sajet.g_sn_status s where s.serial_number = trev or s.customer_sn = trev),
				'')
	into   v_sn
	from   dual;
	select work_order, work_flag
	into   cwo, wflag
	from   sajet.g_sn_status
	where  /*CUSTOMER_SN = TREV OR*/
	 serial_number = v_sn and rownum = 1;
	if wflag = '1' then
		tres := 'SN SCRAP';
	elsif wflag = '2' then
		tres := 'SN HOLD';
	else
		sajet.sj_chk_wo_input(cwo, tres);
	end if;
exception
	when others then
		tres := 'Please Input Correct SN';
end;


/

