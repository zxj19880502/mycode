create view V_DAILY_IN_SCRAP_REWORK_NEW as
select p.process_name,
       query_date,
       a.sizespec,
       p2.JZ_PLAN_NUMBER plan_input,
       sum(qty) qty,
       sum(scrap_qty) scrap_qty,
       sum(rework_qty) rework_qty,
       wo_type
  from (select process_id,
               sizespec,
               output_date query_date,
               count( DISTINCT serial_number) qty,
               0 scrap_qty,
               0 rework_qty,
               wo_type
          from sajet.V_SN_TRAVEL_SIMPLE t
         where process_id in (100031, 100026, 100029)
         and current_status in('0','1','2') --by20170907 总量=合格+废品
         group by process_id, output_date, sizespec,wo_type
        union all
        select process_id,
               sizespec,
               output_date,
               0,
               count(serial_number),
               0
               ,wo_type
          from sajet.V_SN_TRAVEL_SIMPLE t
         where process_id in (100031, 100026, 100029)
           and current_status = '1'
         group by process_id, output_date, sizespec,wo_type
        union all
        select process_id,
               sizespec,
               output_date,
               0,
               0,
               count(serial_number)
               ,wo_type
          from sajet.V_SN_TRAVEL_SIMPLE t
         where process_id in (100031, 100026, 100029)
           and current_status = '4'
         group by process_id, output_date, sizespec,wo_type
         ----<--半检,成品检,出厂检
        union all
        select process_id,
               sizespec,
               output_date,
               count(serial_number) out_qty,
               0 scrap_qty,
               0
               ,wo_type
          from sajet.V_SN_TRAVEL_SIMPLE t
         where process_id in (100013, 100022,100015,100016,100017,100020,100024)
         group by process_id, sizespec, output_date,wo_type
        union all
        select process_id,
               sizespec,
               output_date,
               0,
               count(serial_number) scrap_qty,
               0
               ,wo_type
          from sajet.V_SN_TRAVEL_SIMPLE t
         where process_id in (100013, 100022,100015,100016,100017,100020,100024)
           and current_status = '1'
         group by process_id, sizespec, output_date,wo_type
         ----<--脱模,喷涂,喷砂,切边,修坯,清洗,包装
        union all
        select process_id,
               sizespec,
               input_date,
               count(serial_number) in_qty,
               0 scrap_qty,
               0
               ,wo_type
          from sajet.V_SN_TRAVEL_SIMPLE t
         where process_id in (100014,
                              100018,
                              100019)
         group by process_id, sizespec, input_date,wo_type
        union all
        select process_id,
               sizespec,
               input_date,
               0,
               count(serial_number) scrap_qty,
               0
               ,wo_type
          from sajet.V_SN_TRAVEL_SIMPLE t
         where process_id in (100014,
                              100018,
                              100019)
           and current_status = '1'
         group by process_id, sizespec, input_date,wo_type
         ----<--养护,烘干,烧结,
        union all
        select t.process_id,
               d2.die_option1,
               to_char(t.in_process_time - 8.5/24, 'yyyymmdd') query_date,
               count(t.rc_no) in_qty,
               0 scrap_qty,
               0
               ,wo_type
          from sajet.g_rc_status     t,
               sajet.g_rc_travel_die d1,
               sajet.sys_die         d2,
               sajet.g_wo_base w
         where t.process_id = 100011
           and t.RC_NO = d1.rc_no(+)
           and d1.die_code = d2.die_no(+)
           and t.work_order=w.work_order
         group by t.process_id,
                  d2.die_option1,
                  to_char(t.in_process_time - 8.5/24, 'yyyymmdd'),wo_type
        union all
        select t.process_id,
               d2.die_option1,
               to_char(t.in_process_time - 8.5/24, 'yyyymmdd') query_date,
               0,
               count(t.rc_no) scrap_qty,
               0
               ,wo_type
          from sajet.g_rc_status     t,
               sajet.g_rc_travel_die d1,
               sajet.sys_die         d2,
               sajet.g_wo_base w
         where t.process_id = 100011
           and t.RC_NO = d1.rc_no(+)
           and d1.die_code = d2.die_no(+)
           and t.work_order=w.work_order
           and current_status = '1'
         group by t.process_id,
                  d2.die_option1,
                  to_char(t.in_process_time - 8.5/24, 'yyyymmdd'),wo_type
                  ----<--浇注
                  ) a,
       sajet.sys_process p,
       (select to_char(a.date_time,'yyyymmdd') plan_date, a.jz_plan_number, substr(b.spec1,1,4) sizespec
          from sajet.G_SCHEDULE_PLAN a, sajet.sys_part b
         where a.part_id = b.part_id) p2
 where a.process_id = p.process_id
   and a.query_date = p2.plan_date(+)
   and a.sizespec = p2.sizespec(+)
 group by p.process_name, a.sizespec, query_date, p2.JZ_PLAN_NUMBER,wo_type


/

