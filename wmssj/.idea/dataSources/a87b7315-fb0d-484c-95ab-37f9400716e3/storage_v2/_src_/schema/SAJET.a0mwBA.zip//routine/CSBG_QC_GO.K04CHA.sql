create procedure       csbg_qc_go(tterminalid    in number
											,tqclotno       in varchar2
											,tqccnt         in varchar2
											,two            in varchar2
											,tpartid        in varchar2
											,tsn            in varchar2
											,twipqty        in number
											,tinspsndata    in varchar2
											,tdefectdata    in varchar2
											,tempid         in number
											,tsampling_type in varchar2
											,tqcresult      in varchar2
											,tlotsize       in number
											,tsamplingsize  in number
											,tpassqty       in number
											,tfailqty       in number
											,tqcpdlineid    in varchar2
											,tres           out varchar2) is
	--==============LAYOUT===================
	clineid       number;
	cstageid      number;
	cprocessid    number;
	cnextstage    number;
	cnextterminal number;
	--========================================= 
	c_model_id    number;
	c_sampling_id number;
	c_date        date;
	cnewsn        sajet.g_sn_status.serial_number%type;
	c_routeid     sajet.g_sn_status.route_id%type;
	cnextprocess  sajet.g_sn_status.wip_process%type;
	c_status      varchar2(1);
	outflag       boolean;
begin
	tres   := 'OK';
	c_date := sysdate;
	sajet.sj_get_place(tterminalid, clineid, cstageid, cprocessid);
	sajet.csbg_qc_get_samplingid(tsampling_type, c_sampling_id);
	begin
		select current_status, route_id, part_id
		into   c_status, c_routeid, c_model_id
		from   sajet.g_sn_status
		where  serial_number = tsn and rownum = 1;
	exception
		when others then
			tres := 'NO SN :' || tsn;
			goto endp;
	end;
	sajet.csbg_qc_insert_sn(tinspsndata, tqclotno, tqccnt, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	sajet.csbg_qc_insert_sn_defect(tdefectdata, tqclotno, tqccnt, tterminalid, tqcpdlineid, cstageid, cprocessid,
								   tpartid, tempid, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	sajet.csbg_qc_update_lot(tterminalid, tqclotno, tqccnt, tlotsize, tsamplingsize, tpassqty, tfailqty, c_sampling_id,
							 c_date, two, tpartid, tempid, tqcresult, tqcpdlineid, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	update sajet.g_sn_status set qc_result = tqcresult, qc_no = tqclotno where serial_number = tsn;
	--PASS 
	if (tqcresult = '0') then
		--良品數記102 PASS QTY
		--SAJET.CSBG_transation_count(TQCPDLINEID,CSTAGEID,CPROCESSID,TEMPID,C_DATE,TSN,TWO,C_MODEL_ID,0,TPASSQTY,TLOTSIZE,'0',TRES);
		sajet.csbg_transation_count(tqcpdlineid, cstageid, cprocessid, tempid, c_date, tsn, two, c_model_id, 0,
									tpassqty, 0, '0', tres);
		if tres <> 'OK' then
			goto endp;
		end if;
		--不良數記102 FAIL QTY
		sajet.csbg_transation_count(tqcpdlineid, cstageid, cprocessid, tempid, c_date, tsn, two, c_model_id, 1,
									tfailqty, 0, '0', tres);
		if tres <> 'OK' then
			goto endp;
		end if;
		sajet.csbg_wo_output_qty(cprocessid, tsn, twipqty, c_date, tempid, outflag, tres);
		--減少此張rc 數量
		update sajet.g_sn_status set wip_qty = wip_qty - twipqty where serial_number = tsn;
		--產生下一張rc號
		sj_get_nextprocess(c_routeid, cprocessid, '0', cnextprocess);
		if cnextprocess <> 0 then
			/*
            select stage_id,terminal_id into cnextstage,cnextterminal 
            from sajet.sys_terminal
            where pdline_id = clineid
            and process_id = CNEXTPROCESS
            and rownum=1;
            */
			cnewsn := two || cnextprocess;
			--SAJET.CSBG_UPDATE_SN(TWO,TPARTID,c_routeid,clineid,cnextstage,CNEXTPROCESS,cnextterminal,CNEWSN,c_status,c_date,TEMPID,TWIPQTY,TRES);    
			sajet.csbg_update_sn(two, tpartid, c_routeid, clineid, cstageid, cnextprocess, tterminalid, cnewsn,
								 c_status, c_date, tempid, twipqty, tres);
			if tres <> 'OK' then
				goto endp;
			end if;
		end if;
	else
		--良品數記102 PASS QTY
		sajet.csbg_transation_count(tqcpdlineid, cstageid, cprocessid, tempid, c_date, tsn, two, c_model_id, 0,
									tpassqty, 0, '0', tres);
		if tres <> 'OK' then
			goto endp;
		end if;
		--不良數記102 FAIL QTY
		sajet.csbg_transation_count(tqcpdlineid, cstageid, cprocessid, tempid, c_date, tsn, two, c_model_id, 1,
									tfailqty, 0, '0', tres);
		if tres <> 'OK' then
			goto endp;
		end if;
	end if;
	<<endp>>
	null;
	if tres = 'OK' then
		commit;
	else
		rollback;
	end if;
exception
	when others then
		tres := 'CSBG_QC_GO ERROR';
		rollback;
end;


/

