create function       Convert_Ten_To_TT(Ten in number) return varchar2 is
--10???33??(10????26????I.O.S???)
stt varchar2(12) ;--33?????
sremainder varchar2(2);--??
nremainder number;
squotient varchar2(2);--?
nquotient number;
bytes varchar2(33);
begin
  bytes:='0123456789ABCDEFGHJKLMNPQRTUVWXYZ';
  --s33d:='N/A';
  if Ten<=0 then
    return '0';
  elsif Ten>=33 then
  begin
    nquotient:=trunc(Ten/33);
    nremainder:=mod(Ten,33);
    sremainder:=substr(bytes,nremainder+1,1);
    stt:=sremainder||stt;
    stt:=Convert_Ten_To_TT(nquotient)||stt;
    exception
      when others then
      return '0';
    end;
  else
    stt:=substr(bytes,Ten+1,1)||stt;
    end if;
    --if stt!='0'then
    --  stt:=lpad(stt,bitlength,'0');
    --  end if;
return stt;
end;


/

