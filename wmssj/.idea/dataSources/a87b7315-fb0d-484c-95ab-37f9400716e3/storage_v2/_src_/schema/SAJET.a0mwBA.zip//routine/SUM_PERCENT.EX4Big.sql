create function SUM_PERCENT(Sdate in varchar2,Sprocess in number,Sflag in number,ssizespec in varchar2) return number is
  Result number;
  x_count number;
begin
  if Sflag=1 then 
  select count(t.SERIAL_NUMBER)
    into Result
    from sajet.v_sn_travel_simple t
   where t.PROCESS_ID = Sprocess
     and t.output_date = Sdate
     and t.CURRENT_STATUS = '4' and t.sizespec=ssizespec;
    
  end if;
  
  if sflag=2 then
     select count(t.SERIAL_NUMBER)
    into Result
    from sajet.v_sn_travel_simple t
   where t.PROCESS_ID = Sprocess
     and t.output_date = Sdate and t.sizespec=ssizespec; 
  end if;
  
  return(Result);
  exception
    when others then
      result:=0;
      return(result);
end SUM_PERCENT;


/

