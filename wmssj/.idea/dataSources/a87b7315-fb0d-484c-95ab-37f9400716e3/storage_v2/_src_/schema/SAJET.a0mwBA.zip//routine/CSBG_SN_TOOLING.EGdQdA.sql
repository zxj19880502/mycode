create procedure       csbg_sn_tooling(tsn         in varchar2
												 ,tterminalid number
												 ,tres        out varchar2) is
	c_wo          sajet.g_sn_status.work_order%type;
	c_tooling_seq sajet.g_tooling_sn_status.tooling_seq%type;
begin
	select work_order into c_wo from sajet.g_sn_status where serial_number = tsn;
	--固定治具===============================================
	begin
		select tooling_seq
		into   c_tooling_seq
		from   sajet.g_tooling_sn_status
		where  work_order = c_wo and terminal_id = tterminalid and rownum = 1;
	exception
		when others then
			c_tooling_seq := 'N/A';
	end;
	--紀錄使用治具的序號
	if c_tooling_seq <> 'N/A' then
		insert into sajet.g_sn_tooling
			(work_order, serial_number, pdline_id, stage_id, process_id, terminal_id, in_process_time, out_process_time,
			 emp_id, tooling_seq)
			select work_order, serial_number, pdline_id, stage_id, process_id, terminal_id, in_process_time,
				   out_process_time, emp_id, c_tooling_seq
			from   sajet.g_sn_status
			where  serial_number = tsn;
	end if;
	--============================================================
	--變動治具===============================================
	begin
		select tooling_seq into c_tooling_seq from sajet.g_tooling_sn_status where serial_number = tsn and rownum = 1;
	exception
		when others then
			c_tooling_seq := 'N/A';
	end;
	--紀錄使用治具的序號
	if c_tooling_seq <> 'N/A' then
		insert into sajet.g_sn_tooling
			(work_order, serial_number, pdline_id, stage_id, process_id, terminal_id, in_process_time, out_process_time,
			 emp_id, tooling_seq)
			select work_order, serial_number, pdline_id, stage_id, process_id, terminal_id, in_process_time,
				   out_process_time, emp_id, c_tooling_seq
			from   sajet.g_sn_status
			where  serial_number = tsn;
	end if;
	--============================================================
	--UPDATE 治具次數
	update sajet.g_tooling_sn_status
	set    used_count = used_count + 1
	where  tooling_sn_id in
		   (select tooling_sn_id
			from   sajet.g_tooling_sn_status
			where  (work_order = c_wo and terminal_id = tterminalid) or serial_number = tsn);
	tres := 'OK';
exception
	when others then
		tres := 'CSBG_SN_TOOLING ERROR! ';
end;


/

