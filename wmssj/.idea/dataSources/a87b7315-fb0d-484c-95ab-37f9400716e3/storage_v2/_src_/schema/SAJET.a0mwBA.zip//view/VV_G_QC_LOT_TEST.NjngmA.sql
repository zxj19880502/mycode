create view VV_G_QC_LOT_TEST as
select h.QC_LOTNO,h.SERIAL_NUMBER,h.PROCESS_NAME,h.lot_memo,h.start_time,j.times from
(SELECT distinct A.QC_LOTNO,A.SERIAL_NUMBER,G.PROCESS_NAME,b.lot_memo,b.start_time
FROM sajet.g_qc_lot_test_item a,sajet.g_qc_lot b,
sajet.sys_test_item_type e,sajet.sys_test_item f,sajet.sys_process g
WHERE a.qc_lotno=b.qc_lotno AND b.process_id=g.process_id AND a.item_type_id=e.item_type_id
AND a.item_id=f.item_id AND G.PROCESS_ID=100026

ORDER BY A.QC_LOTNO,A.SERIAL_NUMBER)h,
(SELECT serial_number, MAX(qc_lotno) AS qc_lotno,to_char(update_time-8.5/24,'yyyy-mm-dd') times
FROM sajet.g_qc_lot_test_item
where qc_lotno<>'N/A'
GROUP BY serial_number,to_char(update_time-8.5/24,'yyyy-mm-dd'))j
where h.QC_LOTNO=j.QC_LOTNO and h.SERIAL_NUMBER=j.SERIAL_NUMBER


/

