create procedure       csbg_chk_wo_qty(trev     in number
												 ,two      in varchar2
												 ,tres     out varchar2
												 ,pmodelid out number) is
	ccaninput number;
begin
	select target_qty - input_qty, part_id into ccaninput, pmodelid from sajet.g_wo_base where work_order = two;
	--檢查投入數量是否超過目標
	if trev > ccaninput then
		tres := 'OVER WO TARTGET QTY !!';
	else
		tres := 'OK';
	end if;
exception
	when others then
		tres := 'CSBG_CHK_WO_QTY error';
end;


/

