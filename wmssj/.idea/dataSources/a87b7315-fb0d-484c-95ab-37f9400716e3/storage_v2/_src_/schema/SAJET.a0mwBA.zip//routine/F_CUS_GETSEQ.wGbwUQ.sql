create function       f_cus_getseq(seqcode    in varchar2
											 ,binary_num in number
											 ,out_length in number) return varchar2 is
	fres varchar2(64);
	x    number;
	n    number;
	l    varchar(36);
	chex number;
begin
	if (binary_num is null) then
		if (out_length is null) then
			return null;
		else
			return lpad('0', out_length, '0');
		end if;
	end if;
	--L := '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	l    := seqcode;
	chex := length(l);
	x    := binary_num;
	loop
		n    := mod(x, chex);
		fres := concat(substr(l, abs(n) + 1, 1), fres);
		x    := trunc(x / chex);
		exit when x = 0;
	end loop;
	if (out_length is not null and length(fres) < out_length) then
		fres := lpad(fres, out_length, '0');
	end if;
	if (binary_num < 0) then
		fres := '-' || fres;
	end if;
	return fres;
end f_cus_getseq;


/

