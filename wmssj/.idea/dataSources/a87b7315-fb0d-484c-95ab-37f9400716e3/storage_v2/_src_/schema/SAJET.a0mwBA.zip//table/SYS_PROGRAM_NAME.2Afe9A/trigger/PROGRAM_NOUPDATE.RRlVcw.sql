create trigger PROGRAM_NOUPDATE
  before update of PGM_UI_BLOCK_COLOR,PGM_UI_BLOCK_IMAGE
  on SYS_PROGRAM_NAME
  for each row
declare
	-- local variables here
begin
	case
		when updating('PGM_UI_BLOCK_COLOR') then
			:new.pgm_ui_block_color := :old.pgm_ui_block_color;
		when updating('PGM_UI_BLOCK_IMAGE') then
			:new.pgm_ui_block_image := :old.pgm_ui_block_image;
	end case;
end program_noupdate;


/

