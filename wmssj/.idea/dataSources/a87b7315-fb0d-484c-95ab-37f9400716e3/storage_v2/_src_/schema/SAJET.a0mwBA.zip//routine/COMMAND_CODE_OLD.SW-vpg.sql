create PROCEDURE COMMAND_CODE_old (
   tlineid       IN       NUMBER,
   tstageid      IN       NUMBER,
   tprocessid    IN       NUMBER,
   tterminalid   IN       NUMBER,
   tnow          IN       DATE,
   trev          IN       VARCHAR2,
   tres          OUT      VARCHAR2,
   tnextproc     OUT      VARCHAR2
)
IS
   tsajet1       VARCHAR2(25);
   tsajet2       VARCHAR2(25);
   tsajet3       VARCHAR2(128);
   tsajet4       VARCHAR2(128);
   tsajet4ton  VARCHAR2(4096);
   tsajet5ton    VARCHAR2(4096);
   c_Buffer      VARCHAR2(4096);
   c_head        NUMBER;
   cmd           NUMBER;
   c_Number  Number;
   c_Start  Number;
   c_End  Number;
   c_PSN  Varchar2(35);
   c_Temp        Varchar2(255);
   c_Item   Sajet.SYS_SPC.SPC_ITEM%Type;
   c_Value       Sajet.G_SPC.SPC_VALUE%Type;
   c_Defect      SAJET.SYS_DEFECT.DEFECT_CODE%Type;
   C_WO          SAJET.G_SN_STATUS.WORK_ORDER%TYPE;
   C_WO_SEQ      SMT.G_WO_MSL.WO_SEQUENCE%TYPE;
   C_DATECODE    SMT.G_SMT_STATUS.DATECODE%TYPE;
   C_DBID        VARCHAR2(20);
   C_TYPE  NUMBER;
   C_EVENTID     NUMBER;
   T_TYPE  VARCHAR2(25);
   Check_Status  VARCHAR2(10);
   Msl_Status    VARCHAR2(30);
   C_FACTORY     NUMBER;
BEGIN
   tres := 'Fail,Command fail';
   --
   IF SUBSTR(TREV, LENGTH(TREV), 1) = ';' THEN
      c_Buffer := TREV;
   ELSE
      c_Buffer := TREV || ';';
   END IF;

   c_Number := 1;
   c_Start := 1;
   c_End := INSTR (c_Buffer, ';', c_Start, c_Number);

   IF C_End <= 3 THEN
   BEGIN
      cmd := SUBSTR(c_Buffer, c_Start, C_End-c_Start);
      -- INCREASE INDEX
      c_Number := c_Number + 1;
      c_Start := c_End + 1;
   EXCEPTION
      WHEN OTHERS THEN
         cmd := 999;
   END;
   ELSE
      cmd := 999;
   END IF;
   --

   IF cmd = 1
   THEN
      c_End := INSTR (c_Buffer, ';', 1, c_Number);

      IF (c_End-c_Start) <= 25 THEN
         tsajet2 := SUBSTR(c_Buffer, c_Start, c_End-c_Start);
         SAJET.SJ_CKSYS_EMP(tsajet2,tres);

         IF TRES = 'OK' THEN
            TRES := 'OK;OK;';
         ELSE
            TRES := 'NG;[EC201] EMP NO NG 1;'||' ['||tsajet2||']';
         END IF;
      ELSE
         TRES := 'NG;[EC201] EMP NO NG 2;';
      END IF;

   ELSIF cmd = 2
   THEN
      c_End := INSTR (c_Buffer, ';', 1, c_Number);

      IF (c_End-c_Start) <= 25 THEN
         tsajet2 := SUBSTR(c_Buffer, c_Start, c_End-c_Start);
         --SAJET.SJ_CKRT_SN(tsajet2, tres);
         SAJET.SJ_CKRT_SN_PSN(tsajet2, tres, c_PSN);
         If Tres = 'OK' Then
            --SAJET.SJ_CKRT_ROUTE(TTerminalid, tsajet2, tres);
            ----CHECK MI
            begin
              select Trim(param_value) into Check_Status from sys_base where param_name='Check MI' and rownum = 1;
              if (Check_Status='Y') then
                begin
                  select WORK_ORDER into C_WO from SAJET.G_SN_STATUS
                    where SERIAL_NUMBER=c_PSN and rownum =1;
                  select WO_SEQUENCE,STATUS into C_WO_SEQ,Msl_Status from SMT.G_WO_MSL
                    where WORK_ORDER=C_WO and rownum =1;
                exception
                  when others then
                    Msl_Status:='';
                end;
                if (Msl_Status = 'SMTLOADING') or (Msl_Status = 'SMTLOADOK') then
                 begin
                    TRES := 'OK';
                    select DATECODE into C_DATECODE from SMT.G_SMT_TRAVEL
                    where WO_SEQUENCE=C_WO_SEQ and Length(DATECODE)>6 and rownum =1;
                 EXCEPTION
                   WHEN OTHERS THEN
                    BEGIN
                      select DATECODE into C_DATECODE from SMT.G_SMT_STATUS
                      where WO_SEQUENCE=C_WO_SEQ and Length(DATECODE)>6 and rownum =1;
                    EXCEPTION
                      WHEN OTHERS THEN
                         TRES := 'MI not Load DateCode Length(8/9) ('||C_WO||')';
                    END;
                 END;
                elsif Msl_Status='' then
                     TRES := 'MSL not Create('||C_WO||')';
                else
                     TRES := 'MSL not Load ('||C_WO||')';
                end if;
                IF TRES<>'OK' THEN
                   T_TYPE := 'MI';  -- EVENT TYPE:  MI
                   BEGIN
                      SELECT TYPE_ID INTO C_TYPE FROM SAJET.ALARM_TYPE_BASE
                       WHERE TYPE_NAME = T_TYPE AND ENABLED = 'Y' AND ROWNUM = 1;
                      BEGIN
                        SELECT FACTORY_ID INTO C_FACTORY
                         FROM SAJET.SYS_PDLINE
                        WHERE PDLINE_ID = tlineid AND ROWNUM = 1;
                        SELECT Trim(PARAM_VALUE)||TO_CHAR(TNOW,'Y')||LPAD(SAJET.S_ALARM_CODE.NEXTVAL,6,0)
                          INTO C_EVENTID FROM SAJET.SYS_BASE
                         WHERE PARAM_NAME='DBID';
                        INSERT INTO SAJET.ALARM_EVENT
                          (EVENT_ID, EVENT_STATUS, TYPE_ID, EVENT_LEVEL,
                           FACTORY_ID, PDLINE_ID, STAGE_ID, PROCESS_ID, TERMINAL_ID,
                           EVENT_DESC, RECORD_TIME)
                          VALUES (C_EVENTID, 0, C_TYPE, 3,
                            C_FACTORY, tlineid, tstageid, tprocessid, TTerminalid, TRES, TNOW);
                      EXCEPTION
                       WHEN OTHERS THEN
                         TRES := 'INSERT ALARM_EVENT Error';
                      END;
                   EXCEPTION
                    WHEN OTHERS THEN
                      TRES := 'NO MI ALARM';
                   END;
                END IF;
              end if;
            exception
              when others then
              TRES := 'OK';
            end;
            IF TRES = 'OK' THEN
              SAJET.SJ_CKRT_ROUTE(TTerminalid, c_PSN, tres);
              IF TRES = 'OK' THEN
                 TRES := 'OK;OK;';
              ELSE
                 TRES := 'NG;[EC999] Route NG:'||TRES||';';
              END IF;
            END IF;
         ELSE
            TRES := 'NG;'||TRES||';';
         End If;
      ELSE
         TRES := 'NG;[EC202] SN NG2;';
      END IF;
   ELSIF cmd = 3
   THEN
      c_End := INSTR (c_Buffer, ';', 1, c_Number);

      IF (c_End-c_Start) <= 25 THEN
         tsajet2 := SUBSTR(c_Buffer, c_Start, c_End-c_Start);  -- GET EMP
         SAJET.SJ_CKSYS_EMP(tsajet2,tres);

                 -- INCREASE INDEX
         c_Number := c_Number + 1;
         c_Start := c_End + 1;

         IF TRES = 'OK' THEN    -- CHECK EMP OK
            c_End := INSTR (c_Buffer, ';', 1, c_Number);

            IF (c_End-c_Start) <= 25 THEN
               tsajet3 := SUBSTR(c_Buffer, c_Start, c_End-c_Start); -- GET SN
               --SAJET.SJ_CKRT_SN(tsajet3,tres);
               SAJET.SJ_CKRT_SN_PSN(tsajet3, tres, c_PSN);

                       -- INCREASE INDEX
               c_Number := c_Number + 1;
               c_Start := c_End + 1;
            ELSE
               TRES := 'NG;[EC202] SN NG3;';
            END IF;
         ELSE      -- CHECK EMP NG
            TRES := 'NG;[EC201] EMP NO NG;';
         END IF;

         IF TRES = 'OK' THEN    -- CHECK SN OK
            --SAJET.SJ_CKRT_ROUTE(TTerminalID,tsajet3,tres);
            SAJET.SJ_CKRT_ROUTE(TTerminalID,c_PSN,tres);

            IF TRES <> 'OK' THEN    -- CHECK ROUTE NG
               TRES := 'NG;[EC999] Route NG:'||TRES||';';
            END IF;
         ELSE      -- CHECK SN NG
            TRES := 'NG;'||TRES||';';
         END IF;

         If tres = 'OK' Then    -- CHECK ROUTE OK
            c_End := INSTR (c_Buffer, ';', 1, c_Number);
            IF (c_End-c_Start) = 2 THEN
               tsajet4 := SUBSTR(c_Buffer, c_Start, c_End-c_Start); -- GET RESULT

                       -- INCREASE INDEX
               c_Number := c_Number + 1;
               c_Start := c_End + 1;

               If tsajet4 = 'OK' Then
           --SAJET.SJ_Go(TTerminalID,tsajet3,tnow,tres,tsajet2);
                  SAJET.SJ_Go(TTerminalID,c_PSN,tnow,tres,tsajet2);

                  IF substr(TRES,1,2) = 'OK' THEN
                     TRES := 'OK;OK;';
                  ELSE
                     TRES := 'NG;[EC101] CALL DBA;';
                  END IF;
               Elsif tsajet4 = 'NG' Then
                  tsajet5ton := SUBSTR(c_Buffer, c_Start, LENGTH(c_Buffer)-c_Start)||';';
                  c_Number := 1;
                  c_Start := 1;
                  Loop
                     c_End := instr(tsajet5ton,';',1,c_Number);
                        Exit When c_End = 0;

                     c_Defect := Trim(Substr(tsajet5ton,c_Start,c_End - c_Start));
                     Sajet.Sj_CKSYS_Defect(c_Defect,Tres);
                     IF substr(TRES,1,2) <> 'OK' THEN
                        TRES := 'NG;[EC203] ERROR CODE NG;'||' ['||c_Defect||']';
                        EXIT;
                     END IF;

                     --Sajet.Sj_Nogo(TTerminalID, tsajet3,c_Defect,tnow,tres,tnextproc,tsajet2);
                     Sajet.Sj_Nogo(TTerminalID, c_PSN,c_Defect,tnow,tres,tnextproc,tsajet2);
                     IF substr(TRES,1,2) <> 'OK' THEN
                        TRES := 'NG;[EC101] CALL DBA;';
                        EXIT;
                     END IF;

                     c_Start := c_End + 1;
                     c_Number := c_Number + 1;
                  End Loop;

                  IF substr(TRES,1,2) = 'OK' then
                     TRES := 'OK;OK;';
                     Commit;
                  Else
                     RollBack;
                  End If;
               ELSE
                  TRES := 'NG;[EC101] RESULT NG;';
               End If;
            ELSE
               TRES := 'NG;[EC101] RESULT NG;';
            End If;

         End If;
      ELSE
         TRES := 'NG;[EC201] EMP NO NG;';
      END IF;

   --ELSIF cmd = 4
   --THEN

   ELSIF cmd = 5
   THEN
      SAJET.SJ_CKSYS_EMP(tsajet2,tres);
   If tres = 'OK' Then
      --SAJET.SJ_CKRT_SN(tsajet3,tres);
             SAJET.SJ_CKRT_SN_PSN(tsajet3, tres, c_PSN);
   End If;

   --If tres = 'OK' Then
      --SAJET.SJ_CKRT_ROUTE(TTerminalID,tsajet3,tres);
   --End If;

   If tres = 'OK' Then
   c_Number := 1;
   c_Start := 1;
   Loop
      c_End := Instr(tsajet4ton||';',';',1,c_Number);
   Exit When c_End = 0;
   c_Temp := Substr(tsajet4ton||';',c_Start,c_End - c_Start);
   If Instr(c_Temp,':',1,1) = 0 Then
      Tres := 'SPC [Item:Value] Format Error!';
      Exit;
   Else
      c_Item := Trim(Substr(c_Temp,1,Instr(c_Temp,':',1,1)-1));
      Sajet.SJ_CHK_SPC_Item(c_Item,Tres);
      Exit When Tres <> 'OK';

      begin
         c_Value := Trim(SubStr(c_Temp,Instr(c_Temp,':',1,1)+1, Length(c_Temp) - Instr(c_Temp,':',1,1)));
      exception
         When Others Then
         Tres := 'Test Value Error' || ' - ' || c_Value;
      Exit;
      end;

      --SAJET.SJ_INSERT_SPC_ITEM(c_item,tsajet3,c_value,tlineid,tstageid,tprocessid,tterminalid,tsajet2,tnow,tres);
      SAJET.SJ_INSERT_SPC_ITEM(c_item,c_PSN,c_value,tlineid,tstageid,tprocessid,tterminalid,tsajet2,tnow,tres);
                           Exit When Tres <> 'OK';
   End If;
      c_Start := c_End + 1;
   c_Number := c_Number + 1;
   End Loop;
   End If;
   ELSE
      TRES := 'NG;[EC102] COMMAND NOT DEFINE.;';
   END IF;
END;
/

