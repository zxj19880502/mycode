create view V_SN_TRAVEL_SIMPLE as
  select t."WORK_ORDER",t."SERIAL_NUMBER",t."PART_ID",t."VERSION",t."PROCESS_ID",t."CURRENT_STATUS",
  t."IN_PROCESS_TIME",t."WIP_IN_TIME",t."WIP_OUT_TIME",t."OUT_PROCESS_TIME",
  t."RC_NO",t."OUT_PDLINE_TIME",t."IN_PDLINE_TIME",t."WORK_FLAG",t."IN_PROCESS_SHIFT",t."OUT_PROCESS_SHIFT",
       to_char(out_process_time-8.5/24, 'yyyymmdd') output_date,
       to_char(t.in_process_time - 8.5/24, 'yyyymmdd') input_date,
       c.part_no,c.spec1,b.model_name,substr(b.model_name,4,4) sizespec,p.process_name,s.wo_type
  from sajet.g_sn_travel t,sajet.sys_part c,sajet.sys_model b, sajet.sys_process p,sajet.g_wo_base s
 where t.out_process_time is not null and c.part_id=t.part_id and b.model_id(+)=c.model_id and t.process_id = p.process_id(+) and t.work_order=s.work_order(+)
 union all
 select t."WORK_ORDER",t."SERIAL_NUMBER",t."PART_ID",t."VERSION",t."PROCESS_ID",t."CURRENT_STATUS",
  t."IN_PROCESS_TIME",t."WIP_IN_TIME",t."WIP_OUT_TIME",t."OUT_PROCESS_TIME",
  t."RC_NO",t."OUT_PDLINE_TIME",t."IN_PDLINE_TIME",t."WORK_FLAG",t."IN_PROCESS_SHIFT",t."OUT_PROCESS_SHIFT",
       to_char(out_process_time-8.5/24, 'yyyymmdd') output_date,
       to_char(t.in_process_time - 8.5/24, 'yyyymmdd') input_date,
       c.part_no,c.spec1,b.model_name,substr(b.model_name,4,4) sizespec,p.process_name,s.wo_type
  from sajet.g_sn_status t,sajet.sys_part c,sajet.sys_model b, sajet.sys_process p,sajet.g_wo_base s
 where t.out_process_time is null and c.part_id=t.part_id and b.model_id(+)=c.model_id and t.process_id = p.process_id(+) and t.work_order=s.work_order(+)


/

