create procedure bcf_panel_no(two    in varchar2
										,tvalue in varchar2
										,tqty   in number
										,tempid in number
										,tres   out varchar2) is
	c_count   number;
	i_qty     number;
	c_total   number;
	c_panel   sajet.g_sn_status.panel_no%type;
	c_part    sajet.g_wo_base.part_id%type;
	c_route   sajet.g_wo_base.route_id%type;
	c_version sajet.g_wo_base.version%type;
	c_sn      sajet.g_sn_status.serial_number%type;
	v_qty     number;
	b_single  boolean;
	v_prefix  varchar2(10);
	v_maxseq  number;
begin

	v_prefix := substr(two, 1, 7) || substr(two, length(two), 1);
	select nvl(option1, 1), a.part_id, a.route_id, a.version
	into   i_qty, c_part, c_route, c_version
	from   sajet.g_wo_base a, sajet.sys_part b
	where  a.work_order = two and a.part_id = b.part_id and rownum = 1;
	b_single := false;
	c_panel  := 'N/A';
	c_sn     := tvalue;
	/*if i_qty = 1 then
        c_panel  := 'N/A';
        b_single := true;
    else
        --？？？？？？？？？？SEQ
        select nvl(max(seq_no), 0) into v_maxseq from sajet.g_wo_panel where panel_no like v_prefix || '%';
    
        begin
            select panel_no, seq_no, acc_qty, total_qty
            into   c_panel, i_qty, c_count, c_total
            from   sajet.g_wo_panel a
            where  work_order = two and seq_no = (select max(seq_no) from sajet.g_wo_panel where work_order = two);
            if c_total = c_count then
                --I_QTY := I_QTY + 1;
                i_qty := v_maxseq + 1;
                --        C_PANEL := SUBSTR(TWO,1,8) || LPAD(TO_CHAR(I_QTY), 4, '0');
                c_panel := v_prefix || lpad(to_char(i_qty), 4, '0');
                insert into sajet.g_wo_panel
                    (work_order, panel_no, seq_no, total_qty, acc_qty, update_userid)
                values
                    (two, c_panel, i_qty, tqty, 0, tempid);
            end if;
        exception
            when others then
                --        C_PANEL := SUBSTR(TWO,1,8) || '0001';
                i_qty := v_maxseq + 1;
                --        C_PANEL := SUBSTR(TWO,1,8) || LPAD(TO_CHAR(I_QTY), 4, '0');
                c_panel := v_prefix || lpad(to_char(i_qty), 4, '0');
                insert into sajet.g_wo_panel
                    (work_order, panel_no, seq_no, total_qty, acc_qty, update_userid)
                values
                    (two, c_panel, i_qty, tqty, 0, tempid);
        end;
        update sajet.g_wo_panel set acc_qty = acc_qty + 1 where work_order = two and panel_no = c_panel and rownum = 1;
    
    end if;
    if b_single = true then
        c_sn := tvalue;
    else
        select count(*) into v_qty from sajet.g_sn_status where panel_no = c_panel;
        if v_qty = 0 then
            c_sn := c_panel || '01';
        else
            c_sn := c_panel || lpad(to_char(v_qty + 1), 2, '0');
        end if;
        begin
            insert into sajet.g_wo_sn (work_order, serial_number, emp_id) values (two, tvalue, tempid);
        exception
            when others then
                tres := 'OK';
        end;
    end if;*/

	insert into sajet.g_sn_status
		(work_order, serial_number, part_id, route_id, version, emp_id, panel_no, model_id)
	values
		(two, c_sn, c_part, c_route, c_version, tempid, c_panel, c_part);

	insert into sajet.g_wo_sn (work_order, serial_number, emp_id) values (two, tvalue, tempid);

	tres := 'OK';
	<<endp>>
	null;
exception
	when others then
		tres := 'Insert Fail.' || sqlerrm;
		rollback;
end;
/

