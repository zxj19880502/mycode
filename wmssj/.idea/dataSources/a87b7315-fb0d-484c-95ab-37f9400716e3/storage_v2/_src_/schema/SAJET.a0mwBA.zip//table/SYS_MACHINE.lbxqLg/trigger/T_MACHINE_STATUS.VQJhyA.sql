create trigger T_MACHINE_STATUS
  after insert
  on SYS_MACHINE
  for each row
DECLARE
  C_CURRENT_STAUTS_ID NUMBER;
  C_DOWN_STAUTS  NUMBER;
BEGIN
   C_CURRENT_STAUTS_ID := 0;
   C_DOWN_STAUTS := 0;
 INSERT INTO SAJET.G_MACHINE_STATUS
 ( machine_id,current_status_id,status_update_time,down_status,update_userid ）
 values
 （:NEW.MACHINE_ID,
 C_CURRENT_STAUTS_ID,
 SYSDATE,
  C_DOWN_STAUTS,
  :NEW.UPDATE_USERID
 ）;


EXCEPTION
  WHEN OTHERS THEN
     NULL;
END;


/

