create PROCEDURE Compare_Table_Cols2
is


      CURSOR TAB_COL IS
       select a.table_name,
        a.column_name,
        a.column_id,
        a.data_type,
        a.data_length,
        a.default_length,
        a.data_default
   from user_tab_cols a WHERE A.COLUMN_NAME in(
  select distinct column_name
    from user_tab_cols
   group by column_name
  having count(*) > 1 ) order by a.column_name  ;

  TAB_COL_RECORD TAB_COL%ROWTYPE;
  g_table_name varchar2(50);
  g_column_name varchar2(50);
  g_column_id number;
  g_data_type varchar(106);
  g_data_length number;
  g_default_length number;
  g_data_default varchar(150);
begin
    IF NOT TAB_COL%ISOPEN THEN
      OPEN TAB_COL;
    END IF;
  LOOP
    FETCH TAB_COL
      INTO TAB_COL_RECORD;
    EXIT WHEN TAB_COL%NOTFOUND OR TAB_COL%NOTFOUND IS NULL;

  if g_column_name<>TAB_COL_RECORD.column_name then
      g_table_name:=TAB_COL_RECORD.table_name;
      g_column_name:=TAB_COL_RECORD.column_name;
      g_column_id:= TAB_COL_RECORD.column_id;
      g_data_type:=TAB_COL_RECORD.data_type;
      g_data_length:=TAB_COL_RECORD.data_length;
      g_default_length:=TAB_COL_RECORD.default_length;
      g_data_default:=TAB_COL_RECORD.data_default;
  else
    if TAB_COL_RECORD.data_type <> g_data_type or
       TAB_COL_RECORD.data_length <> g_data_length  then
      --insert into 第一笔不一样数据
      insert into Com_tab_cols2
        (table_name,
         column_name,
         column_id,
         data_type,
         data_length,
         default_length)
      values
        (TAB_COL_RECORD.table_name,
         TAB_COL_RECORD.column_name,
         TAB_COL_RECORD.column_id,
         TAB_COL_RECORD.data_type,
         TAB_COL_RECORD.data_length,
         TAB_COL_RECORD.default_length);
         commit;
        --insert into 第二笔不一样数据
      insert into Com_tab_cols2
        (table_name,
         column_name,
         column_id,
         data_type,
         data_length,
         default_length)
      values
        (g_table_name,
         g_column_name,
         g_column_id,
         g_data_type,
         g_data_length,
         g_default_length);
         commit;
    end if;
      g_table_name:=TAB_COL_RECORD.table_name;
      g_column_name:=TAB_COL_RECORD.column_name;
      g_column_id:= TAB_COL_RECORD.column_id;
      g_data_type:=TAB_COL_RECORD.data_type;
      g_data_length:=TAB_COL_RECORD.data_length;
      g_default_length:=TAB_COL_RECORD.default_length;
      g_data_default:=TAB_COL_RECORD.data_default;
  end if;

end loop;
close TAB_COL;
end;


/

