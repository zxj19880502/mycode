create function fn_split(p_str       in varchar2
								   ,p_delimiter in varchar2)

 return ty_str_split
	pipelined is
	j    int := 0;
	i    int := 1;
	len  int := 0;
	len1 int := 0;
	str  varchar2(4000);
begin
	len  := length(p_str);
	len1 := length(p_delimiter);
	while j < len loop
		j := instr(p_str, p_delimiter, i);
		if j = 0 then
			j   := len;
			str := substr(p_str, i);
			pipe row(str);
			if i >= len then
				exit;
			end if;
		else
			str := substr(p_str, i, j - i);
			i   := j + len1;
			pipe row(str);
		end if;
	end loop;
	return;
end fn_split;


/

