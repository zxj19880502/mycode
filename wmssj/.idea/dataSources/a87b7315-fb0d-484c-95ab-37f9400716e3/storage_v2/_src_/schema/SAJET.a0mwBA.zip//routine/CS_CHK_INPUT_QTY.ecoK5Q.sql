create procedure       cs_chk_input_qty(two        in varchar2
												  ,tprocessid in number
												  ,tres       out varchar2) is
	c_pass   number;
	r_target number;
begin
	select nvl(sum(pass_qty), 0) into c_pass from sajet.g_sn_count where work_order = two and process_id = tprocessid;
	select target_qty into r_target from sajet.g_wo_base where work_order = two and rownum = 1;
	if r_target > c_pass then
		tres := 'OK';
	else
		tres := 'INPUT > TARGET';
	end if;
end;


/

