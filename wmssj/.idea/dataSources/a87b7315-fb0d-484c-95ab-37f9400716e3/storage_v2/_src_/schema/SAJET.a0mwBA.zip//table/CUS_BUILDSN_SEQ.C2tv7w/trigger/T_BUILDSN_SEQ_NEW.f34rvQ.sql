create trigger T_BUILDSN_SEQ_NEW
  before insert
  on CUS_BUILDSN_SEQ
  for each row
declare
	-- local variables here
begin
	select sys_guid() into :new.keyid from dual;
end t_buildsn_seq_new;


/

