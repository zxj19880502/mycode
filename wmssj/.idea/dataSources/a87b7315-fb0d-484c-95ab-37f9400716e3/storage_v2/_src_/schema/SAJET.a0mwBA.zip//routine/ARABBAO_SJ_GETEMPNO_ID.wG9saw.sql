create procedure       arabbao_sj_getempno_id(trev in varchar2
														,tres out varchar2) is
	c_emp varchar2(25);
begin
	select emp_name into c_emp from sajet.sys_emp where emp_id = trev and enabled = 'Y' and rownum = 1;
	tres := c_emp;
exception
	when others then
		tres := 'EMP ERR';
end;


/

