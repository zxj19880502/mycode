create procedure       csbg_transation_count(tlineid      in number
													   ,tstageid     in number
													   ,tprocessid   in number
													   ,temp         in number
													   ,tnow         in date
													   ,tsn          in varchar2
													   ,pwo          in varchar2
													   ,pmodelid     in number
													   ,flag         in number
													   ,tqty         in number
													   ,toutqty      in number
													   ,trework_flag in varchar2
													   ,tres         out varchar2) is
	cworkdate  varchar2(8);
	cworktime  number;
	crework    number;
	crowid     varchar2(25);
	line_no    number;
	cshiftid   number;
	coutputqty number;
	csn        sajet.g_sn_status.serial_number%type;
begin
	line_no   := 1;
	cworkdate := to_char(tnow, 'yyyymmdd');
	line_no   := 2;
	cworktime := sajet.sj_get_time_section(tnow);
	sajet.sj_get_pdline_shift(tlineid, cshiftid);
	/*
    begin
       line_no := 3;
       select rowid into crowid from sajet.g_sn_travel where work_order = pwo and serial_number = tsn and process_id = tprocessid and rownum = 1;
       crework := 1;
    exception
       when others then
          crework := 0;
    end;
    */
	crework := trework_flag;
	begin
		line_no := 4;
		select rowid
		into   crowid
		from   sajet.g_sn_count
		where  pdline_id = tlineid and stage_id = tstageid and process_id = tprocessid and shift_id = cshiftid and
			   work_order = pwo and part_id = pmodelid and work_date = cworkdate and work_time = cworktime and
			   rownum = 1;
	exception
		when others then
			crowid := '0';
	end;
	--NO REWORK
	if crework = 0 then
		if flag = 0 then
			if crowid = '0' then
				line_no := 5;
				insert into sajet.g_sn_count
					(work_order, part_id, pdline_id, stage_id, process_id, shift_id, work_date, work_time, pass_qty,
					 fail_qty, repass_qty, refail_qty, output_qty)
				values
					(pwo, pmodelid, tlineid, tstageid, tprocessid, cshiftid, cworkdate, cworktime, tqty, 0, 0, 0,
					 toutqty);
			else
				line_no := 6;
				update sajet.g_sn_count
				set    pass_qty = pass_qty + tqty, output_qty = output_qty + toutqty
				where  rowid = crowid;
			end if;
		else
			if crowid = '0' then
				line_no := 7;
				insert into sajet.g_sn_count
					(work_order, part_id, pdline_id, stage_id, process_id, shift_id, work_date, work_time, pass_qty,
					 fail_qty, repass_qty, refail_qty, output_qty)
				values
					(pwo, pmodelid, tlineid, tstageid, tprocessid, cshiftid, cworkdate, cworktime, 0, tqty, 0, 0, 0);
			else
				line_no := 8;
				update sajet.g_sn_count set fail_qty = fail_qty + tqty where rowid = crowid;
			end if;
		end if;
	else
		--REWORK
		if flag = 0 then
			/*
            --若之前沒有PASS 過,產量需增加
            begin
              select serial_number into csn from sajet.g_sn_travel where work_order = pwo and serial_number = tsn and process_id = tprocessid and current_status= 0 and rownum = 1;
                cOutputQty := 0;
            exception
              when others then
                cOutputQty := TQTY;
            end;
            */
			coutputqty := tqty;
			if crowid = '0' then
				line_no := 9;
				insert into sajet.g_sn_count
					(work_order, part_id, pdline_id, stage_id, process_id, shift_id, work_date, work_time, pass_qty,
					 fail_qty, repass_qty, refail_qty, output_qty)
				values
					(pwo, pmodelid, tlineid, tstageid, tprocessid, cshiftid, cworkdate, cworktime, 0, 0, tqty, 0,
					 toutqty);
			else
				line_no := 10;
				update sajet.g_sn_count
				set    repass_qty = repass_qty + tqty, output_qty = output_qty + toutqty
				where  rowid = crowid;
			end if;
		else
			if crowid = '0' then
				line_no := 11;
				insert into sajet.g_sn_count
					(work_order, part_id, pdline_id, stage_id, process_id, shift_id, work_date, work_time, pass_qty,
					 fail_qty, repass_qty, refail_qty, output_qty)
				values
					(pwo, pmodelid, tlineid, tstageid, tprocessid, cshiftid, cworkdate, cworktime, 0, 0, 0, tqty, 0);
			else
				line_no := 12;
				update sajet.g_sn_count set refail_qty = refail_qty + tqty where rowid = crowid;
			end if;
		end if;
	end if;
	tres := 'OK';
	<<endp>>
	null;
exception
	when others then
		tres := 'CSBG_transation_count error ' || cshiftid;
end;


/

