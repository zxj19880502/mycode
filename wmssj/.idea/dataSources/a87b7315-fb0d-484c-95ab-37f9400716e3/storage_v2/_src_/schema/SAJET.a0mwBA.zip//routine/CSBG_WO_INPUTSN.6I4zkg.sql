create procedure       csbg_wo_inputsn(trev in varchar2
												 ,two  in varchar2
												 ,temp in varchar2
												 ,tres out varchar2) is
	cempid   number;
	cstatus  varchar2(1);
	csn      sajet.g_sn_status.serial_number%type;
	cmodelid number;
	crouteid number;
	ctarget  number;
	ccnt     number;
	ccode    sajet.g_wo_param.parame_value%type;
	cdefault sajet.g_wo_param.parame_value%type;
begin
	/*====
       工單投入序號(不由Barcode Center 展序號)
       2005/04/14 CREATE
    ====*/
	sajet.sj_get_empid(temp, cempid);
	select wo_status, part_id, route_id, target_qty
	into   cstatus, cmodelid, crouteid, ctarget
	from   sajet.g_wo_base
	where  work_order = two and rownum = 1;
	begin
		select serial_number into csn from sajet.g_sn_status where serial_number = trev;
		tres := 'SN DUP';
		goto endp;
	exception
		when others then
			tres := 'OK';
	end;
	--檢查此工單數量是否允許再投入SN
	select count(*) into ccnt from sajet.g_sn_status where work_order = two;
	ccnt := ccnt + 1;
	if ccnt > ctarget then
		tres := 'WO FULL !!';
		goto endp;
	end if;
	--檢查是否符合序號規則----BEGIN-----
	select parame_value
	into   ccode
	from   sajet.g_wo_param
	where  work_order = two and module_name = 'SERIAL NUMBER RULE' and parame_name = 'Serial Number Code' and
		   parame_item = 'Code';
	select parame_value
	into   cdefault
	from   sajet.g_wo_param
	where  work_order = two and module_name = 'SERIAL NUMBER RULE' and parame_name = 'Serial Number Code' and
		   parame_item = 'Default';
	-- 序號長度
	if length(trev) <> length(ccode) then
		tres := 'SN LENGTH ERR!!';
		goto endp;
	end if;
	--固定碼
	for i in 1 .. length(ccode) loop
		if (substr(ccode, i, 1) = 'A') or (substr(ccode, i, 1) = 'C') or (substr(ccode, i, 1) = 'L') then
			if substr(trev, i, 1) <> substr(cdefault, i, 1) then
				tres := 'SN RULE NOT MATCH!!';
				goto endp;
			end if;
		end if;
	end loop;
	--------------------------END-------
	--INSERT SN_STATUS
	insert into sajet.g_sn_status
		(work_order, part_id, serial_number, route_id, emp_id)
	values
		(two, cmodelid, trev, crouteid, cempid);
	tres := 'OK (' || ccnt || ')';
	<<endp>>
	null;
exception
	when others then
		tres := 'CSBG_WO_INPUTSN ERR';
end;


/

