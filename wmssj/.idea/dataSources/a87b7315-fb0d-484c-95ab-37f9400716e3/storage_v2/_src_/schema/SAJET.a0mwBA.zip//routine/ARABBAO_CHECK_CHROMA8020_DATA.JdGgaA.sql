create procedure
-- ----------------
	-- mes.dll 5.0.2.25----Arabbao-20180620
	-- ----------------
 arabbao_check_chroma8020_data(tsajet1     in varchar2
							  ,tsajet2     in varchar2
							  ,tsajet3     in varchar2
							  ,tsajet4     in varchar2
							  ,tsajet5     in varchar2
							  ,tsajet6     in varchar2
							  ,tsajet7     in varchar2
							  ,tsajet8     in varchar2
							  ,tsajet9     in varchar2
							  ,tsajet10    in varchar2
							  ,tsajet11    in varchar2
							  ,tlineid     in varchar2
							  ,tstageid    in varchar2
							  ,tprocessid  in varchar2
							  ,tterminalid in varchar2
							  ,temp        in out varchar2
							  ,tres        out varchar2) as
	c_emp_id       varchar(40);
	c_wo           varchar2(40);
	c_model        varchar2(40);
	c_part_id      varchar2(40);
	c_psn          varchar2(40);
	outprocesstime date;
	time_diff      number;
begin
	tres := 'OK';

	if tres = 'OK' then
		begin
			if tsajet1 = '1' then
				begin
					sajet.tm_check_emp(tsajet2, tsajet3, tres);
					if substr(tres, 1, 2) = 'OK' then
						select emp_id into c_emp_id from sajet.sys_emp where emp_no = tsajet2 and rownum = 1;
						temp := tsajet2;
						tres := 'OK' || chr(27) || tsajet1 || chr(27) || c_emp_id;
					end if;
				exception
					when others then
						tres := 'EXECUTE CHAROM DATA ERROR(EMP)';
				end;
			elsif tsajet1 = '2' then
				begin
					sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
					if substr(tres, 1, 2) = 'OK' then
						select out_process_time into outprocesstime from g_sn_status where serial_number = c_psn;
						select (sysdate - outprocesstime) * 24 into time_diff from dual;
						if time_diff > 17 then
							sajet.tm_check_sn(c_psn, tres, c_wo);
							if substr(tres, 1, 2) = 'OK' then
								sajet.sj_ckrt_route(tterminalid, c_psn, tres);
								if substr(tres, 1, 2) = 'OK' then
									select a.work_order, b.part_no, a.part_id
									into   c_wo, c_model, c_part_id
									from   sajet.g_wo_base a, sajet.sys_part b
									where  a.work_order = c_wo and a.part_id = b.part_id;
								
									tres := 'OK' || chr(27) || tsajet1 || chr(27) || tsajet2 || chr(27) || c_wo ||
											chr(27) || c_model || chr(27) || c_part_id || chr(27) || c_psn;
								end if;
							end if;
						else
							tres := 'PLEASE TIME_DIFF 17H';
						end if;
					end if;
				exception
					when others then
						tres := 'EXECUTE CHAROM DATA ERROR(SN)';
				end;
			elsif tsajet1 = '3' then
				--SAJET.SJ_CKRT_SN_PSN(TSAJET2, TRES, C_PSN);
				sajet.sj_ckrt_route(tterminalid, tsajet2, tres);
				if substr(tres, 1, 2) = 'OK' then
					--SAJET.TM_TEST_RESULT(TSAJET2,TSAJET3,TSAJET4,TRES);
					--
					sajet.tm_test_result(tsajet2, tterminalid, tsajet4, temp, tres);
					--
					if substr(tres, 1, 2) = 'OK' then
						tres := 'OK' || chr(27) || tsajet1 || chr(27);
					end if;
				end if;
			elsif tsajet1 = '4' then
				--SAJET.SJ_CKRT_SN_PSN(TSAJET3, TRES, C_PSN);
				sajet.tm_test_value(tsajet2, tsajet3, tsajet4, tsajet5, tsajet6, tsajet7, tsajet8, tsajet9, tsajet10,
									tsajet11, tlineid, tstageid, tprocessid, tterminalid, tres);
				if substr(tres, 1, 2) = 'OK' then
					tres := 'OK' || chr(27) || tsajet1 || chr(27);
				end if;
			elsif tsajet1 = '5' then
				--SAJET.SJ_CKRT_SN_PSN(TSAJET2, TRES, C_PSN);
				if substr(tres, 1, 2) = 'OK' then
					sajet.tm_download_tp(tsajet1, tsajet2, tterminalid, tres);
				end if;
			elsif tsajet1 = '6' then
				tres := 'OK' || chr(27) || tsajet1 || chr(27) || tlineid || chr(27) || tstageid || chr(27) ||
						tprocessid || chr(27) || tterminalid || chr(27);
			else
				tres := 'UNKNOW COMMAND NO - ' || tsajet1;
			end if;
		exception
			when others then
				tres := 'EXECUTE CHAROM DATA ERROR(UNKNOW)';
			
		end;
	end if;
end;


/

