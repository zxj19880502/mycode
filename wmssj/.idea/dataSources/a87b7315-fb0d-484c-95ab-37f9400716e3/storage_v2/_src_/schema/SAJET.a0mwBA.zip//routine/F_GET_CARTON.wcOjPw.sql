create function f_get_carton(spallet_no in varchar2
									   ,srownum    in number) return varchar2 is
	carton1 varchar2(50);
	ccount  number;
begin
	select distinct count(distinct carton_no) into ccount from sajet.g_sn_status a where pallet_no = spallet_no;
	if srownum > ccount then
		carton1 := '';
		goto endp;
	end if;
	select carton_no
	into   carton1
	from   (select rownum as rn, b.carton_no
			 from   (select distinct carton_no from sajet.g_sn_status a where pallet_no = spallet_no order by carton_no) b)
	
	where  rn = srownum;
	<<endp>>
	return carton1;
exception
	when others then
		return sqlerrm;
end;
/

