create procedure       csbg_chk_wo_inputsn(trev in varchar2
													 ,tres out varchar2) is
	cnt     number;
	cworule sajet.g_wo_base.wo_rule%type;
begin
	--檢查工單狀態
	sajet.sj_chk_wo_input(trev, tres);
	--WO RULE
	select count(*) into cnt from sajet.g_wo_param where work_order = trev;
	if cnt = 0 then
		select wo_rule into cworule from sajet.g_wo_base where work_order = trev;
		insert into sajet.g_wo_param
			select trev work_order, b.*
			from   sajet.sys_module_param a, sajet.sys_module_param b
			where  a.module_name = 'W/O RULE' and a.function_name = cworule and a.parame_name = 'Serial Number Rule' and
				   a.parame_item = b.function_name and b.module_name = 'SERIAL NUMBER RULE';
		insert into sajet.g_wo_param
			select trev work_order, b.*
			from   sajet.sys_module_param a, sajet.sys_module_param b
			where  a.module_name = 'W/O RULE' and a.function_name = cworule and a.parame_name = 'Carton No Rule' and
				   a.parame_item = b.function_name and b.module_name = 'CARTON NO RULE';
		insert into sajet.g_wo_param
			select trev work_order, b.*
			from   sajet.sys_module_param a, sajet.sys_module_param b
			where  a.module_name = 'W/O RULE' and a.function_name = cworule and a.parame_name = 'Pallet No Rule' and
				   a.parame_item = b.function_name and b.module_name = 'PALLET NO RULE';
		insert into sajet.g_wo_param
			select trev work_order, b.*
			from   sajet.sys_module_param a, sajet.sys_module_param b
			where  a.module_name = 'W/O RULE' and a.function_name = cworule and a.parame_name = 'Customer SN Rule' and
				   a.parame_item = b.function_name and b.module_name = 'CUSTOMER SN RULE';
	end if;
exception
	when others then
		tres := 'CSBG_CHK_WO_INPUTSN ERR';
end;


/

