create function       Convert_Ten_To_DEC(Ten in number,TCHAR in varchar2) return varchar2 is
--10???33??(10????26????I.O.S???)
stt varchar2(12) ;--33?????
sremainder varchar2(2);--??
nremainder number;
squotient varchar2(2);--?
nquotient number;
bytes varchar2(36);
i number;
iDec number;
cchar varchar2(2);
begin
  bytes:='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

   for i in 1..Length(TCHAR)
   loop
       cchar:=substr(TCHAR,i,1);
       bytes:=replace(bytes,cchar,'');
   end loop;
  bytes:=TRIM(bytes);
  iDec:=Length(bytes);
  --s33d:='N/A';
  if Ten<=0 then
    return '0';
  elsif Ten>=iDec then
  begin
    nquotient:=trunc(Ten/iDec);
    nremainder:=mod(Ten,iDec);
    sremainder:=substr(bytes,nremainder+1,1);
    stt:=sremainder||stt;
    stt:=Convert_Ten_To_DEC(nquotient,TCHAR)||stt;
    exception
      when others then
      return '0';
    end;
  else
    stt:=substr(bytes,Ten+1,1)||stt;
    end if;
    --if stt!='0'then
    --  stt:=lpad(stt,bitlength,'0');
    --  end if;
return stt;
end;


/

