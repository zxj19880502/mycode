create view V_PROCESS as
select decode(process_name,'MOCVD','01-MOCVD','雷刻','02-雷刻','检测','03-检测',process_name) process_name_order,process_id,
       --process_name||'-'||process_desc process_name_display,
       process_name/*,
       process_desc */
  from sajet.sys_process
       where enabled='Y'


/

