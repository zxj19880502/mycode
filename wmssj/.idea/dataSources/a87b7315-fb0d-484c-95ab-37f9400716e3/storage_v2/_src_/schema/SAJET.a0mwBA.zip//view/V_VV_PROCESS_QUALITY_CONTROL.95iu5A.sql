create view V_VV_PROCESS_QUALITY_CONTROL as
select t.start_time,t.QC_LOTNO,t.SERIAL_NUMBER,t.process_name,t.粒径D10,
t.粒径D50,
t.密度,t.黏度,t.水分,t.温度,t.PH值,t.电导率,t.流时,t.qcresult from
((select t.start_time,t.QC_LOTNO,t.SERIAL_NUMBER,t.process_name,t.info1 粒径D10,t.info2 粒径D50,
null 密度,t.info3 黏度,t.info7 水分,t.info4 温度,t.info5 PH值,t.info6 电导率,null 流时,t.qcresult
from
(SELECT b.start_time,A.QC_LOTNO, A.SERIAL_NUMBER, b.process_name,
max(decode(a.item_id, '10000128', a.information)) info1,
max(decode(a.item_id, '10000129', a.information)) info2,
max(decode(a.item_id, '10000130', a.information)) info3,
max(decode(a.item_id, '10000131', a.information)) info4,
max(decode(a.item_id, '10000132', a.information)) info5,
max(decode(a.item_id, '10000133', a.information)) info6,
max(decode(a.item_id, '10000134', a.information)) info7,a.qcresult
  FROM
  sajet.g_qc_lot_test_item a,
(select h.QC_LOTNO,h.SERIAL_NUMBER,h.PROCESS_NAME,h.lot_memo,h.start_time from
(SELECT distinct A.QC_LOTNO,A.SERIAL_NUMBER,G.PROCESS_NAME,b.lot_memo,b.start_time
FROM sajet.g_qc_lot_test_item a,sajet.g_qc_lot b,
sajet.sys_test_item_type e,sajet.sys_test_item f,sajet.sys_process g
WHERE a.qc_lotno=b.qc_lotno AND b.process_id=g.process_id AND a.item_type_id=e.item_type_id
AND a.item_id=f.item_id AND G.PROCESS_ID=100001
ORDER BY A.QC_LOTNO,A.SERIAL_NUMBER)h,
(SELECT serial_number, MAX(qc_lotno) AS qc_lotno FROM sajet.g_qc_lot_test_item
where qc_lotno<>'N/A'
GROUP BY serial_number)j
where h.QC_LOTNO=j.QC_LOTNO and h.SERIAL_NUMBER=j.SERIAL_NUMBER)b
 WHERE a.qc_lotno = b.qc_lotno
   and a.serial_number=b.serial_number
group by b.start_time,A.QC_LOTNO, A.SERIAL_NUMBER, b.process_name,a.qcresult)t)
union all
(select t.start_time,t.QC_LOTNO,t.SERIAL_NUMBER,t.process_name,null,
t.info8 粒径D50,t.info9 密度,t.info10 黏度,t.info11 水分,t.info12 温度,t.info13 PH值,t.info14 电导率,null 流时,
t.qcresult
from
(SELECT b.start_time,A.QC_LOTNO, A.SERIAL_NUMBER, b.process_name,
max(decode(a.item_id, '10000135', a.information)) info8,
max(decode(a.item_id, '10000136', a.information)) info9,
max(decode(a.item_id, '10000137', a.information)) info10,
max(decode(a.item_id, '10000138', a.information)) info11,
max(decode(a.item_id, '10000139', a.information)) info12,
max(decode(a.item_id, '10000140', a.information)) info13,
max(decode(a.item_id, '10000141', a.information)) info14,a.qcresult
  FROM
  sajet.g_qc_lot_test_item a,
(select h.QC_LOTNO,h.SERIAL_NUMBER,h.PROCESS_NAME,h.lot_memo,h.start_time from
(SELECT distinct A.QC_LOTNO,A.SERIAL_NUMBER,G.PROCESS_NAME,b.lot_memo,b.start_time
FROM sajet.g_qc_lot_test_item a,sajet.g_qc_lot b,
sajet.sys_test_item_type e,sajet.sys_test_item f,sajet.sys_process g
WHERE a.qc_lotno=b.qc_lotno AND b.process_id=g.process_id AND a.item_type_id=e.item_type_id
AND a.item_id=f.item_id AND G.PROCESS_ID =100003
ORDER BY A.QC_LOTNO,A.SERIAL_NUMBER)h,
(SELECT serial_number, MAX(qc_lotno) AS qc_lotno FROM sajet.g_qc_lot_test_item
where qc_lotno<>'N/A'
GROUP BY serial_number)j
where h.QC_LOTNO=j.QC_LOTNO and h.SERIAL_NUMBER=j.SERIAL_NUMBER)b
 WHERE a.qc_lotno = b.qc_lotno
   and a.serial_number=b.serial_number
group by b.start_time,A.QC_LOTNO, A.SERIAL_NUMBER, b.process_name,a.qcresult)t)
union all
(select t.start_time,t.QC_LOTNO,t.SERIAL_NUMBER,t.process_name,null,null,t.info18 密度,t.info19 黏度
,t.info20 水分,t.info17 温度,t.info16 PH值,t.info15 电导率,t.info21 流时,t.qcresult
from
(SELECT b.start_time,A.QC_LOTNO, A.SERIAL_NUMBER, b.process_name,
max(decode(a.item_id, '10000142', a.information)) info15,
max(decode(a.item_id, '10000143', a.information)) info16,
max(decode(a.item_id, '10000144', a.information)) info17,
max(decode(a.item_id, '10000145', a.information)) info18,
max(decode(a.item_id, '10000146', a.information)) info19,
max(decode(a.item_id, '10000147', a.information)) info20,
max(decode(a.item_id, '10000148', a.information)) info21,a.qcresult
  FROM
  sajet.g_qc_lot_test_item a,
(select h.QC_LOTNO,h.SERIAL_NUMBER,h.PROCESS_NAME,h.lot_memo,h.start_time from
(SELECT distinct A.QC_LOTNO,A.SERIAL_NUMBER,G.PROCESS_NAME,b.lot_memo,b.start_time
FROM sajet.g_qc_lot_test_item a,sajet.g_qc_lot b,
sajet.sys_test_item_type e,sajet.sys_test_item f,sajet.sys_process g
WHERE a.qc_lotno=b.qc_lotno AND b.process_id=g.process_id AND a.item_type_id=e.item_type_id
AND a.item_id=f.item_id AND G.PROCESS_ID =100007
ORDER BY A.QC_LOTNO,A.SERIAL_NUMBER)h,
(SELECT serial_number, MAX(qc_lotno) AS qc_lotno FROM sajet.g_qc_lot_test_item
where qc_lotno<>'N/A'
GROUP BY serial_number)j
where h.QC_LOTNO=j.QC_LOTNO and h.SERIAL_NUMBER=j.SERIAL_NUMBER)b
 WHERE a.qc_lotno = b.qc_lotno
   and a.serial_number=b.serial_number
group by b.start_time,A.QC_LOTNO, A.SERIAL_NUMBER, b.process_name,a.qcresult)t))t


/

