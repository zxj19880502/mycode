create FUNCTION get_rc_sr_id RETURN nvarchar2 IS
auto_id nvarchar2(20);
v_id nvarchar2(20);

begin
select max(substr(nvl(auto_id,'10000'),9,5)) into v_id 
from SAJET.G_RC_sr_main 
where substr(nvl(auto_id,to_char(sysdate,'yyyymmdd')),1,8)=to_char(sysdate,'yyyymmdd');
if v_id is null then
auto_id:=to_number(to_char(sysdate,'yyyymmdd')||10000);
else
auto_id:=to_number(to_char(sysdate,'yyyymmdd')||v_id+1);
end if;
return auto_id;
end;


/

