create procedure       csbg_chk_tooling_used(ttool_snid in number
													   ,tres       out varchar2
													   ,sres       out varchar2
													   ,p_toolsn   out varchar2) is
	cday          number;
	c_usedcount   number;
	c_max_count   number;
	c_limit_count number;
	cusedtime     number;
begin
	sres := 'N/A';
	--CHECK TOOLING 使用次數
	select used_count, trunc((sysdate - nvl(last_maintain_time, sysdate)))
	into   c_usedcount, cday
	from   sajet.g_tooling_sn_status
	where  tooling_sn_id = ttool_snid;
	select b.tooling_sn, nvl(a.max_used_count, 0), nvl(a.limit_used_count, 0), nvl(used_time, 0)
	into   p_toolsn, c_max_count, c_limit_count, cusedtime
	from   sajet.sys_tooling a, sajet.sys_tooling_sn b
	where  b.tooling_sn_id = ttool_snid and a.tooling_id = b.tooling_id;
	--超過可使用次數
	if (c_limit_count > 0) and (c_usedcount >= c_limit_count) then
		tres := 'OVER LIMIT';
		goto endp;
	end if;
	--超過警告次數
	if (c_max_count > 0) and (c_usedcount >= c_max_count) then
		sres := 'OVER MAX';
	end if;
	--是否超過可使用時間
	if (cusedtime <> 0) and (cday >= cusedtime) then
		tres := 'OVER DAYS';
		goto endp;
	end if;
	tres := 'OK';
	<<endp>>
	null;
end;


/

