create procedure       csbg_defect_input(tlineid     in number
												   ,tstageid    in number
												   ,tprocessid  in number
												   ,tterminalid in number
												   ,tsn         in varchar2
												   ,tdefect     in varchar2
												   ,tnow        in date
												   ,tempid      in varchar2
												   ,two         in varchar2
												   ,tmodelid    in number
												   ,tdefectqty  in number) is
	cdefectid number;
	crecid    number;
begin
	sajet.sj_get_defectid(tdefect, cdefectid);
	select to_char(tnow, 'YYYYMMDD') || lpad(sajet.s_def_code.nextval, 5, '0') into crecid from dual;
	insert into sajet.g_sn_defect
		(recid, serial_number, work_order, part_id, rec_time, defect_id, terminal_id, process_id, stage_id, pdline_id,
		 test_emp_id, defect_qty)
	values
		(crecid, tsn, two, tmodelid, tnow, cdefectid, tterminalid, tprocessid, tstageid, tlineid, tempid, tdefectqty);
end;


/

