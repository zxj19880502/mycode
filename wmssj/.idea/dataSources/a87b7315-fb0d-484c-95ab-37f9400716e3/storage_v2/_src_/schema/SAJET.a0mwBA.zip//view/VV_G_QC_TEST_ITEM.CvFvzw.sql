create view VV_G_QC_TEST_ITEM as
select g.times,g.QC_LOTNO,g.SERIAL_NUMBER,g.PROCESS_NAME,
g.defect_code,g.defect_code1,g.status,g.defect_code2,g.lot_memo from
(select h.times,h.QC_LOTNO,h.SERIAL_NUMBER,h.PROCESS_NAME,
h.defect_code,h.defect_code1,h.status,j.defect_code defect_code2,h.lot_memo,h.work_order from
(select x.QC_LOTNO,x.SERIAL_NUMBER,x.PROCESS_NAME,x.lot_memo,x.times,
x.defect_code,x.defect_code1,y.status,y.work_order from
(select m.QC_LOTNO,m.SERIAL_NUMBER,m.PROCESS_NAME,m.lot_memo,m.times,
n.defect_code,o.defect_code defect_code1 from
sajet.vv_g_qc_lot_test m,
(select f.serial_number,b.defect_code from
sajet.g_sn_defect a,
sajet.sys_defect b,
(select p.serial_number,min(p.recid) recid from
(select a.serial_number,a.defect_id,b.defect_code,a.recid from
sajet.g_sn_defect a,
sajet.vv_g_qc_lot_test m,
sajet.sys_defect b
where m.serial_number=a.serial_number and a.process_id='100026' and a.defect_id=b.defect_id(+)
and a.rp_status<>1)p
group by p.serial_number)f
where a.serial_number=f.serial_number and a.recid=f.recid and a.defect_id=b.defect_id(+)) n,
(select f.serial_number,b.defect_code from
sajet.g_sn_defect a,
sajet.sys_defect b,
(select p.serial_number,max(p.recid) recid from
(select a.serial_number,a.defect_id,b.defect_code,a.recid from
sajet.g_sn_defect a,
sajet.vv_g_qc_lot_test m,
sajet.sys_defect b
where m.serial_number=a.serial_number and a.process_id='100026' and a.defect_id=b.defect_id(+))p
group by p.serial_number)f
where a.serial_number=f.serial_number and a.recid=f.recid and a.defect_id=b.defect_id(+))o
where m.SERIAL_NUMBER=n.SERIAL_NUMBER(+) and m.SERIAL_NUMBER=o.SERIAL_NUMBER(+))x,
(select to_char(a.out_process_time-8.5/24,'yyyy-mm-dd') times,a.work_order,a.serial_number,decode(a.current_status,0,'合格',1,'报废',2,'合格',4,'返工') status from
sajet.g_sn_travel a,
(select a.serial_number,a.out_process_time from
(select to_char(a.out_process_time-8.5/24,'yyyy-mm-dd') times,a.SERIAL_NUMBER,max(a.out_process_time) out_process_time from
sajet.g_sn_travel a
where a.process_id=100026
group by to_char(a.out_process_time-8.5/24,'yyyy-mm-dd'),a.SERIAL_NUMBER) a,
sajet.vv_g_qc_lot_test b
where a.serial_number=b.serial_number
and b.times=a.times)p
where a.serial_number=p.serial_number and a.out_process_time=p.out_process_time and a.process_id='100026')y
where x.serial_number=y.serial_number(+) and x.times=y.times(+))h,
(select f.serial_number,b.defect_code from
sajet.g_sn_defect a,
sajet.sys_defect b,
(select p.serial_number,max(p.recid) recid from
(select a.serial_number,a.defect_id,b.defect_code,a.recid from
sajet.g_sn_defect a,
sajet.vv_g_qc_lot_test m,
sajet.sys_defect b
where m.serial_number=a.serial_number and a.process_id='100026' and a.defect_id=b.defect_id(+)
and a.rp_status=1)p
group by p.serial_number)f
where a.serial_number=f.serial_number and a.recid=f.recid and a.defect_id=b.defect_id(+))j
where h.serial_number=j.serial_number(+))g,
sajet.g_wo_base f
where g.work_order=f.work_order and f.wo_type in ('正常工单','实验工单','内返工单','客返工单')


/

