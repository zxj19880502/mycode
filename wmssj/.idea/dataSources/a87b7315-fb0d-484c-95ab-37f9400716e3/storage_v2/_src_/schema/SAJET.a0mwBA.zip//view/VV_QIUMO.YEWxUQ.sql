create view VV_QIUMO as
select times,shift,sum(qty1) qty1 from
(select to_char(a.in_process_time-8.5/24,'yyyy-mm-dd') times,sajet.worksshifet_param(a.in_process_time-8.5/24) shift,
sum(a.wip_in_qty) qty1 from
sajet.g_rc_travel a
where a.process_id='100001'
group by to_char(a.in_process_time-8.5/24,'yyyy-mm-dd'),sajet.worksshifet_param(a.in_process_time-8.5/24)
union all
select to_char(a.in_process_time-8.5/24,'yyyy-mm-dd') times,sajet.worksshifet_param(a.in_process_time-8.5/24) shift,
sum(a.wip_in_qty) qty1 from
sajet.g_rc_status a
where a.process_id='100001' and a.out_process_time is null
group by to_char(a.in_process_time-8.5/24,'yyyy-mm-dd'),sajet.worksshifet_param(a.in_process_time-8.5/24))
group by times,shift


/

