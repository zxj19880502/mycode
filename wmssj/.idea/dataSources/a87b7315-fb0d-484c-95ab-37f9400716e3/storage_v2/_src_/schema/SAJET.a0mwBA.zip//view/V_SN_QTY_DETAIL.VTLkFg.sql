create view V_SN_QTY_DETAIL as
  select S.WORK_ORDER,B.PART_NO,e.route_name,P.PROCESS_NAME,sum(s.GOOD_QTY+S.SCRAP_QTY) WIP_QTY,B.PART_ID,P.PROCESS_ID,S.SERIAL_NUMBER,
       '待产出' 生产阶段,
DECODE(S.CURRENT_STATUS,0,'正常',1,'报废',2,'异常放行',3,'锁定',4,'重工') 状态
    FROM SAJET.G_SN_STATUS S,
         sajet.sys_rc_route e,
         sajet.sys_part b,
         sajet.g_wo_base C,
         sajet.SYS_PROCESS P
    WHERE S.PART_ID=B.PART_ID
    AND S.PROCESS_ID=P.PROCESS_ID
    AND S.ROUTE_ID=E.ROUTE_ID
    and S.WORK_ORDER=C.WORK_ORDER
    and c.WO_OPTION2 in ('2','3')
    AND S.IN_PROCESS_TIME is not null AND S.OUT_PROCESS_TIME is null--'待产出'
    GROUP BY S.WORK_ORDER,B.PART_NO,e.route_name,P.PROCESS_NAME,B.PART_ID,P.PROCESS_ID,S.SERIAL_NUMBER,S.CURRENT_STATUS,S.IN_PROCESS_TIME,S.OUT_PROCESS_TIME
    union all
     select S.WORK_ORDER,B.PART_NO,e.route_name,P.PROCESS_NAME,sum(s.GOOD_QTY+S.SCRAP_QTY) WIP_QTY,B.PART_ID,P.PROCESS_ID,S.SERIAL_NUMBER,
     '待投入' 生产阶段,
DECODE(S.CURRENT_STATUS,0,'正常',1,'报废',2,'异常放行',3,'锁定',4,'重工') 状态
    FROM SAJET.G_SN_STATUS S,
         sajet.sys_rc_route e,
         sajet.sys_part b,
         sajet.g_wo_base C,
         sajet.SYS_PROCESS P
    WHERE S.PART_ID=B.PART_ID
    AND S.NEXT_PROCESS=P.PROCESS_ID
    AND S.ROUTE_ID=E.ROUTE_ID
    and S.WORK_ORDER=C.WORK_ORDER
    and c.WO_OPTION2 in ('2','3')
    and S.CURRENT_STATUS!=1--没有报废
    AND S.IN_PROCESS_TIME is not null AND S.OUT_PROCESS_TIME is NOT null--'待投入'
    GROUP BY S.WORK_ORDER,B.PART_NO,e.route_name,P.PROCESS_NAME,B.PART_ID,P.PROCESS_ID,S.SERIAL_NUMBER,S.CURRENT_STATUS,S.IN_PROCESS_TIME,S.OUT_PROCESS_TIME
    /*UNION ALL
    select S.WORK_ORDER,B.PART_NO,e.route_name,P.PROCESS_NAME,sum(s.GOOD_QTY+S.SCRAP_QTY) WIP_QTY,B.PART_ID,P.PROCESS_ID,S.SERIAL_NUMBER,
    '已产出' 生产阶段,
DECODE(S.CURRENT_STATUS,0,'正常',1,'报废',2,'异常放行',3,'锁定',4,'重工') 状态
    FROM SAJET.G_SN_STATUS S,
         sajet.sys_rc_route e,
         sajet.sys_part b,
         sajet.g_wo_base C,
         sajet.SYS_PROCESS P
    WHERE S.PART_ID=B.PART_ID
    AND S.PROCESS_ID=P.PROCESS_ID
    AND S.ROUTE_ID=E.ROUTE_ID
    and S.WORK_ORDER=C.WORK_ORDER
    and c.WO_OPTION2 in ('2','3')
    and S.CURRENT_STATUS=1
    AND S.IN_PROCESS_TIME is not null AND S.OUT_PROCESS_TIME is NOT null
    GROUP BY S.WORK_ORDER,B.PART_NO,e.route_name,P.PROCESS_NAME,B.PART_ID,P.PROCESS_ID,S.SERIAL_NUMBER,S.CURRENT_STATUS,S.IN_PROCESS_TIME,S.OUT_PROCESS_TIME
;*/

 
 
 
 
 

