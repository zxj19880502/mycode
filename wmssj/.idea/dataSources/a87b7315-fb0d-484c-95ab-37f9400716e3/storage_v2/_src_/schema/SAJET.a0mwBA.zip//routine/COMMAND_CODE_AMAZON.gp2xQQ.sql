create procedure command_code_amazon(tlineid     in number
											   ,tstageid    in number
											   ,tprocessid  in number
											   ,tterminalid in number
											   ,tnow        in date
											   ,trev        in varchar2
											   ,tres        out varchar2
											   ,tnextproc   out varchar2) is
	tsajet1      varchar2(25);
	tsajet2      varchar2(40);
	tsajet3      varchar2(256);
	tsajet4      varchar2(256);
	tsajet4ton   varchar2(4096);
	tsajet5ton   varchar2(4096);
	c_buffer     varchar2(4096);
	c_head       number;
	cmd          number;
	c_number     number;
	c_start      number;
	c_end        number;
	c_psn        varchar2(35);
	c_temp       varchar2(255);
	c_item       sajet.sys_spc.spc_item%type;
	c_value      sajet.g_spc.spc_value%type;
	c_defect     sajet.sys_defect.defect_code%type;
	c_wo         sajet.g_sn_status.work_order%type;
	c_wo_seq     smt.g_wo_msl.wo_sequence%type;
	c_datecode   smt.g_smt_status.datecode%type;
	c_dbid       varchar2(20);
	c_type       number;
	c_eventid    number;
	t_type       varchar2(25);
	check_status varchar2(10);
	msl_status   varchar2(30);
	c_factory    number;
	cnt          number;
	cnt2         number;
	cvalue       number;
begin
	tres := 'Fail,Command fail';
	/*   IF SUBSTR(TREV, LENGTH(TREV), 1) = ';' THEN
       c_Buffer := TREV;
    ELSE
       c_Buffer := TREV || ';';
    END IF;

    c_Number := 1;
    c_Start := 1;
    c_End := INSTR (c_Buffer, ';', c_Start, c_Number);

    IF C_End <= 3 THEN
    BEGIN
       cmd := SUBSTR(c_Buffer, c_Start, C_End-c_Start);
       c_Number := c_Number + 1;
       c_Start := c_End + 1;
    EXCEPTION
       WHEN OTHERS THEN
          cmd := 999;
    END;
    ELSE
       cmd := 999;
    END IF;*/
	select count(*) into cnt from table(f_cus_split(trev, ';'));
	cmd := to_number(trim(f_cus_splitstr(trev, 1, ';'))); --獲取cmd

	if cmd = 1 --檢查用戶
	 then
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;PWD]' || trev || '[' || cnt || ']';
			--TRES := 'NG;[EC201] EMP NO NG 2;';
		else

			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';'));

			sajet.sj_cksys_emp(tsajet2, tres);
			if tres = 'OK' then
				select trim(password.decrypt(passwd)) into c_temp from sajet.sys_emp where emp_no = tsajet2;
				if c_temp <> tsajet3 then
					tres := 'NG;密碼錯誤!';
				else
					tres := 'OK;OK;';
				end if;
			else
				--TRES := 'NG;[EC201] EMP NO NG 1;'||' ['||tsajet2||']';
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 2 --檢查工單,并檢查投入數是否已滿
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![WO]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --WO
			hipro_wo_input_chk_wo(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				--select count(*) into cnt from g_sn_status where work_order=tsajet2;
				select input_qty, target_qty into cnt, cnt2 from g_wo_base where work_order = tsajet2;
				if cnt >= cnt2 then
					tres := 'NG;工單投入數已滿!';
				end if;
			end if;
			/*       select instr(trev,';',1,1) into c_Number from dual;
            tsajet3:=trim(substr(trev,c_Number+1,length(trev)-c_Number));
            cus_dip_mapping(tterminalid,tsajet2,tsajet3,tres);*/
		end if;
	elsif cmd = 3 then
		if cnt < 3 then
			tres := 'NG格式錯誤![WO;連板數]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';'));
			cus_wo_buildsn(tsajet2, tsajet3, tterminalid, tres);
		end if;
	elsif cmd = 4 then
		if cnt < 5 then
			tres := 'NG格式錯誤![WO;工號;板數;SNList]';
		else
			tsajet2    := trim(f_cus_splitstr(trev, 2, ';')); --wo
			tsajet3    := trim(f_cus_splitstr(trev, 3, ';')); --emp
			tsajet4    := trim(f_cus_splitstr(trev, 4, ';')); --板數
			tsajet5ton := trim(f_cus_splitstr(trev, 5, ';')); --SN List
			cus_sn_automapping(tterminalid, tsajet2, tsajet3, tsajet4, tsajet5ton, tres);
		end if;
	elsif cmd = 5 --檢查SN
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			--SAJET.SJ_CKRT_SN(tsajet2,TRES);
			sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
			if tres = 'OK' then
				sajet.sj_ckrt_route(tterminalid, tsajet2, tres);
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
		/*   ELSIF cmd=5 then                                  --wifi mapping 檢查psn
        if cnt<2 then
          tres:='NG格式錯誤![PSN]';
        else
          tsajet2:=trim(f_cus_splitstr(TREV,2,';')); --psn
          SAJET.SJ_CKRT_SN(tsajet2,tres);
          if substr(tres,1,2)='OK' then
            SAJET.SJ_CKRT_ROUTE(tterminalid,tsajet2,tres);
          end if;
        end if;*/
	elsif cmd = 6 then
		--wifi mapping 檢查wifi sn
		if cnt < 2 then
			tres := 'NG格式錯誤![WIFI SN]';
		else
			tsajet3 := trim(f_cus_splitstr(trev, 2, ';')); --wifi sn
			select count(*) into cnt from cus_wifisn_base a where a.w_psn = tsajet3;
			cus_ckrt_wifisn(tterminalid, tsajet3, tres, c_temp);
		end if;
	elsif cmd = 7 then
		--wifi mapping mapping
		if cnt < 4 then
			tres := 'NG格式錯誤![EMP;PSN;WIFI SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --emp
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';')); --psn
			tsajet4 := trim(f_cus_splitstr(trev, 4, ';')); --wifi sn

			sajet.sj_ckrt_sn(tsajet3, tres);
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, tsajet3, tres);
				if substr(tres, 1, 2) = 'OK' then
					sajet.cus_link_wifisn_1(tterminalid, tsajet4, tsajet3, tsajet2, tres, c_temp);
					if substr(tres, 1, 2) = 'OK' then
						sajet.cus_amazon_transfer(tterminalid, tsajet3, 'N/A', sysdate, tsajet2, tres, t_type, c_temp);
					end if;
				end if;
			end if;
		end if;
	else
		tres := 'NG;[EC102] COMMAND NOT DEFINE.;';
	end if;

	if substr(tres, 1, 2) = 'OK' and length(tres) < 5 then
		tres := 'OK;' || tres;
	end if;
exception
	when others then
		tres := trev || '[' || sqlerrm || ']';
end;
/

