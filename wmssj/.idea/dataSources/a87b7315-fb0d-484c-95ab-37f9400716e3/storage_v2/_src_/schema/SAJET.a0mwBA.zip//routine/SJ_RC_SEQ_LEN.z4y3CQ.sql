create function       
       SJ_RC_SEQ_LEN return number is
begin
  --RC？？？？？
  return 2;
end;


/

