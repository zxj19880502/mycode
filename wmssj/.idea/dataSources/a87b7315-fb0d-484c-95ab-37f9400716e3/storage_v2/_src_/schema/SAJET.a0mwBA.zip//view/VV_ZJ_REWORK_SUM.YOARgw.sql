create view VV_ZJ_REWORK_SUM as
select nvl(p.times,q.times) times,nvl(p.sizespec,q.sizespec) sizespec,nvl(p.qt2,0)+nvl(q.qt2,0) qt2 from
(select nvl(h.times,j.times) times,nvl(h.sizespec,j.sizespec) sizespec,nvl(h.qt2,0)+nvl(j.qt2,0) qt2 from
(select a.sizespec,a.times,count(1) qt2
from sajet.vv_ok_rework_new_new a
where 1=1
group by a.sizespec,a.times)h
full outer join
(select a.sizespec,a.times,count(1) qt2
from sajet.vv_ng_rework_new_new a
where 1=1
group by a.sizespec,a.times)j
on h.sizespec=j.sizespec and h.times=j.times)p
full outer join
(select a.sizespec,a.times,count(1) qt2
from sajet.vv_rework_rework_new a
where 1=1
group by a.sizespec,a.times)q
on p.sizespec=q.sizespec and p.times=q.times


/

