create view V_SN_TRAVEL_OUTPUT_SPC as
select process_id,
       part_id,
       work_order,
       pdline_id,
       work_date,
       work_time,
       --sum(total_qty) total_qty,
       sum(pass_qty) pass_qty,
       sum(fail_qty_1) fail_qty_1,
       sum(fail_qty_2) fail_qty_2
  from (/*select process_id,
               a.part_id,
               a.work_order,
               pdline_id,
               to_char(out_process_time, 'yymmdd') work_date,
               to_char(out_process_time, 'hh24') work_hour,
               count(serial_number) total_qty,
               0 pass_qty,
               0 fail_qty_1,
               0 fail_qty_2
          from sajet.g_sn_travel a, sajet.g_wo_base b
         where a.work_order = b.work_order
           and b.wo_option2 in ('2', '3')
         group by process_id,
                  a.part_id,
                  a.work_order,
                  pdline_id,
                  to_char(out_process_time, 'yymmdd'),
                  to_char(out_process_time, 'hh24')
        union all*/
        select process_id,
               a.part_id,
               a.work_order,
               pdline_id,
               to_char(out_process_time, 'yyyymmdd') work_date,
               to_char(out_process_time, 'hh24') work_time,
               --0,
               count(serial_number) pass_qty,
               0 fail_qty_1,
               0 fail_qty_2
          from sajet.g_sn_travel a, sajet.g_wo_base b
         where a.work_order = b.work_order
           and b.wo_option2 in ('2', '3')
           and a.current_status not in ('1', '4')
         group by process_id,
                  a.part_id,
                  a.work_order,
                  pdline_id,
                  to_char(out_process_time, 'yyyymmdd'),
                  to_char(out_process_time, 'hh24')
        union all
        select process_id,
               a.part_id,
               a.work_order,
               pdline_id,
               to_char(out_process_time, 'yyyymmdd') work_date,
               to_char(out_process_time, 'hh24') work_time,
               --0,
               0,
               count(serial_number),
               0
          from sajet.g_sn_travel a, sajet.g_wo_base b
         where a.work_order = b.work_order
           and b.wo_option2 in ('2', '3')
           and a.current_status = '1'
         group by process_id,
                  a.part_id,
                  a.work_order,
                  pdline_id,
                  to_char(out_process_time, 'yyyymmdd'),
                  to_char(out_process_time, 'hh24')
        union all
        select process_id,
               a.part_id,
               a.work_order,
               pdline_id,
               to_char(out_process_time, 'yyyymmdd') work_date,
               to_char(out_process_time, 'hh24') work_time,
               --0,
               0,
               0,
               count(serial_number)
          from sajet.g_sn_travel a, sajet.g_wo_base b
         where a.work_order = b.work_order
           and b.wo_option2 in ('2', '3')
           and a.current_status = '4'
         group by process_id,
                  a.part_id,
                  a.work_order,
                  pdline_id,
                  to_char(out_process_time, 'yyyymmdd'),
                  to_char(out_process_time, 'hh24'))
 group by process_id, part_id, work_order, pdline_id, work_date, work_time


/

