create PROCEDURE       BITLAND_CHECK_MPART(TMPART in varchar2,TCOANO in varchar2,TTERMINALID in varchar2,TEMP in varchar2,TRES out varchar2)IS
empid number;
mpart sajet.g_sn_coa.m_part_no%type;
BEGIN
  TRES:='OK';
  empid:=0;
  if TMPART is null then
    TRES:='Microsoft Part NO is null';
  elsif TCOANO is null then
    TRES:='COA No is null';
  elsif TEMP is  null then
    TRES:='emp no is null';
  end if;
  if TRES!='OK'then
    return;
  end if;
     sajet.Sj_Get_Empid(TEMP,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMP||')';
    return;
   end if;
   select sc.m_part_no into mpart from sajet.g_sn_coa sc where sc.coa_no=TCOANO;
   if mpart<>TMPART then
     TRES:='Microsoft Part No Error';
     return;
   end if;

exception
  when NO_DATA_FOUND then--？？？？coa no
     TRES:='No this coa no('||TCOANO||')record';
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

