create procedure       csbg_wo_input_qty(tprocessid in number
												   ,tsn        in varchar2
												   ,tqty       in number
												   ,tnow       in date
												   ,tempid     in varchar2
												   ,bflag      out boolean
												   ,tres       out varchar2) is
	cstartp    number;
	cinpdline  date;
	coutpdline date;
	cendp      number;
	cwo        varchar2(25);
	cstatus    varchar2(1);
	ctarget    number;
	coutput    number;
begin
	bflag := false;
	tres  := 'OK';
	select b.work_order, start_process_id, end_process_id, wo_status, target_qty, output_qty, in_pdline_time,
		   out_pdline_time
	into   cwo, cstartp, cendp, cstatus, ctarget, coutput, cinpdline, coutpdline
	from   sajet.g_wo_base a, sajet.g_sn_status b
	where  b.serial_number = tsn and a.work_order = b.work_order and rownum = 1;
	--是工單的第一站
	if (cstartp = tprocessid) /*and (cinpdline is null) */
	 then
		bflag := true;
		if cstatus = '2' then
			update sajet.g_wo_base
			set    input_qty = input_qty + tqty, wo_status = '3', wo_start_date = tnow, update_time = tnow,
				   update_userid = tempid
			where  work_order = cwo;
			insert into sajet.g_ht_wo_base
				select * from sajet.g_wo_base where work_order = cwo;
			update sajet.g_sn_status set in_pdline_time = tnow where serial_number = tsn and rownum = 1;
		else
			update sajet.g_wo_base set input_qty = input_qty + tqty where work_order = cwo;
		end if;
	end if;
exception
	when no_data_found then
		tres := 'OK';
	when others then
		tres := 'CSBG_WO_INPUT_QTY ERROR';
end;


/

