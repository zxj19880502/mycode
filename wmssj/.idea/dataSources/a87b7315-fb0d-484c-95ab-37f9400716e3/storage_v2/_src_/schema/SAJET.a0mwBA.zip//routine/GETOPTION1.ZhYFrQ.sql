create FUNCTION GETOPTION1(SVALUE IN VARCHAR2,STYPE IN VARCHAR2)
  RETURN VARCHAR2 is
  STR VARCHAR2(40);
BEGIN
  
    IF STYPE='1' THEN
      
  IF SVALUE = 'P' THEN
    STR := '量产仓';
  ELSIF SVALUE = 'Q' THEN
    STR := '验证片仓';
  ELSIF SVALUE = 'W' THEN
    STR := '待验证仓';
  ELSIF  SVALUE IS NULL OR SVALUE =''  THEN
    STR := '一般半成品仓';
  ELSIF   SVALUE = 'CQ' THEN
    STR := '芯片前段入库验证片仓';
  ELSIF  SVALUE = 'CP'  THEN
    STR := '芯片前段入库量产仓';
  ELSE
    STR := 'nknow';
  END IF;
  END IF;
  RETURN STR;
END;


/

