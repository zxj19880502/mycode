create FUNCTION       WMS_CHECK_FIFO(TPARAM    IN VARCHAR2
                                         ,TDATECODE IN VARCHAR2
                                         ,TPARTID   IN NUMBER
                                         ,TWHID     IN NUMBER
                                         ,TREELNO   IN VARCHAR2
                                         ,TRES      OUT VARCHAR2) RETURN BOOLEAN IS
    STR          VARCHAR2(100);
    C_SQL        VARCHAR2(4000);
    C_CARTON_QTY NUMBER;
    C_FLAG       VARCHAR2(2);
    C_REELQTY    NUMBER;
    S_LHNUM      VARCHAR2(100);
BEGIN
    TRES := 'OK';

    --余量
    SELECT A.Option8 INTO C_CARTON_QTY FROM SAJET.SYS_PART A WHERE PART_ID = TPARTID;
    IF C_CARTON_QTY IS NULL OR C_CARTON_QTY = 0 THEN
        C_FLAG := 'N';
    ELSE
        C_FLAG := 'Y';
    END IF;

    --如果仓别不为空，找到仓库下最小的DataCode
    IF TWHID IS NOT NULL THEN
        C_SQL := 'SELECT MIN(DATECODE) ' || 'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                --'WHERE (INTERFACE_TYPE = ''WORETURN'' OR INTERFACE_TYPE = ''IN'') ' ||
                 ' WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' || 'AND OPERATION_TYPE = :TPARAM ' ||
                 '   AND A.WAREHOUSE_ID = :TWHID ';
        --确认是否余量的料
        IF C_FLAG = 'Y' THEN
            C_SQL := C_SQL || 'AND A.BOX_QTY<' || C_CARTON_QTY;
        END IF;
        EXECUTE IMMEDIATE C_SQL
            INTO TRES
            USING TPARTID, TPARAM, TWHID;
        --如果仓别为空，找所有仓库下最小的datecode
    ELSE
        C_SQL := 'SELECT MIN(DATECODE) ' || 'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                --'WHERE (INTERFACE_TYPE = ''WORETURN'' OR INTERFACE_TYPE = ''IN'') ' ||
                 ' WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' || 'AND OPERATION_TYPE = :TPARAM ';
        EXECUTE IMMEDIATE C_SQL
            INTO TRES
            USING TPARTID, TPARAM;
    END IF;

    --如果找到最小datecode
    IF TRES IS NOT NULL THEN
        --此datecode需要与传入的datecode一致
        IF TRES = TDATECODE THEN
            TRES := 'OK';
            IF C_FLAG = 'Y' THEN
                SELECT BOX_QTY INTO C_REELQTY FROM SAJET.WMS_STOCK WHERE BOX_NO = TREELNO AND ROWNUM = 1;
                IF C_REELQTY >= C_CARTON_QTY THEN
                     C_SQL :='SELECT * ' || ' FROM (SELECT BOX_NO ' || ' FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                      'WHERE PART_ID =: TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' || 'AND OPERATION_TYPE =: TPARAM ' || 'AND A.WAREHOUSE_ID =: TWHID ' || 'AND A.BOX_QTY<' || C_CARTON_QTY  ||
                     'ORDER BY BOX_NO )WHERE ROWNUM<= 1';
                     EXECUTE IMMEDIATE C_SQL
                     INTO S_LHNUM
                     USING TPARTID,TPARAM,TWHID;
                    TRES := '此料卷不是余量,建议料号'||S_LHNUM;
                    RETURN FALSE;
                END IF;
            END IF;

            RETURN TRUE;
            --若不一致，则获取建议的储位
        ELSE
            STR  := SAJET.Wms_Get_Location(TPARTID, TRES, TPARAM, TWHID);
            TRES := SAJET.Wms_Message('DC NG') || '-' || TRES || CHR(13) || CHR(10) || '建議儲位' || ': ' || STR;
            --SUBSTR(STR, 0, INSTR(STR, ',') - 1);
            RETURN FALSE;
        END IF;
        --如果找不到工單退料或雜收的最小datecode
    ELSE
        --如果仓别不为空，找该仓别下最小的datecode
        IF TWHID IS NOT NULL THEN
            C_SQL := 'SELECT MIN(DATECODE) ' || 'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                     'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' || 'AND OPERATION_TYPE = :TPARAM ' ||
                     'AND A.WAREHOUSE_ID = :TWHID ';
            EXECUTE IMMEDIATE C_SQL
                INTO TRES
                USING TPARTID, TPARAM, TWHID;
            --如果仓别为空，找所有box的最小的datecode
        ELSE
            C_SQL := 'SELECT MIN(DATECODE) ' || 'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                     'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' || 'AND OPERATION_TYPE = :TPARAM ';
            EXECUTE IMMEDIATE C_SQL
                INTO TRES
                USING TPARTID, TPARAM;
        END IF;

        --此最小datecode需要与传入的DATECODE一致
        IF TRES IS NOT NULL THEN
            IF TDATECODE = TRES THEN
                TRES := 'OK';
                RETURN TRUE;
                --若不一致，则依据此最小datecode获取建议的储位
            ELSE
                STR  := SAJET.Wms_Get_Location(TPARTID, TRES, TPARAM, TWHID);
                TRES := SAJET.Wms_Message('DC NG') || '-' || TRES || CHR(13) || CHR(10) || '建議儲位' || ': ' || STR;
                --SUBSTR(STR, 0, INSTR(STR, ',') - 1);
                RETURN FALSE;
            END IF;

        ELSE
            STR := ',';
            RETURN FALSE;
            --TRES:='';
        END IF;
    END IF;

END;


/

