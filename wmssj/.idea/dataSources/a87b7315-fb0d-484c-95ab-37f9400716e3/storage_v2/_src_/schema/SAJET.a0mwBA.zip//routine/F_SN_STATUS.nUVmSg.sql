create function F_SN_STATUS(SSN IN VARCHAR2) return varchar2 is
  Result varchar2(50);
  sSN_TYPE       VARCHAR2(50);
  sSN_STATUS     VARCHAR2(50);
  sSCRAP_PROCESS VARCHAR2(20);
    sSHIP_FLAG       VARCHAR2(20);
  I_COUNT          NUMBER;
  sSTORE_FLAG      VARCHAR2(20);
  s_CURRENT_STATUS VARCHAR2(20);
  SRES VARCHAR2(50);

begin
  SRES        := 'OK';

  /*  I_COUNT     := 0;*/
  sSTORE_FLAG := '-';

  select a.model_name, e.process_name, t.current_status
    into sSN_TYPE, sSCRAP_PROCESS, s_CURRENT_STATUS
    from sajet.g_sn_status t,
         (select b.part_id, c.model_name
            from sajet.sys_part b, sajet.sys_model c
           where b.model_id = c.model_id(+)) a,
         sajet.sys_process e
   where t.serial_number = ssn
     and t.part_id = a.part_id
     and t.process_id = e.process_id;

  BEGIN
    SELECT A.BOX_QTY
      INTO I_COUNT
      FROM (SELECT T.BOX_QTY, T.CREATE_TIME
              FROM SAJET.WMS_STOCK_TRACK T
             WHERE T.BOX_NO = SSN
             ORDER BY T.CREATE_TIME DESC) A
     WHERE ROWNUM = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      sSHIP_FLAG  := 'N';
      sSTORE_FLAG := 'N';
      SRES        := 'NO';
  END;
  IF I_COUNT > 0 THEN
    sSHIP_FLAG  := 'N';
    sSTORE_FLAG := 'Y';
  ELSIF I_COUNT < 0 THEN
    sSHIP_FLAG  := 'Y';
    sSTORE_FLAG := 'N';
  
  END IF;

  IF s_CURRENT_STATUS = '1' THEN
    sSN_STATUS := '已报废';
  else
    IF SRES = 'NO' THEN
      sSN_STATUS := '在制';
    else
      sSN_STATUS := '合格';
    end if;
    sSCRAP_PROCESS := '-';
  
  END IF;

  RESULT:=sSN_STATUS; 
  return(Result);
end F_SN_STATUS;


/

