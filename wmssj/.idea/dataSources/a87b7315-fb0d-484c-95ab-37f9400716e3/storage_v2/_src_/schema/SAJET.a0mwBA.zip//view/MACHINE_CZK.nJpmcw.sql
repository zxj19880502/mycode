create view MACHINE_CZK as
select a.rc_no, a.machine_id, b.machine_code, b.machine_desc,c.merge_rc_no
  from sajet.g_rc_travel_machine a, sajet.sys_machine b,sajet.g_rc_merge c
 where a.machine_id = b.machine_id and a.rc_no=c.rc_no and c.process_id=100011 and b.machine_desc='抽真空搅拌机'


/

