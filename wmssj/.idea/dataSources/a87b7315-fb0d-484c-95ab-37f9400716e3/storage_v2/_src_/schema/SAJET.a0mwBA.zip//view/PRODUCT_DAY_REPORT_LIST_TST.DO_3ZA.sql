create view PRODUCT_DAY_REPORT_LIST_TST as
select a.query_date query_date,a.sizespec sizespec,a.plan_input 计划浇注量,a.浇注_数量 浇注数量 ,a.浇注_报废数量 浇注报废,a.脱模_数量 脱模数量,
a.脱模_报废数量 脱模报废,a.养护_数量 养护数量,a.养护_报废数量 养护报废,a.喷砂_数量 喷砂数量,a.喷砂_报废数量 喷砂报废,
a.切边_数量 切边数量,a.切边_报废数量 切边报废,a.修坯_数量 修坯数量,a.修坯_报废数量 修坯报废,a.半检_数量 半检总数,a.半检_报废数量 半检报废,
sajet.PROCESS_REWORK_PERCENT(a.query_date,100031,a.sizespec) 半检返工率,a.烘干_数量 烘干数量,a.烘干_报废数量 烘干报废,a.烧结_数量 烧结数量,
a.质检_数量 质检数量,a.质检_数量-a.质检_报废数量 质检合格,a.质检_报废数量 质检报废,a.质检_返工数量 质检返工,
CASE WHEN a.质检_数量=0 then '0%' else nvl(to_char(round((a.质检_数量-a.质检_报废数量)/a.质检_数量,4)*100),'0')||'%' end 终检合格率,sajet.PROCESS_REWORK_PERCENT(a.query_date,100026,a.sizespec) 质检返工比例,
a.清洗_数量 清洗数量,a.清洗_报废数量 清洗报废,a.喷涂_数量 喷涂数量,a.喷涂_报废数量 喷涂报废,a.终检_返工数量 OQC返工,
sajet.PROCESS_REWORK_PERCENT(a.query_date,100029,a.sizespec) OQC返工率,a.包装_数量 包装数量,sajet.sj_all_process_tst_lv(1,a.sizespec,to_char(to_date(a.query_date,'yyyy-mm-dd'),'yyyy-mm-dd')) 全制程合格率,
b.stock_qty 入库数量, b.plan_stock 计划入库 ,CASE WHEN NVL(B.plan_stock,0)=0 THEN '0%' ELSE nvl(to_char(round(b.stock_qty/b.plan_stock,4)*100),'0')||'%' END 产出达成率,c.shipping_qty 发货
  from (select *
          from (select *
                  from sajet.v_daily_in_scrap_rework_T k
                 where sizespec in ('1044','1200','1060')
                  /*[AND k.QUERY_DATE >= to_char(:PARAM1,'yyyymmdd')]
                  [AND k.QUERY_DATE < to_char(:PARAM1,'yyyymmdd')]
                  [AND k.SIZESPEC In :PARAM2]*/)
        pivot(max(qty) as 数量, max(scrap_qty) as 报废数量, max(rework_qty) as 返工数量
           for process_name in('浇注' 浇注,'脱模' 脱模,'养护' 养护,'喷砂' 喷砂,
                              '切边' 切边,'修坯' 修坯,'半检' 半检,'烘干' 烘干,
                              '烧结' 烧结,'成品检' 质检,'清洗' 清洗,'喷涂' 喷涂,
                              '出厂检' 终检,'包装' 包装))) a,
       sajet.v_daily_stock b,
       sajet.v_daily_shipping c
 where a.query_date = b.query_date(+)
   and a.query_date = c.query_date(+)
   and a.sizespec = b.sizespec(+)
   and a.sizespec = c.sizespec(+) and a.query_date is not null


/

