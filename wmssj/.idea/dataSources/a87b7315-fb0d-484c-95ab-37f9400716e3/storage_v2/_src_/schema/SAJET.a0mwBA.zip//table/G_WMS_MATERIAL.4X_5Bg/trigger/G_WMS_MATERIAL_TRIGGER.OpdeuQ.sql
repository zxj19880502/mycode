create trigger G_WMS_MATERIAL_TRIGGER
  after insert
  on G_WMS_MATERIAL
  for each row
declare
	--tres      varchar2(50);
	icount               number;
	icount1              number;
	icount2              number;
	icount3              number;
	icount4              number;
	icount5              number;
	avendor_id           sajet.sys_vendor.vendor_id%type;
	art_id               sajet.g_erp_rtno.rt_id%type;
	aactive              sajet.g_wms_material.active%type;
	apart_id             sajet.sys_part.part_id%type;
	apackageserialnumber sajet.g_wms_material_status.packageserialnumber%type;
	--astatus    sajet.g_wms_material_status.status%type; 
	awork_order  sajet.g_sn_status.work_order%type;
	apart_no     sajet.sys_part.part_no%type;
	alotno       varchar2(50);
	adatecode    varchar2(50);
	aqty         number;
	apackagespec varchar2(50);
	avendor_code varchar2(50);
	aupdate_time date;
	art_no       varchar2(50);
	art_seq      varchar2(50);
	apart_spec   varchar2(50);
	apart_uom    varchar2(50);
	avendor_name varchar2(50);
	apo_no       varchar2(50);
	astatus      varchar2(50);
	--aupdate_userid varchar2(50);
	aincoming_qty number;
	aeff_date     date;

	apo_item varchar2(50);
begin
	awork_order          := trim(:new.work_order);
	aactive              := trim(:new.active);
	apackageserialnumber := trim(:new.packageserialnumber);
	apart_no             := trim(:new.part_no);
	alotno               := trim(:new.lotno);
	adatecode            := trim(:new.datecode);
	aqty                 := trim(:new.qty);
	apackagespec         := trim(:new.packagespec);
	avendor_code         := trim(:new.vendor_code);
	aupdate_time         := trim(:new.update_time);
	art_no               := trim(:new.rt_no);
	art_seq              := trim(:new.rt_seq);
	apart_spec           := trim(:new.part_spec);
	apart_uom            := trim(:new.part_uom);
	avendor_code         := trim(:new.vendor_code);
	avendor_name         := trim(:new.vendor_name);
	apo_no               := trim(:new.po_no);
	aupdate_time         := trim(:new.update_time);
	apo_item             := trim(:new.po_item);
	aeff_date            := trim(:new.effective_date);
	aincoming_qty        := trim(:new.incoming_qty);
	begin
		--查询工单是否在MES存在，没有就保存在g_tri_log ，然后retuen
		select t.work_order into awork_order from sajet.g_wo_base t where t.work_order = awork_order;
	
	exception
		when others then
			--dbms_output.put_line('工厂代码校验错误');
		
			raise_application_error('-20000', '工单校验错误');
			goto endp;
		
	end;
	if apackageserialnumber is null then
		raise_application_error('-20000', 'PKSN不能为空');
		goto endp;
	end if;
	if aqty is null then
		raise_application_error('-20000', 'qty不能为空');
		goto endp;
	end if;
	if avendor_code is null then
		raise_application_error('-20000', 'vendor代码不能为空');
		goto endp;
	end if;
	if art_no is null then
		raise_application_error('-20000', 'art_no不能为空');
		goto endp;
	end if;
	--select a.active into aactive from sajet.g_wms_material a  ;
	if aactive = '1' then
		-- 0 检查料号是否在sys_part存在，没有就insert，( part_id,part_no,spec1,uom )--抓sys_part的max(part_id)+1作为part_id ，及时commit；
	
		--查询Vendor_code在sys_vendor是否存在，没有就新增，(vender_id,vendor_code,vender_name)有就查询对应的vendor_ID,待用
	
		--查询RT_NO在g_erp_rtno是否存在，没有就新增 rt_id(抓目前的rt_id最大值，然后加1),rt_no,vendor_id,po_no,receive_time
		--查询rt_no和RT_SEQ是否在g_erp_rt_item存在，不存在就新增，RT_ID,PART_ID,RT_SEQ,INCOMING_QTY,incoming_time
		--select update_userid into aupdate_userid from sajet.g_wo_base t where t.work_order=awork_order;
		select count(*) into icount1 from sajet.sys_part a where a.part_no = apart_no;
	
		if icount1 = 0 then
			select max(part_id) + 1 into apart_id from sajet.sys_part;
			insert into sajet.sys_part
				(part_id, part_no, spec1, uom)
			values
				(apart_id, apart_no, apart_spec, apart_uom);
		else
			select a.part_id into apart_id from sajet.sys_part a where a.part_no = apart_no;
		end if;
	
		select count(*) into icount2 from sajet.sys_vendor a where a.vendor_code = avendor_code;
	
		if icount2 = 0 then
			select max(vendor_id) + 1 into avendor_id from sajet.sys_vendor;
		
			insert into sajet.sys_vendor
				(vendor_id, vendor_code, vendor_name)
			values
				(avendor_id, avendor_code, avendor_name);
		else
			select a.vendor_id into avendor_id from sajet.sys_vendor a where a.vendor_code = avendor_code;
		end if;
	
		select count(*) into icount3 from sajet.g_erp_rtno a where a.rt_no = art_no;
		if icount3 = 0 then
			select max(rt_id) + 1 into art_id from sajet.g_erp_rtno;
		
			insert into sajet.g_erp_rtno
				(rt_id, rt_no, vendor_id, po_no, receive_time)
			values
				(art_id, art_no, avendor_id, apo_no, aupdate_time);
		else
			select a.rt_id into art_id from sajet.g_erp_rtno a where a.rt_no = art_no;
		end if;
	
		select count(*) into icount4 from sajet.g_erp_rt_item b where b.rt_id = art_id and b.rt_seq = art_seq;
		if icount4 = 0 then
			select max(rt_id) + 1 into art_id from sajet.g_erp_rt_item;
			insert into sajet.g_erp_rt_item
				(rt_id, part_id, rt_seq, incoming_qty, incoming_time)
			values
				(art_id, apart_id, art_seq, aincoming_qty, sysdate); --art_no 不对
		end if;
	
	
		select count(*)
		into   icount
		from   sajet.g_wms_material_status a
		where  apackageserialnumber = a.packageserialnumber;
		if icount = 0 then
			insert into sajet.g_wms_material_status
				(work_order, part_id, lotno, datecode, qty, packagespec, packageserialnumber, vendor_id, update_time,
				 rt_id, rt_seq, download_time, enabled, status, po_no, po_item, effective_date)
			values
				(awork_order, apart_id, alotno, adatecode, aqty, apackagespec, apackageserialnumber, avendor_id,
				 aupdate_time, art_id, art_seq, sysdate, 'Y', '0', apo_no, apo_item, aeff_date);
		
			--1. 检查g_material 里的栏位 reel_no是否有等于:new.packageserialnumber，有，就更新，没有就insert 
		
			-- insert into sajet.g_material
			--   (part_id, datecode, reel_no, reel_qty, lot, vendor_id,  update_time)   
		elsif icount = 1 then
			select a.status
			into   astatus
			from   sajet.g_wms_material_status a
			where  a.packageserialnumber = apackageserialnumber;
		
			if astatus = '1' then
				update sajet.g_wms_material_status
				set    work_order = awork_order, part_id = apart_id, lotno = alotno, datecode = adatecode, qty = aqty,
					   packagespec = apackagespec, packageserialnumber = apackageserialnumber, vendor_id = avendor_id,
					   update_time = aupdate_time, rt_id = art_id, rt_seq = art_seq, download_time = sysdate,
					   enabled = 'Y', status = '0', effective_date = aeff_date
				where  packageserialnumber = apackageserialnumber;
			
			elsif astatus = '0' then
				raise_application_error('-20000', '已下发');
				goto endp;
			elsif astatus = '2' then
				raise_application_error('-20000', '已拆批');
				goto endp;
			elsif astatus = '3' then
				raise_application_error('-20000', '已上料');
				goto endp;
			end if;
		
		
		end if;
	
	
		select count(*) into icount5 from sajet.g_material a where a.reel_no = apackageserialnumber;
		if icount5 = 0 then
			insert into sajet.g_material
				(part_id, datecode, reel_no, reel_qty, lot, vendor_id, update_time)
			values
				(apart_id, adatecode, apackageserialnumber, aqty, alotno, avendor_id, sysdate);
		elsif icount5 = 1 then
			update sajet.g_material
			set    part_id = apart_id, datecode = adatecode, reel_qty = aqty, lot = alotno, update_time = sysdate,
				   vendor_id = avendor_id
			where  reel_no = apackageserialnumber;
		end if;
	
	elsif aactive = '2' then
		select a.status
		into   astatus
		from   sajet.g_wms_material_status a
		where  a.packageserialnumber = apackageserialnumber;
		if astatus = '0' or astatus = '1' then
			update sajet.g_wms_material_status set status = '1' where packageserialnumber = apackageserialnumber; --GAI
		
		else
			raise_application_error('-20000', '状态错误');
			goto endp;
		end if;
	end if;

	<<endp>>
	null;
	--exception
	--  when others then
	--v_sqlerrm := substr(sqlerrm, 1, 200);
	/*insert into sajet.g_tri_log
        (table_name, param1, param2, clog, update_time)
    values
        ('sajet.G_WMS_MATERIAL_trigger', :new.tk_no, :new.packageserialnumber, v_sqlerrm, sysdate);  */

end;


/

