create trigger WMS_LABEL
  before insert or update or delete
  on WMS_LABEL
  for each row
DECLARE
C_ROWID VARCHAR2(25);
BEGIN
  IF DELETING THEN
    C_ROWID := '1';
  END IF;

  IF INSERTING THEN
    C_ROWID := '2';
  ELSE
    C_ROWID := '3';
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END;


/

