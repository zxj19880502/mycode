create function f_get_spc_id_by_process(process_id in number,
                                                   item_name  in varchar2)
  return varchar2 is
  c_item  varchar(30);
  c_spcid number;
  --根据process_id和测试小项名称获取spc_id
begin
  if process_id = 100003 and item_name = '水分' then
    c_item := '水分-均化';
  elsif process_id = 100003 and item_name = '粒径D50' then
    c_item := '粒径D50';
  elsif process_id = 100007 and item_name = '水分' then
    c_item := '水分-混料';
  elsif process_id = 100007 and item_name = '流时' then
    c_item := '流时';
  elsif process_id = 100026 and item_name = 'AC底' then
    c_item := 'AC底';
  elsif process_id = 100026 and item_name = 'BD底' then
    c_item := 'BD底';
  end if;
  select spc_id into c_spcid from sajet.sys_spc where spc_item = c_item;
  return c_spcid;
exception
  when others then
    return '';
end;


/

