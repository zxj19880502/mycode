create trigger T_ED_VD
  before insert
  on ED_VD
  for each row
DECLARE
  C_VENDORID NUMBER;
  C_VENDORNO VARCHAR2(50);
BEGIN
  :NEW.LOG := 'OK';
  BEGIN
    SELECT VENDOR_CODE
      INTO C_VENDORNO
      FROM SAJET.SYS_VENDOR
     WHERE VENDOR_CODE = :NEW.VD_VENDER;
    BEGIN
      UPDATE SAJET.SYS_VENDOR
         SET VENDOR_NAME       = :NEW.VD_VENDER_NAME,
             UPDATE_TIME       = TO_DATE(:NEW.VD_UPDATETIME, 'yyyy/mm/dd'),
             VENDOR_TEL        = :NEW.VD_TEL1,
             VENDOR_TEL2       = :NEW.VD_TEL2,
             VENDOR_NAME_ABBR  = :NEW.VD_LINKMAN1,
             VENDOR_NAME_ABBR2 = :NEW.VD_LINKMAN2,
             VENDOR_EMAIL      = :NEW.VD_MAIL,
             VENDOR_CONTACT   = :NEW.VD_ADD1,
             VENDOR_CONTACT2   = :NEW.VD_ADD2,
             VENDOR_CONTACT3   = :NEW.VD_ADD3
       WHERE VENDOR_CODE = C_VENDORNO;
    EXCEPTION
      WHEN OTHERS THEN
        :NEW.LOG := SQLERRM;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      SELECT NVL(MAX(VENDOR_ID), 10000000) + 1
        INTO C_VENDORID
        FROM SAJET.SYS_VENDOR;
      INSERT INTO SAJET.SYS_VENDOR
        (VENDOR_ID,
         VENDOR_CODE,
         VENDOR_NAME,
         UPDATE_TIME,
         VENDOR_TEL,
         VENDOR_TEL2,
         VENDOR_NAME_ABBR,
         VENDOR_NAME_ABBR2,
         VENDOR_EMAIL,
         VENDOR_CONTACT,
         VENDOR_CONTACT2,
         VENDOR_CONTACT3)
      VALUES
        (C_VENDORID,
         :NEW.VD_VENDER,
         :NEW.VD_VENDER_NAME,
         TO_DATE(:NEW.VD_UPDATETIME, 'yyyy/mm/dd'),
         :NEW.VD_TEL1,
         :NEW.VD_TEL2,
         :NEW.VD_LINKMAN1,
         :NEW.VD_LINKMAN2,
         :NEW.VD_MAIL,
         :NEW.VD_ADD1,
         :NEW.VD_ADD2,
         :NEW.VD_ADD3);
  END;
EXCEPTION
  WHEN OTHERS THEN
    :NEW.LOG := SQLERRM;
END;


/

