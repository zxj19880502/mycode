create view V_PROCESS_WIP as
SELECT D.RC_NO,
       D.WORK_ORDER,
       D.PROCESS_ID,
       D.IN_PROCESS_TIME,
       D.CURRENT_QTY
  FROM (SELECT A.RC_NO,
               B.WORK_ORDER,
               (CASE
                 WHEN (A.NEXT_PROCESS = 0 AND A.PROCESS_ID = 0) THEN
                  100125
               /*WHEN (A.NEXT_PROCESS = 0 AND A.PROCESS_ID <> 0) THEN
               A.WIP_PROCESS*/
                 WHEN A.NEXT_PROCESS <> 0 THEN
                  A.NEXT_PROCESS
               END) PROCESS_ID,
               (CASE
                 WHEN (A.IN_PROCESS_TIME IS NULL AND
                      A.OUT_PROCESS_TIME IS NULL) THEN
                  B.UPDATE_TIME
                 WHEN (A.IN_PROCESS_TIME IS NOT NULL AND
                      A.OUT_PROCESS_TIME IS NULL) THEN
                  A.IN_PROCESS_TIME
                 WHEN (A.IN_PROCESS_TIME IS NOT NULL AND
                      A.OUT_PROCESS_TIME IS NOT NULL) THEN
                  A.OUT_PROCESS_TIME
               END) IN_PROCESS_TIME,
               A.CURRENT_QTY
          FROM SAJET.G_RC_STATUS A, SAJET.G_WO_RC B
         WHERE A.RC_NO = B.RC_NO
        /*AND A.WORK_FLAG<>'8'*/
        ) D,
       SAJET.G_WO_BASE E
 WHERE D.WORK_ORDER = E.WORK_ORDER(+)
 AND D.PROCESS_ID IS NOT NULL
/*AND E.WO_CLOSE_DATE IS NULL
AND E.WO_STATUS < '5'*/

 
 
 
 
 
 
 
 
 
 
 
 
 

