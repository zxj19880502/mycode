create function SUM_PERCENT_ALL(Sdate in varchar2,ssizespec in varchar2,Sflag in number) return number is
  Result number;
  --1 合格 2 报废
begin
  if Sflag=1 then 
  select count(t.SERIAL_NUMBER)
    into Result
    from sajet.v_sn_travel_simple t,sajet.g_wo_base a
   where t.output_date = Sdate
     and t.CURRENT_STATUS IN('0','2') AND T.PROCESS_ID=100026 and t.sizespec=ssizespec and t.WORK_ORDER=a.work_order and a.wo_type<>'客返工单';
    
  end if;
  
  if sflag=2 then
     select count(t.SERIAL_NUMBER)
    into Result
    from sajet.v_sn_travel_simple t,sajet.g_wo_base a
   where t.output_date = Sdate and t.sizespec=ssizespec AND t.CURRENT_STATUS='1' and t.WORK_ORDER=a.work_order and a.wo_type<>'客返工单'; 
  end if;
  
  return(Result);
  exception
    when others then
      Result:=0;
      return(Result);
end SUM_PERCENT_ALL;


/

