create procedure       cs_ssn_map_transfer(tlineid     in number
													 ,tstageid    in number
													 ,tprocessid  in number
													 ,tterminalid in number
													 ,psn         in varchar2
													 ,tnow        in date
													 ,tres        out varchar2
													 ,pempid      in number
													 ,trev        in varchar2
													 ,ssn         in varchar2) is
	cwo      varchar2(25);
	cmodelid number;
	ok       varchar2(25);
	inflag   boolean;
	outflag  boolean;
	intime   date;
	outtime  date;
begin
	select b.work_order, b.part_id, in_pdline_time, out_pdline_time
	into   cwo, cmodelid, intime, outtime
	from   sajet.g_sn_status b
	where  b.serial_number = psn and rownum = 1;
	sajet.sj_chk_wo_input(cwo, ok);
	if ok <> 'OK' then
		tres := ok;
	else
		sajet.sj_wo_input_qty(tlineid, tstageid, tprocessid, tterminalid, psn, tnow, tres, pempid, inflag);
		sajet.sj_wo_output_qty(tlineid, tstageid, tprocessid, tterminalid, psn, tnow, tres, pempid, outflag);
		insert into sajet.g_sn_ssn_map (serial_number, shipping_sn, emp_id) values (psn, ssn, pempid);
		if inflag then
			intime := tnow;
		end if;
		if outflag then
			outtime := tnow;
		end if;
		sajet.sj_transation_count(tlineid, tstageid, tprocessid, pempid, tnow, psn, cwo, cmodelid, tres, 0);
		sajet.sj_update_sn(tlineid, tstageid, tprocessid, tterminalid, psn, '0', tnow, pempid, intime, outtime);
	end if;
exception
	when others then
		tres := 'cs_transfer error';
end;


/

