create view V_EPI_PROCESS_INOUTDATA1 as
select INDATA.current_Inday as current_day,INDATA.process_id ,INDATA.InSheft as Sheft,INDATA.wip_in_Qty,outDATA.win_out_Qty from
(select A.current_Inday,A.process_id ,A.InSheft,sum(A.WIP_IN_QTY) as wip_in_Qty from (select to_char(t.In_Process_Time - 8.5 / 24, 'yyyy/mm/dd') current_Inday,t.process_id,t.wip_in_qty,case when to_char(t.In_Process_Time, 'hh24mi') between '0830' and '2030' then '白班'
    else '夜班'  end  as InSheft from sajet.g_rc_travel t
   where t.process_id in ('100125','100167','100168') and  t.in_process_time is not null )A group by a.current_Inday,a.process_id,InSheft)INDATA,

   (select A.current_outday,A.process_id ,A.outSheft,sum(A.WIP_out_good_QTY) as win_out_Qty from (select to_char(t.out_Process_Time - 8.5 / 24, 'yyyy/mm/dd') current_outday,t.process_id,t.wip_out_good_qty,case when to_char(t.out_Process_Time, 'hh24mi') between '0830' and '2030' then '白班'
    else '夜班'  end  as OutSheft from sajet.g_rc_travel t
   where t.process_id in ('100125','100167','100168') and  t.out_process_time is not null )A group by a.current_outday,a.process_id,outSheft)outDATA
   where INDATA.current_Inday=outDATA.current_outday(+)
   and indata.process_id=outdata.process_id(+)
   and indata.InSheft=outdata.outSheft(+)


/

