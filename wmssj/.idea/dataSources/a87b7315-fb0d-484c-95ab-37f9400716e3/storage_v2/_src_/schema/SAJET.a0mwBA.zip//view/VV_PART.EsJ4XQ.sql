create view VV_PART as
select /*a.part_id, a.part_no, a.part_type, a.spec1, a.spec2, a.upc, a.ean, a.version, a.uom, a.cust_part_no,
	   a.vendor_part_no, a.label_file, a.rule_set, mfger_part_no, material_type, lot_size, mac_rule_id, jan_code,
	   label_name, part_type1, part_type2, runin_time, a.model_id,A.ENABLED,A.MATERIAL_CLASS_CODE,A.OPTION1,*/


a."PART_ID",a."PART_NO",a."PART_TYPE",a."SPEC1",a."SPEC2",a."UPC",a."ROUTE_ID",a."UPDATE_USERID",a."UPDATE_TIME",a."ENABLED",a."BURNIN_TIME",a."VERSION",a."CUST_PART_NO",a."VENDOR_PART_NO",a."MATERIAL_TYPE",a."EAN",a."MODEL_ID",a."LABEL_FILE",a."RULE_SET",a."OPTION1",a."OPTION2",a."OPTION3",a."OPTION4",a."OPTION5",a."OPTION6",a."UOM",a."MFGER_PART_NO",a."OPTION7",a."OPTION8",a."OPTION9",a."OPTION10",a."OPTION11",a."OPTION12",a."OPTION13",a."OPTION14",a."OPTION15",a."ERP_ID",a."R_LAST_UPDATE_DATE",a."I_LAST_UPDATE_DATE",a."ERP_DETAIL_ID",a."LOT_SIZE",a."MAC_RULE_ID",a."IMAGE_FLAG",a."FGER_PART_NO",a."PART_TYPE1",a."PART_TYPE2",a."MATERIAL_CLASS_CODE",a."UPC_CODE",a."JAN_CODE",a."EAN_CODE",a."PACKSPEC_RULE",a."DETAIL_SAMPLE_PLAN",a."RUNIN_TIME",a."LABEL_NAME",a."CARTON_MAX_WG",a."CARTON_AVG_WG",a."CARTON_MIN_WG",a."ANDROID_BID",a."LCRFLAG",a."TYPE8SH_",a."TYPE8S_H",a."TYPE11SH",a."MOULD_NAME",a."IFMOLD",a."SAFETY_STOCK",a."ORG_ID",a."SEND_TYPE",a."SEND_ENABLE",a."LINE_SAFE_QTY",a."PART_STATUS",a."MAX_STOCK_QTY",a."MIN_STOCK_QTY",a."PART_DL",a."PART_ZL",a."MODEL",a."REMARK",a."BOX_QTY",a."CARTON_QTY",a."WEIGHT",a."BENCHMARK",a."PART_DEPARTMENT",a."GIFTBOX_LAB",a."PART_DETAIL",a."CARTON_LAB",a."SN_LAB",a."STOCK_WH_ID",a."UNIT_PRICE",a."NEED_TYPE",a."LINE_MIN_QTY",
        b.route_name, d.sampling_type, f.model_name,
	   nvl(e.rule_name, '') mac_rule_name
from   sajet.sys_part a, sajet.sys_route b, sajet.sys_qc_sampling_default c, sajet.sys_qc_sampling_plan d,
	   sajet.sys_rule_name e, sajet.sys_model f
where  a.route_id = b.route_id(+) and a.part_id = c.part_id(+) and c.sampling_id = d.sampling_id(+) and
	   a.mac_rule_id = e.rule_id(+) and a.model_id = f.model_id(+)


/

