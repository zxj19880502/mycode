create procedure Check_FIFO(TREEL_NO  IN VARCHAR2,
                                       VREEL_NO  IN VARCHAR2,
                                       TRESULT   OUT VARCHAR2,
                                       TRES      OUT varchar2,
                                       VDATACODE OUT varchar2) is
  TDATACODE varchar2(50);
  TCOUNT    number;
begin
  --SELECT NOT DISPATCH
  IF VREEL_NO is null THEN
    select datecode_yw
      into TDATACODE
      from ((select a.reel_no, a.datecode_yw
               from sajet.g_material a
              where a.reel_no not in
                    (select a.reel_no from sajet.g_storeissue a)
                and a.part_id not in
                    (select part_id from sajet.sys_iqc_forbidden)
              order by a.datecode_yw) c)
     where rownum < 2;
  ELSE
    execute immediate 'select datecode_yw
      from ((select a.reel_no, a.datecode_yw
               from sajet.g_material a
              where a.reel_no not in
                    (select a.reel_no from sajet.g_storeissue a)
                and a.reel_no not in (' || VREEL_NO || ')
                and a.part_id not in
                    (select part_id from sajet.sys_iqc_forbidden)
              order by a.datecode_yw) c)
     where rownum < 2'
    into TDATACODE;
  END IF;
  VDATACODE := TDATACODE;
  --CHECK NOW DATACODE
  select count(*)
    into TCOUNT
    from sajet.g_material e
   where e.reel_no = TREEL_NO
     and e.datecode_yw > TDATACODE;

  IF TCOUNT > 0 THEN
    TRESULT := 'TRUE';
  ELSE
    TRESULT := 'FALSE';
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    TRES := SQLERRM;
    ROLLBACK;
END;


/

