create PROCEDURE       BITLAND_IQC_FORBIDDEN(vPartNo       in varchar2,
                                                  vVendorCode   in VARCHAR2,
                                                  vLotCode      in varchar2,
                                                  vDateCode     in varchar2,
                                                  vUpdateUserNo in varchar2,
                                                  TRES          out varchar2) IS
  iPartID       number;
  iVendorID     number;
  iUpdateUserID number;
  iCountIQC     number;
BEGIN
  TRES          := 'OK';
  iPartID       := 0;
  iVendorID     := 0;
  iUpdateUserID := 0;
  iCountIQC     := 0;

  if (vPartNo is not null) then
    begin
      select p.part_id
        into iPartID
        from sajet.sys_part p
       where p.part_no = vPartNo;
    exception
      when NO_DATA_FOUND then
        TRES := 'Part No Error';
        goto ENDP;
    end;
  end if;

  begin
    select v.vendor_id
      into iVendorID
      from sajet.sys_vendor v
     where v.vendor_code = vVendorCode;
  exception
    when NO_DATA_FOUND then
      TRES := 'Vendor Code Error';
      goto ENDP;
  end;

  begin
    select e.emp_id
      into iUpdateUserID
      from sajet.sys_emp e
     where e.emp_no = vUpdateUserNo;
  exception
    when NO_DATA_FOUND then
      TRES := 'Emp Error';
      goto ENDP;
  end;

  begin
    select count(f.part_id)
      into iCountIQC
      from sajet.sys_iqc_forbidden F
     where (f.part_id = iPartID or f.part_id = 0)
       and f.vendor_id = iVendorID
       and (f.lotcode = vLotCode or f.lotcode is null)
       and (f.datecode = vDateCode or f.datecode is null);

    if iCountIQC = 0 then
      insert into sajet.sys_iqc_forbidden
        (part_id, vendor_id, lotcode, datecode, update_userid)
      values
        (iPartID, iVendorID, vLotCode, vDateCode, iUpdateUserID);
      commit;
    elsif iCountIQC > 0 then
      TRES := 'Data Duplicated';
      goto ENDP;
    end if;
  exception
    when others then
      TRES := 'countIQC error';

  end;

  <<ENDP>>
  NULL;
exception
  WHEN OTHERS THEN
    TRES := SQLERRM;
end;


/

