create view V_SN_QTY_TRAVEL_INOUT as
select a."WORK_ORDER",a."SERIAL_NUMBER",a."PART_ID",a."PDLINE_ID",a."STAGE_ID",a."PROCESS_ID",a."SHIFT_NAME",a."WORK_TIME",a."WIP_IN_QTY",a."PASS_QTY",a."FAIL_QTY",a."FLAG",a."ROW_ID", b.process_name, c.part_no from
(select a.work_order,
       a.serial_number,
       a.part_id,
       a.pdline_id,
       a.stage_id,
       a.process_id,
       nvl(in_process_shift, 'N/A') shift_name,
       in_process_time work_time,
       1 wip_in_qty,
       0 pass_qty,
       0 fail_qty, '投入' flag, a.rowid row_id
  from sajet.g_sn_travel a, sajet.g_wo_base b
 where PROCESS_ID <> '100011'
   and a.work_order = b.work_order
union all
select a.work_order,
       a.serial_number,
       a.part_id,
       a.pdline_id,
       a.stage_id,
       a.process_id,
       'ALL' shift_name,
       in_process_time work_time,
       1 wip_in_qty,
       0 pass_qty,
       0 fail_qty, '投入' flag, a.rowid row_id
  from sajet.g_sn_travel a, sajet.g_wo_base b
 where PROCESS_ID <> '100011'
   and a.work_order = b.work_order
   union all
select a.work_order,
       serial_number,
       a.part_id,
       a.pdline_id,
       a.stage_id,
       a.process_id,
       'ALL' shift_name,
       out_process_time work_time,
       0 wip_in_qty,
       (case
         when current_status <> 1 then
          1
         else
          0
       end) pass_qty,
       (case
         when current_status = 1 then
          1
         else
          0
       end) fail_qty,
       (case
         when current_status <> 1 then
          '产出良品'
         else
          '产出不良品'
       end) flag, a.rowid
  from sajet.g_sn_travel a, sajet.g_wo_base b
 where PROCESS_ID <> '100011'
   and a.work_order = b.work_order
union all
select a.work_order,
       serial_number,
       a.part_id,
       a.pdline_id,
       a.stage_id,
       a.process_id,
       nvl(out_process_shift, 'N/A') shift_name,
       out_process_time work_time,
       0 wip_in_qty,
       (case
         when current_status <> 1 then
          1
         else
          0
       end) pass_qty,
       (case
         when current_status = 1 then
          1
         else
          0
       end) fail_qty,
       (case
         when current_status <> 1 then
          '产出良品'
         else
          '产出不良品'
       end) flag, a.rowid
  from sajet.g_sn_travel a, sajet.g_wo_base b
 where PROCESS_ID <> '100011'
   and a.work_order = b.work_order) a, sajet.sys_process b, sajet.sys_part c
   where a.process_id = b.process_id(+)
   and a.part_id = c.part_id(+)


/

