create procedure CHECK_MAX_NUMBER(TPickNO OUT VARCHAR, TRES OUT VARCHAR) is
V_currentdate VARCHAR(25);
begin
  TRES:='OK';
   select 'P'||substr(to_char(sysdate,'yyyymmdd'), 3,6)  INTO V_currentdate  from dual;
  select decode(max(t.PICKING_NO),null,V_currentdate||'0001',(V_currentdate||LPAD(TO_CHAR(substr(max(T.PICKING_NO),8)+1),4,'0'))) as PICKING_NO into TPickNO
FROM sajet.sys_picking_info t where t.PICKING_NO like V_currentdate||'%';

 EXCEPTION
   WHEN OTHERS THEN
     TRES:=SQLERRM;
     ROLLBACK;

end CHECK_MAX_NUMBER;


/

