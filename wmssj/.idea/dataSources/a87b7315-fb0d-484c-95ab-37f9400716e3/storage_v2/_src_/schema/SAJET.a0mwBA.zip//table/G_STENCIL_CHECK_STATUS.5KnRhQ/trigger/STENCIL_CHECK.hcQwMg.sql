create trigger STENCIL_CHECK
  before insert or update
  on G_STENCIL_CHECK_STATUS
  for each row
DECLARE
BEGIN
  INSERT INTO SAJET.G_STENCIL_CHECK_TRAVEL
    (seq_no,
     stencil_id,
     stencil_code,
     value1,
     value2,
     value3,
     value4,
     value5,
     value6,
     value7,
     value8,
     value9,
     update_userid,
     update_time,
     status,
     value10,
     value11,
     value12,
     option1,
     option2,
     option3)
  VALUES
    (:NEW.SEQ_NO,
     :NEW.STENCIL_ID,
     :NEW.STENCIL_CODE,
     :NEW.VALUE1,
     :NEW.VALUE2,
     :NEW.VALUE3,
     :NEW.VALUE4,
     :NEW.VALUE5,
     :NEW.VALUE6,
     :NEW.VALUE7,
     :NEW.VALUE8,
     :NEW.VALUE9,
     :NEW.UPDATE_USERID,
     :NEW.UPDATE_TIME,
     :NEW.STATUS,
     :NEW.VALUE10,
     :NEW.VALUE11,
     :NEW.VALUE12,
     :NEW.OPTION1,
     :NEW.OPTION2,
     :NEW.OPTION3);
EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END;


/

