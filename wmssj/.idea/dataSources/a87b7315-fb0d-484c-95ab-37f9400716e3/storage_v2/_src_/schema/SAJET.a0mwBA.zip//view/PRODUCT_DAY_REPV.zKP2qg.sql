create view PRODUCT_DAY_REPV as
SELECT QUERY_DATE,SIZESPEC,计划浇注量 a1,浇注数量 a2,浇注报废 a3,脱模数量 a4,脱模报废 a5,养护数量 a6,养护报废 a7,喷砂数量 a8,喷砂报废 a9,切边数量 b1,切边报废 b2,
   修坯数量 b3,修坯报废 b4,半检总数 b5,半检报废 b6,半检返工率 b7,烘干数量 b8,烘干报废 b9,烧结数量 c1,质检数量 c2,质检合格 c3,质检报废 c4,质检返工 c5,终检合格率 c6,质检返工比例 c7,
   清洗数量 c8,清洗报废 c9, 喷涂数量 d1, 喷涂报废 d2,OQC返工 d3,OQC返工率 d4,包装数量 d5,全制程合格率 d6,入库数量 d7,计划入库 d8,产出达成率 d9,发货 e1 FROM SAJET.PRODUCT_DAY_REP


/

