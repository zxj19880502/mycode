create procedure       csbg_qc_insert_sn(tsndata  in varchar2
												   ,tqclotno in varchar2
												   ,tqccnt   in varchar2
												   ,tres     out varchar2) is
	/*---------------------------------
    DATE : 2005/06/13
    ----------------------------------*/
	istart    number;
	iend      number;
	c_linkstr varchar2(1);
	--===============SNDATA====================
	c_sn         sajet.g_sn_status.serial_number%type;
	c_insptime   varchar2(25);
	c_empid      varchar2(20);
	c_inspresult varchar2(1);
	c_inspqty    number;
begin
	tres      := 'OK';
	istart    := 0;
	iend      := 0;
	c_linkstr := '@';
	loop
		begin
			istart := iend + 1;
			iend   := instr(tsndata, c_linkstr, istart, 1);
			exit when(iend = 0) or tres <> 'OK';
			c_sn         := substr(tsndata, istart, iend - istart);
			istart       := iend + 1;
			iend         := instr(tsndata, c_linkstr, istart, 1);
			c_insptime   := substr(tsndata, istart, iend - istart);
			istart       := iend + 1;
			iend         := instr(tsndata, c_linkstr, istart, 1);
			c_empid      := substr(tsndata, istart, iend - istart);
			istart       := iend + 1;
			iend         := instr(tsndata, c_linkstr, istart, 1);
			c_inspqty    := to_number(substr(tsndata, istart, iend - istart));
			istart       := iend + 1;
			iend         := instr(tsndata, c_linkstr, istart, 1);
			c_inspresult := to_number(substr(tsndata, istart, iend - istart));
			--寫入檢驗序號的table
			begin
				insert into sajet.g_qc_sn
					(qc_lotno, part_id, work_order, serial_number, qc_result, insp_emp_id, qc_cnt, insp_time, insp_qty)
					select tqclotno, part_id, work_order, serial_number, c_inspresult, c_empid, tqccnt,
						   to_date(c_insptime, 'yyyymmddhh24miss'), c_inspqty
					from   sajet.g_sn_status
					where  serial_number = c_sn and rownum = 1;
			exception
				when others then
					tres := ' INSERT QC SN ERROR';
			end;
		exception
			when others then
				tres := 'GET INSP SN DATE ERROR  !! ' || sqlerrm;
		end;
	end loop;
exception
	when others then
		tres := 'Execute (Csbg_Qc_Insert_Sn) Error!';
end;


/

