create function f_get_csn(scarton_no in varchar2
         ,srownum    in number) return varchar2 is
 csn1   varchar2(50);
 ccount number;
begin
 select count(*) into ccount from sajet.g_sn_status a where carton_no = scarton_no;
 if srownum > ccount then
  csn1 := '';
  goto endp;
 end if;
 select customer_sn
 into   csn1
 from   (select rownum as rn, b.*
    from   (select a.* from sajet.g_sn_status a where carton_no = scarton_no order by customer_sn) b)

 where  rn = srownum;
 <<endp>>
 return csn1;
exception
 when others then
  return sqlerrm;
end;
/

