create function       
SAMPLE_LEVEL(svalue in varchar2) return varchar2 is
str varchar2(16); s number; i number;
begin
  if svalue = '0' then
    str := 'Normal';
  elsif svalue = '1' then
    str := 'Tight';
  elsif svalue = '2' then
    str := 'Reduce';
  elsif svalue = '4' then
    str := 'By Pass';
  else
    str := 'Unknown';
  end if;
  return str;
end;


/

