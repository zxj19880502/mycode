create procedure command_code_dip(tlineid     in number
											,tstageid    in number
											,tprocessid  in number
											,tterminalid in number
											,tnow        in date
											,trev        in varchar2
											,tres        out varchar2
											,tnextproc   out varchar2) is
	tsajet1      varchar2(25);
	tsajet2      varchar2(40);
	tsajet3      varchar2(512);
	tsajet4      varchar2(512);
	tsajet4ton   varchar2(4096);
	tsajet5ton   varchar2(4096);
	c_buffer     varchar2(4096);
	c_head       number;
	cmd          number;
	c_number     number;
	c_start      number;
	c_end        number;
	c_psn        varchar2(35);
	c_temp       varchar2(255);
	c_item       sajet.sys_spc.spc_item%type;
	c_value      sajet.g_spc.spc_value%type;
	c_defect     sajet.sys_defect.defect_code%type;
	c_wo         sajet.g_sn_status.work_order%type;
	c_wo_seq     smt.g_wo_msl.wo_sequence%type;
	c_datecode   smt.g_smt_status.datecode%type;
	c_dbid       varchar2(20);
	c_type       number;
	c_eventid    number;
	t_type       varchar2(25);
	check_status varchar2(10);
	msl_status   varchar2(30);
	c_factory    number;
	cnt          number;
	cvalue       number;
	psn          varchar2(64);
	c_mac        varchar2(24);
	cempid       number;

begin
	tres := 'Fail,Command fail';
	/*   IF SUBSTR(TREV, LENGTH(TREV), 1) = ';' THEN
       c_Buffer := TREV;
    ELSE
       c_Buffer := TREV || ';';
    END IF;
    
    c_Number := 1;
    c_Start := 1;
    c_End := INSTR (c_Buffer, ';', c_Start, c_Number);
    
    IF C_End <= 3 THEN
    BEGIN
       cmd := SUBSTR(c_Buffer, c_Start, C_End-c_Start);
       c_Number := c_Number + 1;
       c_Start := c_End + 1;
    EXCEPTION
       WHEN OTHERS THEN
          cmd := 999;
    END;
    ELSE
       cmd := 999;
    END IF;*/
	select count(*) into cnt from table(f_cus_split(trev, ';'));

	begin
		cmd := to_number(trim(f_cus_splitstr(trev, 1, ';'))); --獲取cmd
	exception
		when others then
			tres := 'NG;CMD ERR!' || ' ' || trev;
			return;
	end;

	if cmd = 1 --檢查用戶
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![EMP]' || trev || '[' || cnt || ']';
		else
		
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			--tsajet3:=trim(f_cus_splitstr(TREV,3,';'));
		
			sajet.sj_cksys_emp(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				tres := 'OK;' || tres;
			end if;
			/*       IF TRES = 'OK' THEN
              select password.decrypt(passwd) into cvalue from sajet.sys_emp where emp_no=tsajet2;
              if cvalue<> tsajet3 then
                tres:='NG;密碼錯誤!';
              else
                TRES := 'OK;OK;';
              end if;
            ELSE
              TRES := tres||' ['||tsajet2||']';
            END IF;*/
		end if;
	elsif cmd = 2 --檢查SN
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			--SAJET.SJ_CKRT_SN(tsajet2,TRES);
			sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
			if tres = 'OK' then
				sajet.sj_ckrt_route(tterminalid, c_psn, tres);
			
				if substr(tres, 1, 2) = 'OK' then
					tres := 'OK;' || tres;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 3 --DIP SN Mapping
	 then
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;SNLIST]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --emp
		
			select instr(trev, ';', 1, 2) into c_number from dual;
			tsajet3 := trim(substr(trev, c_number + 1, length(trev) - c_number));
			/*       tres:='TEST'||tsajet3;
            return;*/
		
			cus_dip_mapping(tterminalid, tsajet2, tsajet3, tres);
			if substr(tres, 1, 2) = 'OK' then
				tres := 'OK;' || tres;
			end if;
		end if;
	elsif cmd = 4 then
		--檢查SN，並獲取相關Mapping SN 列表
		if cnt < 2 then
			tres := 'NG;格式錯誤![SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --SN
			tres    := 'OK';
			sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
			if tres = 'OK' then
				--SAJET.SJ_CKRT_ROUTE(tterminalid,tsajet2,TRES);
				if substr(tres, 1, 2) = 'OK' then
					select wm_concat(serial_number)
					into   tres
					from   (select *
							 from   cus_dip_mapping_base
							 where  keyid = (select *
											 from   (select keyid
													  from   cus_dip_mapping_base
													  where  serial_number = tsajet2
													  order  by create_time desc)
											 where  rownum = 1)
							 order  by seq);
					if length(tres) = 0 then
						tres := 'NG;SN沒有Mapping記錄!';
					else
						tres := 'OK;' || tres;
					end if;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 5 then
		--DIP AOI
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --emp
			sajet.sj_cksys_emp(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				select instr(trev, ';', 1, 2) into c_number from dual;
				tsajet3 := trim(substr(trev, c_number + 1, length(trev) - c_number));
			
				cus_dipaoi_upload(tsajet2, tsajet3, tterminalid, tprocessid, tres);
			else
				tres := tres || tsajet2;
			end if;
		end if;
	elsif cmd = 6 then
		--根据PSN获取機種擴展资料
		if cnt < 2 then
			tres := 'NG;格式錯誤![PSN/DSN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --SN/CSN
			sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
		
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, psn, tres);
			end if;
			if substr(tres, 1, 2) = 'OK' then
				select count(y.build_name)
				into   cnt
				from   sajet.g_sn_status x, wiq.cus_amazon_model y
				where  x.part_id = y.model_id and x.serial_number = psn;
			
				if cnt = 0 then
					tres := 'NG;SN對應機種未設置擴展資料!';
				else
					select tsajet2 || ';' || a.build_name || ';' || a.config_name || ';' || a.program_name || ';' ||
							a.device_id || ';' || a.whw_version || ';' || a.fw_version || ';' || 'ABV:' ||
							a.amazon_barcode_version || ';' || b.parametervalue || ';' || 'PID:' || a.pid
					into   tres
					from   g_sn_status x
					left   join wiq.cus_amazon_model a on x.part_id = a.model_id and x.work_order = a.work_order
					left   join wiq.cus_parameter_base b on a.log_version = b.keyid
					where  x.serial_number = tsajet2 or x.customer_sn = tsajet2;
					tres := 'OK;' || tres;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 7 then
		--根据 PSN 获取 WIFI MAC&BT MAC&WIFI_SN
		if cnt < 2 then
			tres := 'NG;格式錯誤![PSN/DSN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --SN/CSN
			psn     := tsajet2;
			sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, psn, tres);
			end if;
			if substr(tres, 1, 2) = 'OK' then
				select count(x.mac)
				into   cnt
				from   cus_wifisn_base x, sajet.g_sn_status y
				where  x.serial_number = y.serial_number and y.serial_number = psn;
			
				if cnt = 0 then
					tres := 'NG;SN未綁定WIFI MAC資料!';
				else
					--select a.w_psn || ';' || a.mac || ';' || a.bt_id || ';' || a.wfw_version || ';' || z.whw_version
					select a.w_psn || ';' || a.mac || ';' || a.bt_id || ';' || a.hw_ver || ';' || z.whw_version
					into   tres
					from   g_sn_status x
					left   join cus_wifisn_base a on x.serial_number = a.serial_number
					left   join wiq.cus_amazon_model z on x.part_id = z.model_id and x.work_order = z.work_order
					where  x.serial_number = tsajet2 or x.customer_sn = tsajet2;
					tres := 'OK;' || tres;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
		--20190906-arabbao
	elsif cmd = 17 then
		--根据 MAC 获取 WIFI MAC&BT MAC&WIFI_SN,PSN,FW_VERSION
		if cnt < 2 then
			tres := 'NG;格式錯誤![PSN/DSN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --mac
			c_mac   := tsajet2;
			select count(*) into cnt from cus_wifisn_base where mac = c_mac;
			if cnt = 0 then
				tres := 'NG;WIFI MAC[' || c_mac || ']不存在，或錯誤!';
			else
				select a.w_psn || ';' || a.mac || ';' || a.bt_id || ';' || a.wfw_version
				into   tres
				from   cus_wifisn_base a
				where  a.mac = tsajet2;
				tres := 'OK;' || tres;
			end if;
		end if;
	
	
	elsif cmd = 8 then
		--根据 PSN 获取 PIN 等资料
		if cnt < 2 then
			tres := 'NG;格式錯誤![PSN/DSN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --SN/CSN
			sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, psn, tres);
			end if;
			if substr(tres, 1, 2) = 'OK' then
				select count(x.serial_number) into cnt from cus_sn_extenddata x where x.serial_number = psn;
			
				if cnt = 0 then
					tres := 'NG;SN未綁定擴展資料!';
				else
					select tsajet2 || ';' || 'PIN:' || x.pin || ';' || 'PUK:' || x.puk || ';' || x.socsn || ';' ||
							x.fw_version
					into   tres
					from   cus_sn_extenddata x
					where  x.serial_number = psn;
					tres := 'OK;' || tres;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 9 then
		--根据 PSN 保存 PIN
		if cnt < 4 then
			tres := 'NG;格式錯誤![EMP;PSN/DSN;PIN]';
		else
			tsajet4 := trim(f_cus_splitstr(trev, 2, ';')); --EMP
			tsajet2 := trim(f_cus_splitstr(trev, 3, ';')); --SN/CSN
			tsajet3 := trim(f_cus_splitstr(trev, 4, ';')); --PIN
			if length(tsajet3) = 0 then
				tres := 'NG;PIN 不能為空!';
			end if;
			sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, psn, tres);
			end if;
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_get_empid(tsajet4, cempid);
				select count(x.serial_number) into cnt from cus_sn_extenddata x where x.serial_number = psn;
			
				if cnt = 0 then
					insert into cus_sn_extenddata
						(serial_number, pin, update_time, update_empid)
					values
						(psn, tsajet3, sysdate, cempid);
					tres := 'OK;';
				else
					select pin into c_temp from cus_sn_extenddata x where x.serial_number = psn;
					/*if length(c_Temp)>0 then
                      tres:='NG;SN已綁定其它PIN';
                    else*/
					update cus_sn_extenddata
					set    pin = tsajet3, update_time = sysdate, update_empid = cempid
					where  serial_number = psn;
					tres := 'OK;';
					--end if;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 10 then
		--根据 PSN 保存 PUK
		if cnt < 4 then
			tres := 'NG;格式錯誤![EMP;PSN/DSN;PUK]';
		else
			tsajet4 := trim(f_cus_splitstr(trev, 2, ';')); --EMP
			tsajet2 := trim(f_cus_splitstr(trev, 3, ';')); --SN/CSN
			tsajet3 := trim(f_cus_splitstr(trev, 4, ';')); --PUK
			if length(tsajet3) = 0 then
				tres := 'NG;PUK 不能為空!';
			end if;
			sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, psn, tres);
			end if;
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_get_empid(tsajet4, cempid);
				select count(x.serial_number) into cnt from cus_sn_extenddata x where x.serial_number = psn;
			
				if cnt = 0 then
					insert into cus_sn_extenddata
						(serial_number, puk, update_time, update_empid)
					values
						(psn, tsajet3, sysdate, cempid);
					tres := 'OK;';
				else
					select puk into c_temp from cus_sn_extenddata x where x.serial_number = psn;
					/*if length(c_Temp)>0 then
                      tres:='NG;SN已綁定其它PUK';
                    else*/
					update cus_sn_extenddata
					set    puk = tsajet3, update_time = sysdate, update_empid = cempid
					where  serial_number = psn;
					tres := 'OK;';
					--end if;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 11 then
		--根据 PSN 保存 X509
		if cnt < 4 then
			tres := 'NG;格式錯誤![EMP;PSN/DSN;PUK]';
		else
			tsajet4    := trim(f_cus_splitstr(trev, 2, ';')); --EMP
			tsajet2    := trim(f_cus_splitstr(trev, 3, ';')); --SN/CSN
			tsajet4ton := trim(f_cus_splitstr(trev, 4, ';')); --x509
			if length(tsajet4ton) = 0 then
				tres := 'NG;X509 不能為空!';
			end if;
			sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, psn, tres);
			end if;
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_get_empid(tsajet4, cempid);
				select count(x.serial_number) into cnt from cus_sn_extenddata x where x.serial_number = psn;
			
				if cnt = 0 then
					insert into cus_sn_extenddata
						(serial_number, x509, update_time, update_empid)
					values
						(psn, tsajet4ton, sysdate, cempid);
					tres := 'OK;';
				else
					--select x509 into c_Temp from cus_sn_extenddata x where x.serial_number=psn;
					/*if length(c_Temp)>0 then
                      tres:='NG;SN已綁定其它X509';
                    else*/
					update cus_sn_extenddata
					set    x509 = tsajet4ton, update_time = sysdate, update_empid = cempid
					where  serial_number = psn;
					tres := 'OK;';
					--end if;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 12 then
		--根据 PSN 保存 F/W Versio
		if cnt < 4 then
			tres := 'NG;格式錯誤![EMP;PSN/DSN;PUK]';
		else
			tsajet4 := trim(f_cus_splitstr(trev, 2, ';')); --EMP
			tsajet2 := trim(f_cus_splitstr(trev, 3, ';')); --SN/CSN
			tsajet3 := trim(f_cus_splitstr(trev, 4, ';')); --F/W Versio
			if length(tsajet3) = 0 then
				tres := 'NG;F/W Versio 不能為空!';
			end if;
			sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, psn, tres);
			end if;
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_get_empid(tsajet4, cempid);
				select count(x.serial_number) into cnt from cus_sn_extenddata x where x.serial_number = psn;
			
				if cnt = 0 then
					insert into cus_sn_extenddata
						(serial_number, fw_version, update_time, update_empid)
					values
						(psn, tsajet3, sysdate, cempid);
					tres := 'OK;';
				else
					select fw_version into c_temp from cus_sn_extenddata x where x.serial_number = psn;
					if length(c_temp) > 0 then
						tres := 'NG;SN已綁定其它 F/W Version';
					else
						update cus_sn_extenddata
						set    fw_version = tsajet3, update_time = sysdate, update_empid = cempid
						where  serial_number = psn;
						tres := 'OK;';
					end if;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 13 then
		--根据 PSN 保存 SoCSN
		if cnt < 4 then
			tres := 'NG;格式錯誤![EMP;PSN/DSN;SocSN]';
		else
			tres    := 'OK';
			tsajet4 := trim(f_cus_splitstr(trev, 2, ';')); --EMP
			tsajet2 := trim(f_cus_splitstr(trev, 3, ';')); --SN/CSN
			tsajet3 := trim(f_cus_splitstr(trev, 4, ';')); --SoCSN
			if length(tsajet3) = 0 then
				tres := 'NG;SOCSN 不能為空!';
				/*elsif length(tsajet3)<>12 then
                tres:='NG;SOCSN 長度必須是12位!';*/
			end if;
			select count(*) into cnt from cus_sn_extenddata x where x.socsn = tsajet3;
			/* if cnt>0 then
              tres:='NG;SOCSN 已存在!';
            end if;*/
		
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
				if substr(tres, 1, 2) = 'OK' then
					sajet.sj_ckrt_route(tterminalid, psn, tres);
				end if;
			end if;
		
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_get_empid(tsajet4, cempid);
				select count(x.serial_number) into cnt from cus_sn_extenddata x where x.serial_number = psn;
			
				if cnt = 0 then
					insert into cus_sn_extenddata
						(serial_number, socsn, update_time, update_empid)
					values
						(psn, tsajet3, sysdate, cempid);
					tres := 'OK;';
				else
					select socsn into c_temp from cus_sn_extenddata x where x.serial_number = psn;
					/*if length(c_Temp)>0 then
                      tres:='NG;SN已綁定SoCSN';
                    else*/
					update cus_sn_extenddata
					set    socsn = tsajet3, update_time = sysdate, update_empid = cempid
					where  serial_number = psn;
					tres := 'OK;';
					--end if;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 14 then
		--SN 過站
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;PSN/DSN;DefectCode]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --EMP
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';')); --SN/CSN
			tres    := 'OK';
			if cnt = 4 then
				tsajet4 := trim(f_cus_splitstr(trev, 4, ';')); --DefectCode
				if length(tsajet4) = 0 then
					tsajet4 := 'N/A';
				else
					select count(*) into cnt from sys_defect where defect_code = tsajet4 and enabled = 'Y';
					if cnt = 0 then
						tres := 'NG;不良代碼 ' || tsajet4 || ' 不存在!';
					end if;
				end if;
			else
				tsajet4 := 'N/A';
			end if;
		
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_sn_psn(tsajet3, tres, psn);
				if substr(tres, 1, 2) = 'OK' then
					sajet.sj_ckrt_route(tterminalid, psn, tres);
					if substr(tres, 1, 2) = 'OK' then
						sajet.cus_transfer2(tterminalid, psn, tsajet4, sysdate, tsajet2, tres);
					end if;
				else
					tres := tres || ' [' || tsajet3 || ']';
				end if;
			end if;
		end if;
	elsif cmd = 15 then
		--根据 PSN 获取 WIFI MAC&BT MAC,不檢查SN Route
		if cnt < 2 then
			tres := 'NG;格式錯誤![PSN/DSN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --SN/CSN
			psn     := tsajet2;
			sajet.sj_ckrt_sn_psn(tsajet2, tres, psn);
			/*       if substr(tres,1,2)='OK' then
              sajet.sj_ckrt_route(tterminalid,psn,tres);
            end if;*/
			if substr(tres, 1, 2) = 'OK' then
				select count(x.mac)
				into   cnt
				from   cus_wifisn_base x, sajet.g_sn_status y
				where  x.serial_number = y.serial_number and y.serial_number = psn;
			
				if cnt = 0 then
					tres := 'NG;SN未綁定WIFI MAC資料!';
				else
					select psn || ';' || a.mac || ';' || a.bt_id
					into   tres
					from   g_sn_status x
					left   join cus_wifisn_base a on x.serial_number = a.serial_number
					where  x.serial_number = tsajet2 or x.customer_sn = tsajet2;
					tres := 'OK;' || tres;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 16 then
		--獲取4進制，7位長度的流水碼
		if cnt < 2 then
			cvalue := 1;
		else
			begin
				cvalue := to_number(trim(f_cus_splitstr(trev, 2, ';')));
			
				if cvalue > 30 then
					tres := 'NG;請求數量不能大於30!';
				else
					tres := 'OK';
				end if;
			exception
				when others then
					tres := 'NG;格式錯誤!只能有數字!';
			end;
		end if;
		if substr(tres, 1, 2) = 'OK' then
			c_temp := '';
			select sys_guid() into tsajet3 from dual;
		
			for i in 1 .. cvalue loop
				cnt := s_trial_production_seq.nextval;
				psn := f_cus_getseq('0123', cnt, 7);
			
				insert into cus_trial_production_sn
					(keyid, serial_number, seq, create_time)
				values
					(tsajet3, psn, cnt, sysdate);
			
			
				for k in 1 .. length(psn) loop
					if substr(psn, k, 1) = 0 then
						c_temp := c_temp || '%';
					elsif substr(psn, k, 1) = 1 then
						c_temp := c_temp || '{';
					elsif substr(psn, k, 1) = 2 then
						c_temp := c_temp || 'I';
					elsif substr(psn, k, 1) = 3 then
						c_temp := c_temp || '<';
					end if;
				end loop;
				c_temp := c_temp || ';';
				--c_Temp:=c_Temp||psn||';';
			end loop;
		
			tres := 'OK;' || c_temp;
		end if;
	
	else
		tres := 'NG;[EC102] COMMAND NOT DEFINE.;';
	end if;

	if substr(tres, 1, 2) = 'OK' and length(tres) < 5 then
		tres := 'OK;' || tres;
	end if;
	--tres:=f_cus_formatStr(tres,length(trev),' ','N');
exception
	when others then
		tres := trev || '[' || sqlerrm || ']';
end;
/

