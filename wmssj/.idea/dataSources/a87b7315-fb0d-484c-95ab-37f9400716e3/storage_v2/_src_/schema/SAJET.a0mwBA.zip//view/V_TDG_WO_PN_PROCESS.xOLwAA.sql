create view V_TDG_WO_PN_PROCESS as
SELECT D.WORK_ORDER,
       D.PART_ID,
       E.PART_NO,
       F.PROCESS_ID,
       F.PROCESS_NAME,
       F.FLAG,
       D.ROUTE_ID
  FROM SAJET.G_WO_BASE D,
       SAJET.SYS_PART E,
       (SELECT A.NODE_CONTENT PROCESS_ID,
               C.PROCESS_NAME,
               ROUTE_ID,
               MAX(FLAG) FLAG
          FROM (SELECT NODE_CONTENT, ROUTE_ID, ROWNUM FLAG
                  FROM (SELECT B.ROUTE_ID,
                               B.NODE_ID,
                               B.NODE_TYPE,
                               B.NODE_CONTENT,
                               B.NEXT_NODE_ID
                          FROM SAJET.SYS_RC_ROUTE_DETAIL B
                         START WITH B.NODE_TYPE = 0
                        CONNECT BY PRIOR B.NEXT_NODE_ID = B.NODE_ID)
                 WHERE NODE_TYPE NOT IN (0, 9)) A,
               (SELECT TO_CHAR(PROCESS_ID) PROCESS_ID, PROCESS_NAME
                  FROM SAJET.SYS_PROCESS) C
         WHERE A.NODE_CONTENT = C.PROCESS_ID(+)
         GROUP BY A.NODE_CONTENT, C.PROCESS_NAME, ROUTE_ID) F
 WHERE D.PART_ID = E.PART_ID
   AND D.ROUTE_ID = F.ROUTE_ID
 ORDER BY D.WORK_ORDER, F.FLAG


/

