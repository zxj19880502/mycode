create function       
      SJ_PRIVILEGE_DEFINE(sType in varchar2,sPrivilege in varchar2) return varchar2 is
sReturn varchar2(16);
/*====？？？？===============
Allow To Change:？？Update
Full Control :？Insert,Update,Delete,Enabled,Disabled

sTYPE:？？？INSERT,UPDATE,DELETE,DISABLED,ENABLED
============================*/
begin
  sReturn:='N';
  IF sPrivilege='2' THEN
    sReturn:='Y';
  END IF;

  IF UPPER(sType)='UPDATE' THEN
    IF sPrivilege ='1' or sPrivilege ='2' THEN
      sReturn:='Y';
    END IF;
  END IF;

  return sReturn;
end;


/

