create function pivottest( p_stmt in varchar2, p_fmt in varchar2 := 'upper(@p@)', dummy in number := 0 )
return anydataset pipelined using PivotImpl;

--范例
/*select * from table(pivottest('select B.PROCESS_NAME "制程名称", sum(a.output_qty) "产出数量"
  from sajet.g_sn_count a, SAJET.SYS_PROCESS B
 where 1 = 1
   AND A.PROCESS_ID = B.PROCESS_ID
 GROUP BY B.PROCESS_NAME
 order by b.PROCESS_NAME'));*/

 
 
 
 
 

