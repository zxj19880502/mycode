create FUNCTION splitclob(p_string IN clob, p_delimiter IN VARCHAR2)
RETURN str_split
PIPELINED
AS
--v_length   NUMBER := DBMS_LOB.GETLENGTH(p_string);
--v_start    NUMBER := 1;
--v_index    NUMBER;
C_TEMP_CLOB CLOB;
C_ITEMTEMP  VARCHAR2(100);

BEGIN
  C_TEMP_CLOB:=p_string;
LOOP
   EXIT WHEN C_TEMP_CLOB IS NULL;
    C_ITEMTEMP  :=  DBMS_LOB.substr(C_TEMP_CLOB, DBMS_LOB.INSTR(C_TEMP_CLOB, p_delimiter) - 1,1);
    C_TEMP_CLOB :=  DBMS_LOB.substr(C_TEMP_CLOB,DBMS_LOB.GETLENGTH(C_TEMP_CLOB),DBMS_LOB.INSTR(C_TEMP_CLOB,p_delimiter)+1);
    PIPE ROW(C_ITEMTEMP);

END LOOP;

/*WHILE(v_start <= v_length)
LOOP
v_index := INSTR(p_string, p_delimiter, v_start);
IF v_index = 0        THEN
PIPE ROW(SUBSTR(p_string, v_start));
v_start := v_length + 1;
ELSE
PIPE ROW(SUBSTR(p_string, v_start, v_index - v_start));
v_start := v_index + 1;
END IF;
END LOOP;
*/
RETURN;
END splitclob;


/

