create procedure command_code_fu_test(tsajet1     in varchar2
                        ,tsajet2     in varchar2
                        ,tsajet3     in varchar2
                        ,tsajet4     in varchar2
                        ,tsajet5     in clob
                        ,tsajet6     in varchar2
                        ,tlineid     in number
                        ,tstageid    in number
                        ,tprocessid  in number
                        ,tterminalid in number
                        ,tnow        in date
                        ,trev        in varchar2
                        ,tres        out varchar2
                        ,tnextproc   out varchar2) is

  cmd     number;
  c_panel varchar2(25);
  ssnn    varchar2(25);

  c_defect    sajet.sys_defect.defect_code%type;
  mc_defect   sajet.sys_defect.defect_code%type;
  v_recid     sajet.temp_api_sn.recid%type;
  v_count     number;
  v_spcvalue  varchar(100);
  v_empid     number;
  v_spcresult number;
  command_id  number;
  logdate     varchar(30);


  csajet2         varchar(1000);
  vtype           varchar(30);
  vserial_no_type varchar(30);
  search_num      number;
  vbarcode        varchar(30);
  vchannel        varchar(30);
  vresult         varchar(30);
  verror_code     varchar(30);
  verror_code_one varchar(30);
  verror_code_id  varchar(100);
  vequipment      varchar(30);
  vdate           varchar(30);
  vserialno       varchar(30);
  cdata           varchar(500);
  cursor defect_item is
    select * from table(sajet.fn_split(verror_code, ','));

  cdefectid varchar(500);

  ctest_item_all clob;
  ctest_item     varchar2(100);
  ctest_data     varchar2(100);

  v_10_no     number;
  v_10_sn     varchar2(1000);
  v_10_ok     varchar2(500);
  v_10_ng     varchar2(500);
  v_10_ok_len number;
  v_10_ng_len number;


begin
  tres := 'Fail,Command fail';
  cmd  := to_number(tsajet1);

  if cmd = 1 then
    sajet.sj_cksys_emp(tsajet2, tres);
    if tres = 'OK' then
      tres := 'OK;OK';
    else
      tres := 'NG;[EC201] EMP NO NG';
    end if;

  elsif cmd = 10 then

    tres    := 'OK';
    v_10_no := tsajet3;

    if v_10_no = 1 then

      declare
        cursor sn is
          select t.serial_number
          from   sajet.g_sn_status t
          where  t.panel_no = (select a.panel_no from sajet.g_sn_status a where a.serial_number = tsajet4)
          order  by t.serial_number desc;
        snn sn%rowtype;
      begin
        for ssn in sn loop
          exit when sn%notfound;
          sajet.sj_ckrt_route(tterminalid, ssn.serial_number, tres);
          if tres = 'OK' then
            tres := 'OK;' || tsajet2 || ';1;OK;';
            goto endcmd10;
          end if;
        end loop;
        tres := 'NG;' || tsajet2 || ';1;NG;';
        <<endcmd10>>
        null;
      end;

    elsif v_10_no = 2 then
      v_10_ok := '';
      v_10_ng := '';
      v_10_sn := '';

      declare
        cursor sn is
          select t1.column_value from table (select fun_splitstr(tsajet4, ',') ids from dual) t1;
        snn sn%rowtype;

      begin
        for ssn in sn loop
          exit when sn%notfound;
          sajet.sj_ckrt_route(tterminalid, ssn.column_value, tres);
          if tres = 'OK' then
            v_10_ok := v_10_ok || 'OK,';
            v_10_sn := v_10_sn || 'OK,';
          else
            v_10_ng := v_10_ng || 'NG,';
            v_10_sn := v_10_sn || 'NG,';
          end if;

        end loop;
      end;

      v_10_ok_len := nvl(length(v_10_ok), 0);
      v_10_ng_len := nvl(length(v_10_ng), 0);

      if v_10_ng_len > 0 then
        tres := 'NG;' || tsajet2 || ';2;' || substr(v_10_sn, 0, length(v_10_sn) - 1) || ';';
      else
        tres := 'OK;' || tsajet2 || ';2;' || substr(v_10_sn, 0, length(v_10_sn) - 1) || ';';
      end if;
    else
      tres := 'NG;COMMAND 10 error.;';
    end if;
  elsif cmd = 11 then
    csajet2 := tsajet2;
    if csajet2 is null then
      tres := 'NG;RESULT;NG;NODATA';
      goto endp_11;
    end if;
    --  100179 FC\100180  FU\100181 通讯
    if tprocessid = 100179 then
      vtype           := 'PANEL';
      vserial_no_type := 'INSERT_CHECK';
    elsif tprocessid = 100180 then
      vtype           := 'PANEL';
      vserial_no_type := 'CHECK';
    elsif tprocessid = 100181 then
      vtype           := 'PCS';
      vserial_no_type := 'CHECK';
    end if;

    select instr(csajet2, ')') into search_num from dual;
    if (search_num > 0) then
      loop
        exit when csajet2 is null;
        select instr(csajet2, ')') into search_num from dual;
        if (search_num <> 0) then
          cdata := substr(csajet2, 1, instr(csajet2, ')') - 1);
          begin
            vbarcode    := substr(cdata, 1, instr(cdata, ',') - 1);
            cdata       := substr(cdata, instr(cdata, ',') + 1);
            vchannel    := substr(cdata, 1, instr(cdata, ',') - 1);
            cdata       := substr(cdata, instr(cdata, ',') + 1);
            vresult     := substr(cdata, 1, instr(cdata, ',') - 1);
            cdata       := substr(cdata, instr(cdata, ',') + 1);
            verror_code := substr(cdata, 1, instr(cdata, ',') - 1);
            cdata       := substr(cdata, instr(cdata, ',') + 1);
            vequipment  := substr(cdata, 1, instr(cdata, ',') - 1);
            cdata       := substr(cdata, instr(cdata, ',') + 1);
            vdate       := substr(cdata, 1, instr(cdata, ',') - 1);
            cdata       := substr(cdata, instr(cdata, ',') + 1);
            vserialno   := cdata;

            begin
              select panel_no
              into   c_panel
              from   sajet.g_sn_status
              where  serial_number = vbarcode and rownum = 1;
            exception
              when others then
                tres := 'NG;RESULT;NG;NO SN;';
                goto endp_11;
            end;
            if vtype = 'PANEL' then

              select serial_number
              into   vbarcode
              from   (select serial_number, rownum no_qty
                   from   (select a.serial_number
                        from   sajet.g_sn_status a
                        where  a.panel_no = c_panel
                        order  by a.serial_number))
              where  no_qty = vchannel;


            end if;
            --check route ,流程不对，不继续往下走
            sajet.sj_ckrt_route(tterminalid, vbarcode, tres);
            if substr(tres, 1, 2) = 'OK' then
              --检查烧录是否重复，重复直接跳出，panelpo不过站
              sajet.sj_ckrt_shaolu(tterminalid, vchannel, vbarcode, vequipment, vdate, vserialno,
                         vserial_no_type, tres);
              if substr(tres, 1, 2) = 'NG' then
                tres := 'NG;RESULT;NG;' || vchannel || ',serial no dup';
                goto endp_11;
              end if;
              if vresult = 'OK' then
                sajet.sj_go(tterminalid, vbarcode, tnow, tres, '001');
              else
                --chenck 是否一次不良
                if verror_code is null then
                  tres := 'NG;RESULT;NG;NO error';
                  goto endp_11;
                end if;
                verror_code_id := '';
                --[A][B][C]  error_code 取多个不良代码
                select replace(replace(verror_code, '[', ''), ']', ',') into verror_code from dual;
                c_defect := substr(verror_code, 1, instr(verror_code, ',') - 1);
                loop
                  if not defect_item%isopen then
                    open defect_item;
                  end if;
                  fetch defect_item
                    into verror_code_one;
                  sajet.sj_get_defectid(verror_code_one, cdefectid);
                  if cdefectid = 0 then
                    --不良代码不存在，报错
                    tres := 'NG;RESULT;NG;' || vchannel || ',error_code not exists';
                    goto endp_11;
                  else
                    verror_code_id := verror_code_id || cdefectid || ';';
                  end if;
                  exit when defect_item%notfound;
                end loop;

                sj_repair_input_record_count(tterminalid, vbarcode, c_defect, '001'); --add by joseph 20151117 增加计数procdure
                select count
                into   v_count
                from   sajet.g_sn_defect_count a
                where  serial_number = vbarcode and a.process_id = tprocessid;
                if v_count >= 2 then
                  sajet.sj_nogo_more(tterminalid, vbarcode, verror_code_id, tnow, tres, tnextproc,
                             '001');
                else
                  tres := 'NG;RESULT;NG;' || vchannel || ',once ng,';
                  goto endp_11;
                end if;


                tres := 'OK';
              end if;

            else
              --流程不对，不继续往下走
              --check serial_no
              --检查是否重复
              sajet.sj_ckrt_shaolu(tterminalid, vchannel, vbarcode, vequipment, vdate, vserialno,
                         vserial_no_type, tres);
              if substr(tres, 1, 2) = 'NG' then
                goto endp_11;
              end if;

              goto next_sn;
            end if;


          exception
            when others then
              tres := 'NG;RESULT;NG;DATA FORMAT ERROR';
              goto endp_11;
          end;

          <<next_sn>>
          csajet2 := substr(csajet2, instr(csajet2, ')') + 1);
        end if;
      end loop;

    end if;

    <<endp_11>>
    if substr(tres, 1, 2) = 'OK' then
      commit;
    else
      rollback;
    end if;
  elsif cmd = 12 then
    tres     := 'OK;TEST_ITEM:OK;' || tsajet4;
    vbarcode := tsajet3;
    if tsajet3 is null then
      tres := 'NG;TEST_ITEM;NG;NODATA';
      goto endp_12;
    end if;
    --  100179 FC\100180  FU\100181 通讯
    if tprocessid = 100179 then
      vtype := 'PANEL';
    elsif tprocessid = 100180 then
      vtype := 'PANEL';
    elsif tprocessid = 100181 then
      vtype := 'PCS';
    end if;

    begin
      select panel_no into c_panel from sajet.g_sn_status where serial_number = tsajet3 and rownum = 1;
    exception
      when others then
        tres := 'NG;TEST_ITEM;NG;NO SN;';
        goto endp_12;
    end;

    if vtype = 'PANEL' then

      select serial_number
      into   vbarcode
      from   (select serial_number, rownum no_qty

           from   (select a.serial_number
                from   sajet.g_sn_status a
                where  a.panel_no = c_panel
                order  by a.serial_number))
      where  no_qty = tsajet4;
    end if;
    ctest_item_all := tsajet5 || ',';
    if ctest_item_all is null then
      tres := 'NG;TEST_ITEM;NG;NO TESTDATA;';
      goto endp_12;
    end if;

    select instr(ctest_item_all, ',') into search_num from dual;
    if (search_num > 0) then
      loop
        exit when length(ctest_item_all) = 0;
        select instr(ctest_item_all, ',') into search_num from dual;
        if (search_num <> 0) then
          cdata          := substr(ctest_item_all, 1, instr(ctest_item_all, ',') - 1);
          ctest_item     := substr(cdata, 1, instr(cdata, ':') - 1);
          ctest_data     := substr(cdata, instr(cdata, ':') + 1);
          ctest_item_all := substr(ctest_item_all, instr(ctest_item_all, ',') + 1);
          if ctest_item is not null then
            insert into sajet.g_ict_test
              (serial_number, update_time, terminal_id, test_item, test_values)
            values
              (vbarcode, sysdate, tterminalid, ctest_item, ctest_data);
          end if;
        end if;

      end loop;
    end if;

    <<endp_12>>
    if substr(tres, 1, 2) = 'OK' then
      commit;
    else
      rollback;
    end if;
  else
    tres := 'NG;[EC102] COMMAND NOT DEFINE.;';
    delete sajet.temp_wip_lock where key_name = 'GETSN';

  end if;
exception
  when others then
    tres := tsajet1 || '-' || tsajet2 || '-' || sqlerrm;
end;


/

