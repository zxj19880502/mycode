create procedure arabbao_sj_getsn_csn(trev in varchar2
													  ,tres out varchar2) is
	v_sn varchar2(100);
begin
	select nvl((select s.serial_number from sajet.g_sn_status s where s.serial_number = trev or s.customer_sn = trev),
				'')
	into   v_sn
	from   dual;
	--SELECT PART_NO INTO PART FROM SAJET.SYS_PART WHERE PART_ID=(SELECT MODEL_ID FROM SAJET.G_SN_STATUS WHERE SERIAL_NUMBER=v_sn);
	tres := v_sn;
exception
	when others then
		tres := '0:SN ERR';
end;


/

