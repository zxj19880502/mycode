create procedure       csbg_function_error_go(tterminalid     in number
														,tsn             in varchar2
														,tdefect         in varchar2
														,tnow            in date
														,temp            in varchar2
														,tres            out varchar2
														,tnextproc       out varchar2
														,cnext_processid in number) is
	clineid    number;
	cstageid   number;
	cprocessid number;
	cstartp    number;
	cendp      number;
	cwo        varchar2(25);
	cmodelid   number;
	crecid     number;
	cempid     number;
	cdefectid  number;
	intime     date;
	outtime    date;
	tprocessid number;
	inflag     boolean;
	outflag    boolean;
	ok         varchar2(25);
begin
	sajet.sj_get_empid(temp, cempid);
	sajet.sj_get_place(tterminalid, clineid, cstageid, cprocessid);
	cprocessid := cnext_processid;
	select b.work_order, b.part_id, in_pdline_time, out_pdline_time, process_id
	into   cwo, cmodelid, intime, outtime, tprocessid
	from   sajet.g_sn_status b
	where  b.serial_number = tsn and rownum = 1;
	ok := 'OK';
	if tprocessid <> cprocessid then
		sajet.sj_chk_wo_input(cwo, ok);
		if ok = 'OK' then
			sajet.sj_wo_input_qty(clineid, cstageid, cprocessid, tterminalid, tsn, tnow, ok, cempid, inflag);
			if inflag then
				intime := tnow;
			end if;
			if outflag then
				outtime := tnow;
			end if;
			sajet.sj_transation_count(clineid, cstageid, cprocessid, cempid, tnow, tsn, cwo, cmodelid, ok, 1);
			sajet.sj_update_sn(clineid, cstageid, cprocessid, tterminalid, tsn, '1', tnow, cempid, intime, outtime);
		end if;
	end if;
	if ok = 'OK' then
		sajet.sj_repair_input(clineid, cstageid, cprocessid, tterminalid, tsn, tdefect, tnow, cempid, cwo, cmodelid);
	end if;
	tres := ok;
exception
	when others then
		tres      := 'sj_nogo error';
		tnextproc := '';
end;


/

