create FUNCTION sj_sum_count(process in VARCHAR2,model in VARCHAR2,shift in VARCHAR2) return Varchar2 IS

v_process_name                   VARCHAR2(50);
v_model_name                   VARCHAR2(50);
v_shift_name                   VARCHAR2(50);
v_qty                   NUMBER(38);
v_qty1                   NUMBER(38);
v_qty2                   NUMBER(38);

begin

  if (to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')>=to_date('08:30','hh24:mi'))
     and (to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')<to_date('20:30','hh24:mi')) then
     
  select d.process_name,c.model_name,sajet.worksshifet_param(a.wip_out_time),count(1) qty
  into  v_process_name,v_model_name,v_shift_name,v_qty
  from sajet.g_sn_travel a,sajet.sys_part b,sajet.sys_model c,sajet.sys_process d,
(select distinct a.serial_number  
from sajet.g_sn_travel a,sajet.sys_part b,sajet.sys_model c,sajet.sys_process d
  where a.process_id=d.process_id(+) and
        a.part_id=b.part_id(+) and b.model_id=c.model_id(+) and
        d.process_name=process and c.model_name=model and sajet.worksshifet_param(a.wip_out_time)=shift and
        TO_CHAR(a.wip_out_time, 'yyyy-mm-dd')=TO_CHAR(SYSDATE, 'yyyy-mm-dd') and 
        to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi') between to_date('08:30','hh24:mi') and
         to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')) m 
  where a.process_id=d.process_id(+) and
        a.part_id=b.part_id(+) and b.model_id=c.model_id(+) and
        d.process_name=process and c.model_name=model and sajet.worksshifet_param(a.wip_out_time)=shift and
        m.serial_number=a.serial_number(+) and 
        TO_CHAR(a.wip_out_time, 'yyyy-mm-dd')=TO_CHAR(SYSDATE, 'yyyy-mm-dd') and 
        to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi') between to_date('08:30','hh24:mi') and
         to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')
  group by d.process_name,c.model_name,sajet.worksshifet_param(a.wip_out_time); 
  return v_qty;
  end if;
  
  if (to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')>=to_date('20:30','hh24:mi')) then
     
  select d.process_name,c.model_name,sajet.worksshifet_param(a.wip_out_time),count(1) qty
  into  v_process_name,v_model_name,v_shift_name,v_qty
  from sajet.g_sn_travel a,sajet.sys_part b,sajet.sys_model c,sajet.sys_process d,
(select distinct a.serial_number
from sajet.g_sn_travel a,sajet.sys_part b,sajet.sys_model c,sajet.sys_process d 
  where a.process_id=d.process_id(+) and
        a.part_id=b.part_id(+) and b.model_id=c.model_id(+) and
        d.process_name=process and c.model_name=model and sajet.worksshifet_param(a.wip_out_time)=shift and
        TO_CHAR(a.wip_out_time, 'yyyy-mm-dd')=TO_CHAR(SYSDATE, 'yyyy-mm-dd') and 
        to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')<>to_date('00:00','hh24:mi') and 
        to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')>=to_date('20:30','hh24:mi') 
        and to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')<=to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi'))m 
  where a.process_id=d.process_id(+) and
        a.part_id=b.part_id(+) and b.model_id=c.model_id(+) and
        d.process_name=process and c.model_name=model and sajet.worksshifet_param(a.wip_out_time)=shift and
        m.serial_number=a.serial_number(+) and 
        TO_CHAR(a.wip_out_time, 'yyyy-mm-dd')=TO_CHAR(SYSDATE, 'yyyy-mm-dd') and 
        to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')<>to_date('00:00','hh24:mi') and 
        to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')>=to_date('20:30','hh24:mi') 
        and to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')<=to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')               
  group by d.process_name,c.model_name,sajet.worksshifet_param(a.wip_out_time);
  return v_qty;
  end if;
  
  if (to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')<to_date('08:30','hh24:mi')) then
    
  select d.process_name,c.model_name,sajet.worksshifet_param(a.wip_out_time),count(1) qty
  into  v_process_name,v_model_name,v_shift_name,v_qty1
  from sajet.g_sn_travel a,sajet.sys_part b,sajet.sys_model c,sajet.sys_process d,
(select distinct a.serial_number
from sajet.g_sn_travel a,sajet.sys_part b,sajet.sys_model c,sajet.sys_process d
  where a.process_id=d.process_id(+) and
        a.part_id=b.part_id(+) and b.model_id=c.model_id(+) and
        d.process_name=process and c.model_name=model and sajet.worksshifet_param(a.wip_out_time)=shift and
        TO_CHAR(a.wip_out_time, 'yyyy-mm-dd')=TO_CHAR(SYSDATE-1, 'yyyy-mm-dd') and 
        to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')>=to_date('20:30','hh24:mi') 
        and to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')<to_date('24:00','hh24:mi'))m
  where a.process_id=d.process_id(+) and
        a.part_id=b.part_id(+) and b.model_id=c.model_id(+) and
        d.process_name=process and c.model_name=model and sajet.worksshifet_param(a.wip_out_time)=shift and
        m.serial_number=a.serial_number(+) and 
        TO_CHAR(a.wip_out_time, 'yyyy-mm-dd')=TO_CHAR(SYSDATE-1, 'yyyy-mm-dd') and 
        to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')>=to_date('20:30','hh24:mi') 
        and to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')<to_date('24:00','hh24:mi')               
  group by d.process_name,c.model_name,sajet.worksshifet_param(a.wip_out_time);
  
  select d.process_name,c.model_name,sajet.worksshifet_param(a.wip_out_time),count(1) qty
  into  v_process_name,v_model_name,v_shift_name,v_qty2
  from sajet.g_sn_travel a,sajet.sys_part b,sajet.sys_model c,sajet.sys_process d,
(select distinct a.serial_number
from sajet.g_sn_travel a,sajet.sys_part b,sajet.sys_model c,sajet.sys_process d
  where a.process_id=d.process_id(+) and
        a.part_id=b.part_id(+) and b.model_id=c.model_id(+) and
        d.process_name=process and c.model_name=model and sajet.worksshifet_param(a.wip_out_time)=shift and
        TO_CHAR(a.wip_out_time, 'yyyy-mm-dd')=TO_CHAR(SYSDATE, 'yyyy-mm-dd') and 
        to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')<=to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi'))n
  where a.process_id=d.process_id(+) and
        a.part_id=b.part_id(+) and b.model_id=c.model_id(+) and
        d.process_name=process and c.model_name=model and sajet.worksshifet_param(a.wip_out_time)=shift and 
        n.serial_number=a.serial_number(+) and 
        TO_CHAR(a.wip_out_time, 'yyyy-mm-dd')=TO_CHAR(SYSDATE, 'yyyy-mm-dd') and 
        to_date(TO_CHAR(a.wip_out_time,'hh24:mi'),'hh24:mi')<=to_date(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')              
  group by d.process_name,c.model_name,sajet.worksshifet_param(a.wip_out_time);
  v_qty:=v_qty1+v_qty2;
  return v_qty; 
  end if;

  
EXCEPTION
WHEN OTHERS THEN
RETURN '0';
  
end ;


/

