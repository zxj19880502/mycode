create trigger TG_CUS_VENDOR_FTP
  before insert
  on CUS_VENDOR_FTP
  for each row
declare
	-- local variables here
begin
	select sys_guid() into :new.keyid from dual;
end tg_cus_vendor_ftp;


/

