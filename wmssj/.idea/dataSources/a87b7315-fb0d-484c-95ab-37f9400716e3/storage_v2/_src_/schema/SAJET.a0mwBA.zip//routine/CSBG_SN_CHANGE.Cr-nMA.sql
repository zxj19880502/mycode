create procedure       csbg_sn_change(trev in varchar2
												,tsn  in varchar2
												,tres out varchar2) is
	c_wo1    varchar2(25);
	c_model1 number;
	c_ver1   varchar2(10);
	c_wo2    varchar2(25);
	c_model2 number;
	c_ver2   varchar2(10);
begin
	--SN1 的工單及機種
	select work_order, part_id, version into c_wo1, c_model1, c_ver1 from sajet.g_sn_status where serial_number = tsn;
	--SN2 的工單及機種
	select work_order, part_id, version into c_wo2, c_model2, c_ver2 from sajet.g_sn_status where serial_number = trev;
	if c_model1 <> c_model2 then
		tres := 'PART DIFFERENT';
	elsif c_ver1 <> c_ver2 then
		tres := 'VERSION DIFFERENT';
	else
		--UPDATE SN1 的工單號
		update sajet.g_sn_status set work_order = c_wo2 where serial_number = tsn;
		--UPDATE SN2 的工單號
		update sajet.g_sn_status set work_order = c_wo1 where serial_number = trev;
		tres := 'OK';
	end if;
exception
	when others then
		tres := 'SN_CHANGE ERROR';
end;


/

