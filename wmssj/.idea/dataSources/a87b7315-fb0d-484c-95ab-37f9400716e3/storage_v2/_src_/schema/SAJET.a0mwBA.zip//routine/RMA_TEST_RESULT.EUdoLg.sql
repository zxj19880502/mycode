create function       
       RMA_TEST_RESULT(svalue in varchar2) return varchar2 is
str varchar2(16);
begin
  if svalue = '0' then
    str := 'Quotation';
  elsif svalue = '1' then
    str := 'Change';
  elsif svalue = '2' then
    str := 'Return';
  elsif svalue = '3' then
    str := 'NTF';
  else
    str := svalue;
  end if;
  return str;
end;


/

