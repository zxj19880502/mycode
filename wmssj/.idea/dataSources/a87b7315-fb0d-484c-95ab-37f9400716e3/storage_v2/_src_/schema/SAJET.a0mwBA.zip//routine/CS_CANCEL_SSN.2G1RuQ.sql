create procedure       cs_cancel_ssn(tsn  in varchar2
											   ,tres out varchar2
											   ,trev in varchar2
											   ,temp in number) is
	csn varchar2(25);
begin
	select shipping_sn into csn from sajet.g_sn_ssn_map where serial_number = tsn and rownum = 1;
	if trev = csn then
		delete from sajet.g_sn_ssn_map where serial_number = tsn and rownum = 1;
		tres := 'OK';
	else
		tres := 'SSN NG';
	end if;
exception
	when others then
		tres := 'cs_cancel_ssn error';
end;


/

