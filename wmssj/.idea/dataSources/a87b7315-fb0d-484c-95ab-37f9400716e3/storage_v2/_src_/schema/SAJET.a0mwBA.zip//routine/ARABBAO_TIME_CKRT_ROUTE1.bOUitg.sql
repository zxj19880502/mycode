create procedure       
-- Modify 2018/08/09
arabbao_time_ckrt_route1(terminalid in varchar2, tsn in varchar2, tres out varchar2) as
	err_result      varchar2(1);
	current_process number;
	processid       number;
	routeid         number;
	workorder       varchar2(25);
	nextprocess     number;
	routename       varchar2(50);
	inputprocess    number;
	nextprocessname varchar2(50);
	processname     varchar2(50);
	outprocesstime  date;
	time_diff       number;
begin
	tres := 'SN ERROR';
	select current_status, a.process_id, c.process_name pname, work_order, route_id, next_process, b.process_name,
		   a.out_process_time
	into   err_result, current_process, processname, workorder, routeid, nextprocess, nextprocessname, outprocesstime
	from   sajet.g_sn_status a, sajet.sys_process b, sajet.sys_process c
	where  serial_number = tsn and a.next_process = b.process_id(+) and a.process_id = c.process_id(+) and rownum = 1;
	tres := 'NG,Terminal error';
	select process_id into inputprocess from sajet.sys_terminal where terminal_id = terminalid and rownum = 1;
	select (sysdate - outprocesstime) * 24 into time_diff from dual;
	--if time_diff > 17 then
	if (nextprocess is null) or (nextprocess = 0) then
		if current_process = 0 then
			select start_process_id into processid from sajet.g_wo_base where work_order = workorder and rownum = 1;
			if processid = inputprocess then
				if time_diff > 17 then
					tres := 'OK';
				else
					tres := 'PLEASE TIME_DIFF 17H';
				end if;
			else
				begin
					select process_name
					into   nextprocessname
					from   sajet.sys_process
					where  process_id = processid and rownum = 1;
					tres := nextprocessname;
				exception
					when others then
						select route_name into routename from sajet.sys_route where route_id = routeid and rownum = 1;
						if err_result = '0' then
							tres := 'WO Start Process NG';
						else
							tres := 'REPAIR NG';
						end if;
				end;
				--end if;
			end if;
		else
			begin
				select next_process_id
				into   processid
				from   sajet.sys_route_detail
				where  result = err_result and route_id = routeid and process_id = current_process and
					   next_process_id = inputprocess and rownum = 1;
				if time_diff > 17 then
					tres := 'OK';
				else
					tres := 'PLEASE TIME_DIFF 17H';
				end if;
			exception
				when others then
					begin
						select next_process_id, b.process_name
						into   processid, nextprocessname
						from   sajet.sys_route_detail a, sajet.sys_process b
						where  route_id = routeid and a.next_process_id = b.process_id and
							   a.seq =
							   (select max(seq)
								from   sajet.sys_route_detail
								where  process_id = current_process and route_id = routeid and result = err_result);
						tres := nextprocessname;
					exception
						when others then
							if err_result = '0' then
								tres := 'ROUTE END (' || processname || ')';
							else
								tres := 'REPAIR NG';
							end if;
					end;
			end;
			--end if;
		end if;
	else
		if nextprocess = inputprocess then
			if time_diff > 17 then
				tres := 'OK';
			else
				tres := 'PLEASE TIME_DIFF 17H';
			end if;
		else
			tres := nextprocessname;
		end if;
	end if;
	--END IF;
exception
	when others then
		tres := 'call sj_ckrt_route error' || tres;
end;


/

