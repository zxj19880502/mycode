create trigger TG_CUS_CLOG_PART_DETAIL
  before insert
  on CUS_CLOG_PART_DETAIL
  for each row
declare
	-- local variables here
begin
	select sys_guid() into :new.keyid from dual;
end tg_cus_clog_part_detail;


/

