create procedure command_code_ts2(tlineid     in number
											,tstageid    in number
											,tprocessid  in number
											,tterminalid in number
											,tnow        in date
											,trev        in varchar2
											,tres        out varchar2
											,tnextproc   out varchar2) is
	tpmt1            varchar2(25);
	tpmt2            varchar2(25);
	tpmt3            varchar2(128);
	tpmt4            varchar2(128);
	tpmt5            varchar2(128);
	tsajet4ton       varchar2(4096);
	tsajet5ton       varchar2(4096);
	c_buffer         varchar2(4096);
	c_head           number;
	cmd              number;
	c_number         number;
	c_start          number;
	c_end            number;
	c_psn            varchar2(100);
	c_temp           varchar2(255);
	c_item           sajet.sys_spc.spc_item%type;
	c_value          sajet.g_spc.spc_value%type;
	c_defect         sajet.sys_defect.defect_code%type;
	c_wo             sajet.g_sn_status.work_order%type;
	c_dbid           varchar2(20);
	c_type           number;
	c_eventid        number;
	t_type           varchar2(25);
	check_status     varchar2(10);
	msl_status       varchar2(30);
	c_factory        number;
	c_model          number;
	c_pkg_name       varchar(64);
	n_carton_spec    number;
	n_pallet_spec    number;
	n_ccqty          number;
	n_pqty           number;
	c_sta            varchar2(10);
	c_csn            varchar(64);
	c_ccarton        varchar(64);
	c_cpallet        varchar(64);
	c_cnt            number;
	c_carton_modelid number;
	c_pallet_modelid number;
	c_csn1           varchar2(64);
	c51_csn1         varchar2(64);
	c_pkspec_id      number;
begin
	tres := 'Fail,Command fail';
	--
	if substr(trev, length(trev), 1) = ';' then
		c_buffer := trev;
	else
		c_buffer := trev || ';';
	end if;

	c_number := 1;
	c_start  := 1;
	c_end    := instr(c_buffer, ';', c_start, c_number);

	if c_end <= 3 then
		begin
			cmd := substr(c_buffer, c_start, c_end - c_start);
			-- INCREASE INDEX
			c_number := c_number + 1;
			c_start  := c_end + 1;
		exception
			when others then
				cmd := 999;
		end;
	else
		cmd := 999;
	end if;
	--

	if cmd = 1 then
		--?查?工?
		c_end := instr(c_buffer, ';', 1, c_number);
	
		if (c_end - c_start) <= 25 then
			tpmt2 := substr(c_buffer, c_start, c_end - c_start);
			sajet.sj_cksys_emp(tpmt2, tres);
		
			if substr(tres, 1, 2) = 'OK' then
				tres := 'OK;OK;';
			else
				tres := 'NG;[EC201] Emp Error!;'; --||' ['||tsajet2||']';
			end if;
		else
			tres := 'NG;[EC201] Emp Error!;';
		end if;
	
	elsif cmd = 2 --生產序號檢查
	 then
		c_end := instr(c_buffer, ';', 1, c_number);
	
		if (c_end - c_start) <= 25 then
			tpmt2 := substr(c_buffer, c_start, c_end - c_start);
		
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3 := substr(c_buffer, c_start, c_end - c_start); -- SN
				tres  := 'NG;[EC202]SN ERROR';
				begin
					select serial_number
					into   c_psn
					from   g_sn_status
					where  serial_number = tpmt3 or customer_sn = tpmt3;
					sajet.cus_ckrt_sn(c_psn, tres);
				exception
					when others then
						tres := 'NG;[EC202]SN ERROR';
				end;
				--SAJET.SJ_CKRT_SN_PSN(tsajet2, tres, c_PSN);
				if substr(tres, 1, 2) = 'OK' then
					sajet.sj_ckrt_route(tterminalid, c_psn, tres);
					if substr(tres, 1, 2) = 'OK' then
						tres := 'OK;OK;';
					else
						tres := 'NG;[EC909]途程錯誤:' || tres || ';';
					end if;
				else
					tres := 'NG;' || tres || ';';
				end if;
			else
				tres := 'NG;[EC202] SN ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
	elsif cmd = 3 --生產條碼與客戶條碼Mapping  3;001;201902500027;PA191025000212A;
	 then
		c_end := instr(c_buffer, ';', 1, c_number);
		if (c_end - c_start) <= 25 then
			tpmt2    := substr(c_buffer, c_start, c_end - c_start); --EMP NO
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3    := substr(c_buffer, c_start, c_end - c_start); -- SN
				c_number := c_number + 1;
				c_start  := c_end + 1;
				c_end    := instr(c_buffer, ';', 1, c_number);
				if (c_end - c_start) <= 25 then
					tpmt4 := substr(c_buffer, c_start, c_end - c_start); -- CSN
					select serial_number, work_order
					into   c_psn, c_wo
					from   g_sn_status
					where  serial_number = tpmt3 or customer_sn = tpmt3;
					tres := 'OK';
				
					select count(*)
					into   c_cnt
					from   sajet.g_wo_param
					where  work_order = c_wo
						  -- and module_name = 'CUSTOMER SN 2 RULE' and parame_name = 'Customer SN Code'                         
						  
						   and module_name = 'CUSTOMER SN2 RULE' and parame_name = 'Customer SN2 Code' and
						   parame_item = 'Code';
				
				
					if c_cnt = 0 then
						tres := 'OK';
					else
						tres := '[EC203-3]CMD 3 HAS CUSTOMER SN2 RULE';
					end if;
				
					--SAJET.SJ_CKRT_SN_PSN(tsajet2, tres, c_PSN);
					if substr(tres, 1, 2) = 'OK' then
					
						sajet.sj_psn_ckrt_route(tterminalid, c_psn, tres);
					
						if substr(tres, 1, 2) = 'OK' then
							sajet.hipro_cus_ckrt_csn_2(tpmt4, c_psn, tpmt2, tres);
							if substr(tres, 1, 2) = 'OK' then
								--SAJET.HIPRO_CUS_SN_MAPPING_GO(TTERMINALID,TPMT2,SYSDATE,C_psn,TPMT4,'N/A',TRES);
								begin
									select count(*) into c_cnt from g_sn_customersn2 where serial_number = c_psn;
									if c_cnt = 0 then
									
										insert into g_sn_customersn2
											(work_order, serial_number, model_id, pdline_id, stage_id, process_id,
											 terminal_id, out_process_time, pallet_no, carton_no, emp_id, customer_sn,
											 box_no)
											select work_order, serial_number, part_id, pdline_id, stage_id, process_id,
												   terminal_id, sysdate, pallet_no, carton_no, 0, tpmt4, box_no
											from   g_sn_status
											where  serial_number = c_psn and rownum = 1;
									else
										update g_sn_customersn2 set customer_sn = tpmt4 where serial_number = c_psn;
									end if;
								exception
									when others then
										tres := 'NG;INSERT CUSTOMERSN ERROR';
								end;
								if substr(tres, 1, 2) = 'OK' then
									tres := 'OK;OK;';
								else
									tres := 'NG;' || tres || ':';
								end if;
							else
								tres := 'NG;' || tres || ':';
							end if;
						else
							tres := 'NG;[EC909]途程錯誤:' || tres || ';';
						end if;
					else
						tres := 'NG;' || tres || ';';
					end if;
				
				
				else
					tres := 'NG;[EC203] CSN ERROR;';
				end if;
			else
				tres := 'NG;[EC202] SN ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
	
	elsif cmd = 4 --生產條碼與兩個客戶條碼Mapping  4;001;201901700001;PA201910250006;C2191025000456B
	 then
		c_end := instr(c_buffer, ';', 1, c_number);
		if (c_end - c_start) <= 25 then
			tpmt2    := substr(c_buffer, c_start, c_end - c_start); --EMP NO
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3    := substr(c_buffer, c_start, c_end - c_start); -- SN
				c_number := c_number + 1;
				c_start  := c_end + 1;
				c_end    := instr(c_buffer, ';', 1, c_number);
				if (c_end - c_start) <= 25 then
					tpmt4    := substr(c_buffer, c_start, c_end - c_start); -- CSN
					c_number := c_number + 1;
					c_start  := c_end + 1;
					c_end    := instr(c_buffer, ';', 1, c_number);
					if (c_end - c_start) <= 25 then
						tpmt5 := substr(c_buffer, c_start, c_end - c_start); -- CSN2
						begin
							select count(*)
							into   c_cnt
							from   g_sn_status
							where  serial_number = tpmt3 or customer_sn = tpmt3;
							if c_cnt = 0 then
								select serial_number, customer_sn
								into   c_psn, c_csn1
								from   g_sn_customersn2
								where  serial_number = tpmt3 or customer_sn = tpmt3 or customer_sn2 = tpmt3;
							
							else
								select serial_number, customer_sn, work_order
								into   c_psn, c_csn1, c_wo
								from   g_sn_status
								where  serial_number = tpmt3 or customer_sn = tpmt3;
							end if;
							cus_ckrt_sn(c_psn, tres);
							--TRES:='OK';
						exception
							when others then
								tres := '[EC202-1]生產序號不存在' || c_psn;
						end;
					
						select count(*)
						into   c_cnt
						from   sajet.g_wo_param
						where  work_order = c_wo
							  -- and module_name = 'CUSTOMER SN 2 RULE' and   parame_name = 'Customer SN Code' and
							   and module_name = 'CUSTOMER SN2 RULE' and parame_name = 'Customer SN2 Code' and
							   parame_item = 'Code';
					
						if c_cnt <> 0 then
							--原?是=0
							sajet.cus_ckrt_sn(c_psn, tres);
						else
							tres := '[EC203-3]CMD 4 NOT FOUND CUSTOMER SN2 RULE';
						end if;
					
						--SAJET.SJ_CKRT_SN_PSN(tsajet2, tres, c_PSN);
						if substr(tres, 1, 2) = 'OK' then
							sajet.sj_psn_ckrt_route(tterminalid, c_psn, tres);
							if substr(tres, 1, 2) = 'OK' then
							
								sajet.hipro_cus_ckrt_csn_2(tpmt4, c_psn, tpmt2, tres);
								if substr(tres, 1, 2) = 'OK' then
									sajet.hipro_cus_ckrt_csn2_2(tpmt5, c_psn, tpmt2, tres);
								end if;
								if substr(tres, 1, 2) = 'OK' then
								
									--SAJET.HIPRO_CUS_SN_MAPPING_GO(TTERMINALID,TPMT2,SYSDATE,C_psn,TPMT4,'N/A',TRES);
									begin
										select count(*) into c_cnt from g_sn_customersn2 where serial_number = c_psn;
										if c_cnt = 0 then
										
											insert into g_sn_customersn2
												(work_order, serial_number, model_id, pdline_id, stage_id, process_id,
												 terminal_id, out_process_time, pallet_no, carton_no, emp_id,
												 customer_sn, customer_sn2, box_no)
												select work_order, serial_number, part_id, pdline_id, stage_id,
													   process_id, terminal_id, sysdate, pallet_no, carton_no, 0, tpmt4,
													   tpmt5, box_no
												from   g_sn_status
												where  serial_number = c_psn and rownum = 1;
										else
										
											update g_sn_customersn2
											set    customer_sn = tpmt4, customer_sn2 = tpmt5
											where  serial_number = c_psn;
										end if;
									exception
										when others then
											tres := '[EC202-1]INSERT CUSTOMERSN2 ERROR';
									end;
									if substr(tres, 1, 2) = 'OK' then
										tres := 'OK;OK;';
									else
										tres := 'NG;' || tres || ':';
									end if;
								else
									tres := 'NG;' || tres || ':';
								end if;
							else
								tres := 'NG;[EC909]途程錯誤:' || tres || ';';
							end if;
						else
							tres := 'NG;' || tres || ';';
						end if;
					else
						tres := 'NG;[EC203] CSN2 ERROR';
					end if;
				else
					tres := 'NG;[EC203] CSN ERROR;';
				end if;
			else
				tres := 'NG;[EC202] SN ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
	
	elsif cmd = 5 then
		--5;001;201901700001;C20191025008;P20191025008
		c_end := instr(c_buffer, ';', 1, c_number);
		if (c_end - c_start) <= 25 then
			tpmt2    := substr(c_buffer, c_start, c_end - c_start); --EMP NO
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3    := substr(c_buffer, c_start, c_end - c_start); -- SN/CSN
				c_number := c_number + 1;
				c_start  := c_end + 1;
				c_end    := instr(c_buffer, ';', 1, c_number);
				if (c_end - c_start) <= 25 then
					tpmt4    := substr(c_buffer, c_start, c_end - c_start); -- CARTON
					c_number := c_number + 1;
					c_start  := c_end + 1;
					c_end    := instr(c_buffer, ';', 1, c_number);
					if (c_end - c_start) <= 25 then
						tpmt5 := substr(c_buffer, c_start, c_end - c_start); -- PALLET
						sajet.cus_check_rule(tpmt4, 'CARTON NO RULE', 'Carton No Code', 'C', tpmt3, tres);
						if substr(tres, 1, 2) = 'OK' then
							sajet.cus_check_rule(tpmt5, 'PALLET NO RULE', 'Pallet No Code', 'P', tpmt3, tres);
							if substr(tres, 1, 2) = 'OK' then
								begin
									select serial_number, customer_sn
									into   c_psn, c_csn1
									from   g_sn_customersn2
									where  serial_number = tpmt3 or customer_sn = tpmt3 or customer_sn2 = tpmt3;
									cus_ckrt_sn(c_psn, tres);
								exception
									when others then
										tres := '[EC202-1]生產序號不存在';
								end;
								if substr(tres, 1, 2) = 'OK' then
									sajet.sj_psn_ckrt_route(tterminalid, c_psn, tres);
									if substr(tres, 1, 2) = 'OK' then
										-- modify by emily
										select x.work_order, x.part_id, f.pkspec_name, y.carton_capacity,
											   y.pallet_capacity, y.pkspec_id
										into   c_wo, c_model, c_pkg_name, n_carton_spec, n_pallet_spec, c_pkspec_id
										from   g_sn_status x, g_pack_spec y, sys_pkspec f
										where  x.work_order = y.work_order(+) and rownum = 1 and
											   x.serial_number = c_psn and f.pkspec_id(+) = y.pkspec_id;
									
										cus_check_carton(tterminalid, c_wo, c_model, tpmt2, c_pkg_name, tpmt4, tpmt5,
														 c_pkspec_id, tres);
									
										if substr(tres, 1, 2) = 'OK' then
										
											begin
												select nvl(part_id, 0)
												into   c_carton_modelid
												from   g_sn_status
												where  carton_no = tpmt4 and rownum = 1;
												if c_model <> c_carton_modelid then
													tres := 'NG;[EC202-5]SN AND CARTON MODEL IS DIFFENT';
												end if;
											
											exception
												when others then
													if tres = 'OK;NEW' then
														c_carton_modelid := c_model;
													else
														c_carton_modelid := 0;
													end if;
											end;
										
										
										end if;
									
									
										if substr(tres, 1, 2) = 'OK' then
											select x.serial_number, nvl(y.customer_sn, 'N/A'), x.carton_no, x.pallet_no
											into   c_psn, c_csn, c_ccarton, c_cpallet
											from   g_sn_status x, g_sn_customersn2 y
											where  x.serial_number = c_psn and x.serial_number = y.serial_number;
										
											if c_csn <> 'N/A' then
												if c_ccarton = 'N/A' then
												
													--?站之前?csn1替?掉原CSN  ADD BY EMILY 2019/12/21
													begin
														select customer_sn
														into   c51_csn1
														from   sajet.g_sn_customersn2
														where  serial_number = c_psn;
													exception
														when others then
															c51_csn1 := 'N/A';
															tres     := '[EC51]SN NO csn1: ' || c_psn;
															goto comm5;
													end;
												
												
													update g_sn_status
													set    carton_no = tpmt4, pallet_no = tpmt5, customer_sn = c51_csn1
													where  serial_number = c_psn;
													sj_go(tterminalid, c_psn, sysdate, tres, tpmt2);
													if substr(tres, 1, 2) = 'OK' then
														select count(serial_number)
														into   n_ccqty
														from   g_sn_status
														where  carton_no = tpmt4;
														select count(distinct a.carton_no)
														into   n_pqty
														from   g_sn_status a, g_pack_carton b
														where  a.carton_no = b.carton_no and pallet_no = tpmt5 and
															   b.close_flag = 'Y';
														if n_ccqty = n_carton_spec then
															update g_pack_carton
															set    close_flag = 'Y'
															where  carton_no = tpmt4;
															select count(distinct a.carton_no)
															into   n_pqty
															from   g_sn_status a, g_pack_carton b
															where  a.carton_no = b.carton_no and pallet_no = tpmt5 and
																   b.close_flag = 'Y';
														end if;
													
														if n_pqty = n_pallet_spec then
															update g_pack_pallet
															set    close_flag = 'Y'
															where  pallet_no = tpmt5;
														end if;
														update g_sn_status
														set    customer_sn = c_csn1
														where  serial_number = c_psn;
														update g_sn_customersn2
														set    process_id = tprocessid, terminal_id = tterminalid
														where  serial_number = c_psn;
														tres := 'OK;OK;' || to_char(n_ccqty) || '/' ||
																to_char(n_carton_spec) || ';' || to_char(n_pqty) || '/' ||
																to_char(n_pallet_spec) || ';';
													else
														tres := '[EC909]' || tres || ';';
													end if;
												else
													tres := '[EC202]SN IN CARTON: ' || c_ccarton;
												end if;
											
											else
												tres := '[EC202-5]NOT MAPPING CUSTOMER SN';
											end if;
										end if;
									else
										tres := 'NG;[EC909]' || tres || ';';
									end if;
								else
									tres := 'NG;' || tres;
								end if;
							else
								tres := 'NG;' || tres || ';';
							end if;
						else
							tres := 'NG;' || tres || ';';
						end if;
					
					else
						tres := 'NG;[EC302]PALLET NO ERROR';
					end if;
				
				else
					tres := 'NG;[EC301] CARTON ERROR;';
				end if;
			else
				tres := 'NG;[EC202] SN ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
		if substr(tres, 1, 2) <> 'OK' then
			begin
				select serial_number, customer_sn
				into   c_psn, c_csn1
				from   g_sn_customersn2
				where  serial_number = tpmt3 or customer_sn = tpmt3 or customer_sn2 = tpmt3;
				select count(*) into c_cnt from g_sn_customersn2 where serial_number = c_psn;
				if c_cnt > 0 then
					delete g_sn_customersn2 where serial_number = c_psn;
				end if;
			exception
				when no_data_found then
					tres := tres;
			end;
		end if;
	
	
		<<comm5>>
		null;
	
	elsif cmd = 51 then
		c_end := instr(c_buffer, ';', 1, c_number);
		if (c_end - c_start) <= 25 then
			tpmt2    := substr(c_buffer, c_start, c_end - c_start); --EMP NO
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3    := substr(c_buffer, c_start, c_end - c_start); -- SN/CSN
				c_number := c_number + 1;
				c_start  := c_end + 1;
				c_end    := instr(c_buffer, ';', 1, c_number);
				if (c_end - c_start) <= 25 then
					tpmt4    := substr(c_buffer, c_start, c_end - c_start); -- CARTON
					c_number := c_number + 1;
					c_start  := c_end + 1;
					c_end    := instr(c_buffer, ';', 1, c_number);
					if (c_end - c_start) <= 25 then
						tpmt5 := substr(c_buffer, c_start, c_end - c_start); -- PALLET
						sajet.cus_check_rule_51(tpmt4, 'CARTON NO RULE', 'Carton No Code', 'C', tpmt3, tres);
						if substr(tres, 1, 2) = 'OK' then
							sajet.cus_check_rule_51(tpmt5, 'PALLET NO RULE', 'Pallet No Code', 'P', tpmt3, tres);
							if substr(tres, 1, 2) = 'OK' then
								begin
									select serial_number, customer_sn
									into   c_psn, c_csn1
									from   g_sn_status
									where  serial_number = tpmt3 or customer_sn = tpmt3;
									--Cus_Ckrt_Sn(C_psn,TRES);
								exception
									when others then
										tres := '[EC202-1]生產序號不存在';
								end;
								if substr(tres, 1, 2) = 'OK' then
									sajet.sj_psn_ckrt_route(tterminalid, c_psn, tres);
									if substr(tres, 1, 2) = 'OK' then
										sajet.hipro_cus_ckrt_csn_2(tpmt3, c_psn, tpmt2, tres); --SAJET.HIPRO_CUS_CKRT_CSN_2(C_CSN1,C_psn,tpmt2,TRES);
										if substr(tres, 1, 2) = 'OK' then
											select x.work_order, x.part_id, f.pkspec_name, y.carton_capacity,
												   y.pallet_capacity, y.pkspec_id
											into   c_wo, c_model, c_pkg_name, n_carton_spec, n_pallet_spec, c_pkspec_id
											from   g_sn_status x, g_pack_spec y, sys_pkspec f
											where  x.work_order = y.work_order(+) and rownum = 1 and
												   x.serial_number = c_psn and y.pkspec_id = f.pkspec_id(+);
										
											cus_check_carton(tterminalid, c_wo, c_model, tpmt2, c_pkg_name, tpmt4,
															 tpmt5, c_pkspec_id, tres);
										
											if substr(tres, 1, 2) = 'OK' then
											
												begin
													select nvl(part_id, 0)
													into   c_carton_modelid
													from   g_sn_status
													where  carton_no = tpmt4 and rownum = 1;
													if c_model <> c_carton_modelid then
														tres := 'NG;[EC202-5]SN AND CARTON MODEL IS DIFFENT';
													end if;
												
												exception
													when others then
														if tres = 'OK;NEW' then
															c_carton_modelid := c_model;
														else
															c_carton_modelid := 0;
														end if;
												end;
											
											
											end if;
										
										
											if substr(tres, 1, 2) = 'OK' then
												select x.serial_number, nvl(x.customer_sn, 'N/A'), x.carton_no,
													   x.pallet_no
												into   c_psn, c_csn, c_ccarton, c_cpallet
												from   g_sn_status x
												where  x.serial_number = c_psn;
											
												if c_csn <> 'N/A' then
													if c_ccarton = 'N/A' then
													
														update g_sn_status
														set    carton_no = tpmt4, pallet_no = tpmt5
														where  serial_number = c_psn;
													
														sj_go(tterminalid, c_psn, sysdate, tres, tpmt2);
														if substr(tres, 1, 2) = 'OK' then
															select count(serial_number)
															into   n_ccqty
															from   g_sn_status
															where  carton_no = tpmt4;
															select count(distinct a.carton_no)
															into   n_pqty
															from   g_sn_status a, g_pack_carton b
															where  a.carton_no = b.carton_no and pallet_no = tpmt5 and
																   b.close_flag = 'Y';
															if n_ccqty = n_carton_spec then
																update g_pack_carton
																set    close_flag = 'Y'
																where  carton_no = tpmt4;
																select count(distinct a.carton_no)
																into   n_pqty
																from   g_sn_status a, g_pack_carton b
																where  a.carton_no = b.carton_no and pallet_no = tpmt5 and
																	   b.close_flag = 'Y';
															end if;
														
															if n_pqty = n_pallet_spec then
																update g_pack_pallet
																set    close_flag = 'Y'
																where  pallet_no = tpmt5;
															end if;
															--UPDATE G_SN_STATUS SET CUSTOMER_SN=C_CSN1 WHERE SERIAL_NUMBER=C_PSN;
															--UPDATE G_SN_CUSTOMERSN2 SET PROCESS_ID=tprocessid,TERMINAL_ID=tterminalid WHERE SERIAL_NUMBER=C_PSN;
															tres := 'OK;OK;' || to_char(n_ccqty) || '/' ||
																	to_char(n_carton_spec) || ';' || to_char(n_pqty) || '/' ||
																	to_char(n_pallet_spec) || ';';
														else
															tres := '[EC909]' || tres || ';';
														end if;
													else
														tres := '[EC202]SN IN CARTON: ' || c_ccarton;
													end if;
												
												else
													tres := '[EC202-5]NOT MAPPING CUSTOMER SN';
												end if;
											end if;
										else
											tres := 'NG;' || tres || ';';
										end if;
									end if;
								else
									tres := 'NG;' || tres;
								end if;
							else
								tres := 'NG;' || tres || ';';
							end if;
						else
							tres := 'NG;' || tres || ';';
						end if;
					
					else
						tres := 'NG;[EC302]PALLET NO ERROR';
					end if;
				
				else
					tres := 'NG;[EC301] CARTON ERROR;';
				end if;
			else
				tres := 'NG;[EC202] SN ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
		<<comm51>>
		null;
	elsif cmd = 6 then
		c_end := instr(c_buffer, ';', 1, c_number);
		if (c_end - c_start) <= 25 then
			tpmt2    := substr(c_buffer, c_start, c_end - c_start); --EMP NO
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3 := substr(c_buffer, c_start, c_end - c_start); -- CARTON
				begin
					select close_flag into c_sta from sajet.g_pack_carton where carton_no = tpmt3;
					if c_sta = 'Y' then
						tres := 'NG;[EC301-5]CARTON ALREADY CLOSE';
					else
						update g_pack_carton set close_flag = 'Y' where carton_no = tpmt3;
						select count(distinct a.carton_no)
						into   n_ccqty
						from   g_sn_status a, g_pack_carton b
						where  a.carton_no = b.carton_no and pallet_no = tpmt5 and b.close_flag = 'Y';
						if n_pqty = n_pallet_spec then
							update g_pack_pallet set close_flag = 'Y' where pallet_no = tpmt5;
						end if;
						tres := 'OK;OK;';
					end if;
				exception
					when no_data_found then
						tres := 'NG;[EC301-1] CARTON IS NOT FOUND';
				end;
			else
				tres := 'NG;[EC301] CARTON ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
	elsif cmd = 7 then
		c_end := instr(c_buffer, ';', 1, c_number);
		if (c_end - c_start) <= 25 then
			tpmt2    := substr(c_buffer, c_start, c_end - c_start); --EMP NO
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3 := substr(c_buffer, c_start, c_end - c_start); -- PALLET
				begin
					select close_flag into c_sta from sajet.g_pack_pallet where pallet_no = tpmt3;
					if c_sta = 'Y' then
						tres := 'NG;[EC301-5]PALLET ALREADY CLOSE';
					else
						update g_pack_pallet set close_flag = 'Y' where pallet_no = tpmt3;
						update g_pack_carton
						set    close_flag = 'Y'
						where  carton_no in (select distinct carton_no from g_sn_status where pallet_no = tpmt3);
						tres := 'OK;OK;';
					end if;
				exception
					when no_data_found then
						tres := 'NG;[EC302-1] PALLET IS NOT FOUND';
				end;
			else
				tres := 'NG;[EC301] PALLET ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
	elsif cmd = 9 then
		c_end := instr(c_buffer, ';', 1, c_number);
		if (c_end - c_start) <= 25 then
			tpmt2    := substr(c_buffer, c_start, c_end - c_start); --EMP NO
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3 := substr(c_buffer, c_start, c_end - c_start); -- PALLET
				begin
					select close_flag into c_sta from sajet.g_pack_pallet where pallet_no = tpmt3;
					if c_sta = 'N' then
						tres := 'NG;[EC301-5]PALLET ALREADY OPEN';
					else
						update g_pack_pallet set close_flag = 'N' where pallet_no = tpmt3;
						tres := 'OK;OK;';
					end if;
				exception
					when no_data_found then
						tres := 'NG;[EC302-1] PALLET IS NOT FOUND';
				end;
			else
				tres := 'NG;[EC301] PALLET ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
	elsif cmd = 8 then
		c_end := instr(c_buffer, ';', 1, c_number);
		if (c_end - c_start) <= 25 then
			tpmt2    := substr(c_buffer, c_start, c_end - c_start); --EMP NO
			c_number := c_number + 1;
			c_start  := c_end + 1;
			c_end    := instr(c_buffer, ';', 1, c_number);
			if (c_end - c_start) <= 25 then
				tpmt3 := substr(c_buffer, c_start, c_end - c_start); -- CARTON
				begin
					select close_flag into c_sta from sajet.g_pack_carton where carton_no = tpmt3;
					if c_sta = 'N' then
						tres := 'NG;[EC301-5]CARTON ALREADY OPEN';
					else
						update g_pack_carton set close_flag = 'N' where carton_no = tpmt3;
					
						update g_pack_pallet
						set    close_flag = 'N'
						where  pallet_no in (select pallet_no from g_sn_status where carton_no = tpmt3 and rownum = 1);
						tres := 'OK;OK;';
					end if;
				exception
					when no_data_found then
						tres := 'NG;[EC301-1] CARTON IS NOT FOUND';
				end;
			else
				tres := 'NG;[EC301] CARTON ERROR;';
			end if;
		else
			tres := 'NG;[EC201] EMP ERROR;';
		end if;
	end if;

	tres := replace(tres, 'NG;NG', 'NG;');
	tres := replace(tres, ';;', ';');

end;
/

