create function dfi_wo_3(svalue in varchar2) return varchar2 is

	v_code123 char(3);
	v_y       char(1);
	v_mm      char(2);
	v_ww      char(2);
	v_x       char(1);
	v_seq     varchar2(3);
	v_step    char(2);
	v_div     varchar2(2);

	v_wo       sajet.g_wo_base.work_order%type;
	v_result12 char(2);
	v_result3  char(1);
	v_result45 char(2);
	v_code5    char(1);
	v_result67 varchar2(3);
	v_result8  varchar2(2);
	v_idx      number;
begin
	v_idx := 1;
	begin
		select work_order into v_wo from sajet.g_wo_base where work_order = svalue and rownum = 1;
	exception
		when no_data_found then
			v_wo := svalue;
	end;

	v_idx := 2;

	v_code123  := substr(v_wo, 1, 3);
	v_code5    := substr(v_wo, 5, 1);
	v_idx      := 2;
	v_result12 := case v_code123
				  --？？？？？？？
					  when 'DPG' then
					   'BS'
					  when 'UPG' then
					   'IS'
					  when 'GPS' then
					   'SS'
				  -- ？？？？？？？
					  when 'DPK' then
					   'AN'
					  when 'DPP' then
					   'AN'
					  when 'UPK' then
					   'HN'
					  when 'UPP' then
					   'HN'
				  --？？？？
					  when 'DPW' then
					   'AW'
					  when 'UPW' then
					   'HW'
					  when 'GPW' then
					   'SW'
				  -- RMA & ？？？
					  when 'DPR' then
					   'BR'
					  when 'UPR' then
					   'IR'
				  --？？？？？？
					  when 'DSK' then
					   'AS'
					  when 'DSP' then
					   'AS'
					  when 'USK' then
					   'HS'
					  when 'USP' then
					   'HS'
				  --？？？？？
				  
					  else
					   case substr(v_code123, 1, 1) --？？？？？？？
						   when 'D' then
							unistr('\0042\004E')
						   when 'U' then
							'IN'
						   else
							'00'
					   end
				  end;

	if (v_result12 = 'BN') then
		if v_code5 = 'S' then
			v_result12 := 'SN';
		end if;
	end if;


	v_idx := 3;

	--   IF (V_RESULT12 <>'00') AND (V_RESULT12 <>'BN') AND (V_RESULT12 <>'IN')   THEN
	if (v_result12 <> '00') and (v_result12 <> 'BN') and (v_result12 <> 'IN') and (v_result12 <> 'SN') then
		v_y   := substr(v_wo, 4, 1);
		v_mm  := substr(v_wo, 5, 2);
		v_seq := substr(v_wo, 7, 3);
	else
		v_y    := substr(v_wo, 2, 1);
		v_ww   := substr(v_wo, 3, 2);
		v_x    := substr(v_wo, 5, 1);
		v_seq  := substr(v_wo, 6, 2);
		v_step := substr(v_wo, 8, 2);
	end if;
	v_idx := 4;
	--@ ？ 64 ？？？？？, ？？ 0

	select ascii(nvl(substr(v_wo, 10, 1), '@')) - 64 into v_div from dual;

	v_idx := 5;

	v_result3 := v_y;

	--？？？？？？？？？,？？？？
	v_result45 := case v_result12
					  when 'BN' then
					   v_ww
					  when 'IN' then
					   v_ww
					  when 'SN' then
					   v_ww
					  else
					   v_mm
				  end;

	v_idx := 6;
	--100 ？？ A0,  ？？？ 359 Z9
	if to_number(v_seq) > 99 then
		select chr(to_number(substr(v_seq, 1, 2)) + 55) || substr(v_seq, 3, 1) into v_seq from dual;
	else
		select lpad(to_number(v_seq), 2, '0') into v_seq from dual;
	end if;
	v_result67 := v_seq;
	--
	--？？
	v_idx := 7;

	v_result8 := v_div;

	v_idx := 8;

	return v_result12 || v_result3 || v_result45 || v_result67 || v_result8;


exception
	when others then
		return sqlerrm || ',Error Step : ' || to_char(v_idx);
end;


/

