create procedure       csbg_tooling_sn_delete(t_tooling_sn_id in varchar2
														,t_emp_id        in varchar2
														,tres            out varchar2) is
	v_tooling_sn_id number;
begin
	tres := 'OK';
	update sajet.sys_tooling_sn
	set    enabled = 'Drop', update_userid = t_emp_id, update_time = sysdate
	where  tooling_sn_id = t_tooling_sn_id;
	insert into sajet.sys_ht_tooling_sn
		select * from sajet.sys_tooling_sn where tooling_sn_id = t_tooling_sn_id;
	delete sajet.sys_tooling_sn where tooling_sn_id = t_tooling_sn_id;
	delete sajet.g_tooling_sn_status where tooling_sn_id = t_tooling_sn_id;
	commit;
exception
	when others then
		rollback;
		tres := '  CSBG_TOOLING_SN_DELETE  ERROR';
end;


/

