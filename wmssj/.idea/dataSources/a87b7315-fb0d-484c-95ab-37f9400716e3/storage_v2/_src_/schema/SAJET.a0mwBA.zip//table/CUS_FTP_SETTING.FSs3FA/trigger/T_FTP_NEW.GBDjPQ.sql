create trigger T_FTP_NEW
  before insert
  on CUS_FTP_SETTING
  for each row
declare
	-- local variables here
begin
	select sys_guid into :new.keyid from dual;
end t_ftp_new;


/

