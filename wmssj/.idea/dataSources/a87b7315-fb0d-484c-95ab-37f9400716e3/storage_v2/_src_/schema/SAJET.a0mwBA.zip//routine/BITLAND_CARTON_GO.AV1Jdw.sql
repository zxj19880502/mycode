create PROCEDURE       BITLAND_CARTON_GO(TPACKACTION in varchar2,TREV in varchar2,TCARTON in varchar2,TTREMINALID in varchar2,TEMPNO in varchar2,TRES out varchar2)IS
nextprocess varchar2(30);
empid number;
psn varchar2(80);
cursor sn_cursor is
   select serial_number
     from sajet.g_sn_status
       where box_no = TREV;
sn_record sn_cursor%rowtype;
--sncount number;
BEGIN
  TRES:='OK';
  nextprocess:='N/A';
  --sncount:=0;
  if TREV is null then
    TRES:='SN IS NULL';
    return ;
    elsif TPACKACTION is null then
    TRES:='PACK ACTION IS NULL';
    return;
    elsif TCARTON is null then
      TRES:='CARTON NO IS NULL';
      return;
    elsif TTREMINALID is null then
    TRES:='Terminal ID is null';
    return;
    elsif TEMPNO is  null then
    TRES:='Emp no is null';
    return;
  end if;
  if TRES!='OK' then
    return;
    end if;
  sajet.Sj_Get_Empid(TEMPNO,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMPNO||')';
    return;
    end if;
    --select count(*) into sncount from sajet.g_sn_status ss where ss.serial_number=TSN;
  /*  if sncount=0 then
      TRES:='No this sn('||TSN||') record';
      return;
    end if;
   */
   if TPACKACTION='SN->CARTON' then
    sajet.sj_ckrt_sn_psn(TREV,TRES,psn);--？？sn？？？？
    if TRES!='OK'then
      return;
    end if;
      if TRES='OK' then
      -- update sajet.g_sn_status ss set ss.box_no=TSN,ss.customer_sn=TSN||TMO where ss.serial_number=TSN;
      update sajet.g_sn_status ss set ss.carton_no=TCARTON where ss.serial_number=TREV;
       --insert into sajet.g_label_record(LABEL_TYPE,SN1,USER_ID)values('BOX_LABEL',TSN,empid);
        sajet.sj_transfer2(TTREMINALID,TREV,'N/A',sysdate,TEMPNO,TRES,nextprocess);
        if TRES='OK' then
           commit;
        else
           rollback;
        end if;
      end if;
      elsif TPACKACTION='BOX->CARTON' then
      update sajet.g_sn_status ss set ss.carton_no=TCARTON where ss.box_no=TREV;
      for sn_record in sn_cursor loop
        --sajet.sj_transfer2(TTREMINALID,sn_record.serial_number,'N/A',sysdate,TEMPNO,TRES,nextprocess);
         sajet.sj_ckrt_sn_psn(sn_record.serial_number,TRES,psn);
         if TRES='OK' then
          sajet.sj_go(TTREMINALID,sn_record.serial_number,sysdate,TRES,TEMPNO);
              if TRES!='OK' then
                rollback;
                return;
              end if;
         else
           return;
          end if;
        end loop;
      --  UPDATE SAJET.G_SN_STATUS s SET s.carton_no = TCARTON WHERE s.box_no = TREV;
     commit;
      end if;
exception
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

