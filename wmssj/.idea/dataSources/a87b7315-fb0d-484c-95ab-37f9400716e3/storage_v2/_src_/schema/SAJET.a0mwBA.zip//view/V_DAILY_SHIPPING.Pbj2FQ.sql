create view V_DAILY_SHIPPING as
select case
         when to_char(a.update_time, 'yyyymmddhh24miss') <
              to_char(a.update_time, 'yyyymmdd') || '083000' then
          to_char(a.update_time - 1, 'yyyymmdd')
         else
          to_char(a.update_time, 'yyyymmdd')
       end query_date,
       substr(c.model_name, 4, 4) sizespec,
       count(serial_number) shipping_qty
  from sajet.g_shipping_sn t, sajet.sys_part b,sajet.g_shipping_input a,sajet.sys_model c
 where t.part_id = b.part_id(+) and t.shipping_id=a.shipping_id
and b.model_id=c.model_id
 group by substr(c.model_name, 4, 4),
          case
            when to_char(a.update_time, 'yyyymmddhh24miss') <
                 to_char(a.update_time, 'yyyymmdd') || '083000' then
             to_char(a.update_time - 1, 'yyyymmdd')
            else
             to_char(a.update_time, 'yyyymmdd')
          end


/

