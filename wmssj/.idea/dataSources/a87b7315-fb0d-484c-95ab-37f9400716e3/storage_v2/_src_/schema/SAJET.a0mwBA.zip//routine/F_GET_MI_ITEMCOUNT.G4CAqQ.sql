create function f_get_mi_itemcount(swo         in varchar2
											 ,sitempartid in varchar2
											 ,slocaton    in varchar2
											 ,sitem_group in varchar2) return number is
	result      varchar2(50);
	citem_count number;
begin

	begin
		select c.item_count
		into   citem_count
		from   sajet.g_wo_base a, sajet.sys_bom_info b, sajet.sys_bom c, sajet.sys_bom_location d
		where  a.work_order = swo and a.part_id = b.part_id and b.bom_id = c.bom_id and c.item_part_id = sitempartid and
			   c.item_part_id = d.item_part_id and b.bom_id = d.bom_id -- and d.item_group = c.item_group
			   and d.location = slocaton and rownum = 1;
		return citem_count;
	exception
		when others then
			return null;
	end;

exception
	when others then
	
		return null;
end;


/

