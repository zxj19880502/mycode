create function Wait_input_wms_to_product(Sserial_number in varchar2)
  return varCHAR2 is
  Result      varchar2(10);
  wms_time    date;
  status_time date;
begin
  select a.update_time
    into wms_time
    from (select *
            from sajet.wms_pick_list t
           where t.material_no = Sserial_number
           order by t.update_time desc) a
   where rownum = 1;
   select t.Out_Process_Time into status_time from sajet.g_sn_status t where t.serial_number=Sserial_number;
   
   if wms_time>status_time then
     result:='Y';
   end if;
  return(Result);
end Wait_input_wms_to_product;


/

