create PROCEDURE       BITLAND_REPACK_PALLET_GO(TPACKACTION in varchar2,TREV in varchar2,TPALLET in varchar2,TEMPNO in varchar2,TRES out varchar2)IS
empid number;
--psn varchar2(80);
oldpallet sajet.g_repacking_sn.pallet_no%type;
BEGIN
  TRES:='OK';
  if TREV is null then
    TRES:='SN OR CARTON IS NULL';
    return ;
    elsif TPACKACTION is null then
    TRES:='PACK ACTION IS IS NULL';
    return;
  elsif TPALLET is null then
      TRES:='PALLET NO IS NULL';
      return;
  elsif TEMPNO is  null then
    TRES:='Emp no is null';
    return;
  end if;
  sajet.Sj_Get_Empid(TEMPNO,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMPNO||')';
    return;
  end if;
  if TRES='OK' then
     begin
       if TPACKACTION='CARTON->PALLET' then

           begin
               select rs.pallet_no into oldpallet from sajet.g_repacking_sn rs where rs.repack_type='REPACK_PALLET' and rs.carton_no=TREV;--找原来的记录
               update sajet.g_repacking_sn rs set rs.pallet_no=TPALLET,rs.update_userid=empid,rs.update_time=sysdate where rs.carton_no=TREV;--更新重包记录
                insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
               values('REPACK_PALLET',oldpallet,'N/A','N/A',TPALLET,'N/A','N/A','N/A',empid,sysdate);--插入历史记录
               update sajet.g_sn_status ss set ss.pallet_no=TPALLET where ss.carton_no=TREV;--更新箱号
               commit;
           exception
             when NO_DATA_FOUND then--之前没有重包过
               begin
                   insert into sajet.g_repacking_sn(repack_type,serial_number,pallet_no,carton_no,box_no,update_userid,update_time)
                   values('REPACK_PALLET','N/A',TPALLET,TREV,'N/A',empid,sysdate);--插一笔新纪录
                   insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
                   values('REPACK_PALLET','N/A','N/A','N/A',TPALLET,TREV,'N/A','N/A',empid,sysdate);--插入历史记录
                   update sajet.g_sn_status ss set ss.pallet_no=TPALLET where ss.carton_no=TREV;--更新箱号
                   commit;
               exception
                 when others then
                   TRES:=Sqlerrm;
                   rollback;
                   return;
               end;
               when others then
                 TRES:=sqlerrm;
                 rollback;
                 return;
           end;
           elsif TPACKACTION='SN->PALLET'then
              begin
                   select rs.pallet_no into oldpallet from sajet.g_repacking_sn rs where rs.repack_type='REPACK_PALLET' and rs.serial_number=TREV;--找原来的记录
                   update sajet.g_repacking_sn rs set rs.pallet_no=TPALLET,rs.update_userid=empid,rs.update_time=sysdate where rs.serial_number=TREV;--更新重包记录
                    insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
                   values('REPACK_PALLET',oldpallet,'N/A','N/A',TPALLET,'N/A','N/A',TREV,empid,sysdate);--插入历史记录
                   update sajet.g_sn_status ss set ss.pallet_no=TPALLET where ss.serial_number=TREV;--更新栈板号
                   commit;
               exception
                 when NO_DATA_FOUND then--之前没有重包过
                   begin
                       insert into sajet.g_repacking_sn(repack_type,serial_number,pallet_no,carton_no,box_no,update_userid,update_time)
                       values('REPACK_PALLET',TREV,TPALLET,'N/A','N/A',empid,sysdate);--插一笔新纪录
                       insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
                       values('REPACK_PALLET','N/A','N/A','N/A',TPALLET,TREV,'N/A',TREV,empid,sysdate);--插入历史记录
                       update sajet.g_sn_status ss set ss.pallet_no=TPALLET where ss.serial_number=TREV;--更新箱号
                       commit;
                   exception
                     when others then
                       TRES:=Sqlerrm;
                       rollback;
                       return;
                   end;
                   when others then
                     TRES:=sqlerrm;
                     rollback;
                     return;
               end;
           elsif  TPACKACTION='BOX->PALLET'then

            begin
               select rs.pallet_no into oldpallet from sajet.g_repacking_sn rs where rs.repack_type='REPACK_PALLET' and rs.box_no=TREV;--找原来的记录
               update sajet.g_repacking_sn rs set rs.pallet_no=TPALLET,rs.update_userid=empid,rs.update_time=sysdate where rs.box_no=TREV;--更新重包记录
                insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
               values('REPACK_PALLET',oldpallet,'N/A','N/A',TPALLET,'N/A','N/A','N/A',empid,sysdate);--插入历史记录
               update sajet.g_sn_status ss set ss.pallet_no=TPALLET where ss.carton_no=TREV;--更新箱号
               commit;
           exception
             when NO_DATA_FOUND then--之前没有重包过
               begin
                   insert into sajet.g_repacking_sn(repack_type,serial_number,pallet_no,carton_no,box_no,update_userid,update_time)
                   values('REPACK_PALLET','N/A',TPALLET,'N/A',TREV,empid,sysdate);--插一笔新纪录
                   insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
                   values('REPACK_PALLET','N/A','N/A','N/A',TPALLET,'N/A',TREV,'N/A',empid,sysdate);--插入历史记录
                   update sajet.g_sn_status ss set ss.pallet_no=TPALLET where ss.box_no=TREV;--更新箱号
                   commit;
               exception
                 when others then
                   TRES:=Sqlerrm;
                   rollback;
                   return;
               end;
               when others then
                 TRES:=sqlerrm;
                 rollback;
                 return;
           end;
           else
             TRES:='Unknown PACK ACTION:'||TPACKACTION;
             end if;
     end;
     end if;
exception
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

