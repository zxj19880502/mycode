create FUNCTION       SJ_REWORK_RWNO(sWO in varchar2) return varchar2 is
sResult varchar2(50);
C_RWSEQ number;
begin
  select SJ_REWORK_NO.Nextval into C_RWSEQ from dual;

  sResult:='RW'||to_char(sysdate,'yyyymmdd')||LPAD(C_RWSEQ,5,'0');
  return sResult;
end;


/

