create procedure       csbg_sn_mapping(trev        in varchar2
												 ,tsn         in varchar2
												 ,tterminalid in varchar2
												 ,tnow        in date
												 ,temp        in varchar2
												 ,tres        out varchar2) is
	v_cust_sn     sajet.g_wo_customer_sn.customer_sn%type;
	v_carton_no   sajet.g_wo_customer_sn.carton_no%type;
	v_pallet_no   sajet.g_wo_customer_sn.pallet_no%type;
	v_work_order  sajet.g_wo_customer_sn.work_order%type;
	v_work_order1 sajet.g_sn_status.work_order%type;
	v_cust_sn1    sajet.g_sn_status.customer_sn%type;
	v_sn          sajet.g_sn_status.serial_number%type;
	tnextproc     varchar2(100);
begin
	tres := 'OK';
	--檢查客戶序號存不存在
	begin
		select customer_sn, carton_no, pallet_no, work_order
		into   v_cust_sn, v_carton_no, v_pallet_no, v_work_order
		from   sajet.g_wo_customer_sn
		where  customer_sn = trev and rownum = 1;
	exception
		when others then
			tres := 'NO SSN';
	end;
	if tres = 'OK' then
		begin
			select work_order, nvl(customer_sn, 'N/A')
			into   v_work_order1, v_cust_sn1
			from   sajet.g_sn_status
			where  serial_number = tsn and rownum = 1;
			--當廠內序號已有客戶序號且與刷入的客戶序號不同時
			if (v_cust_sn1 <> 'N/A') and (v_cust_sn1 <> v_cust_sn) then
				tres := 'S/N Had CUST SN(' || v_cust_sn || ')';
				--檢查客戶序號是否與廠內序號同工單
			elsif v_work_order <> v_work_order1 then
				tres := 'WO NOT MATCH';
			end if;
		exception
			when no_data_found then
				tres := 'NO SN';
		end;
	end if;
	--檢查客戶序號是否已被其它序號使用
	if tres = 'OK' then
		begin
			select serial_number into v_sn from sajet.g_sn_status where customer_sn = trev and rownum = 1;
			if v_sn <> tsn then
				tres := 'CUST SN Used(' || v_sn || ')';
			end if;
		exception
			when others then
				tres := 'OK';
		end;
	end if;
	--更新客戶序號並過站
	if tres = 'OK' then
		update sajet.g_sn_status
		set    customer_sn = trev
		--    ,CARTON_NO = V_CARTON_NO
		--    ,PALLET_NO = V_PALLET_NO
		where  serial_number = tsn;
		--呼叫transfer
		sajet.sj_transfer(tterminalid, tsn, 'N/A', tnow, temp, tres, tnextproc);
	end if;
exception
	when others then
		tres := 'CSBG_SN_MAPPING error';
end;


/

