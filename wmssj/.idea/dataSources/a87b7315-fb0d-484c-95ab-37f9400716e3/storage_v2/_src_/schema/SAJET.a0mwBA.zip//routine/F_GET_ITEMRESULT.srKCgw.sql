create function f_get_itemresult(slotno   in varchar2
										   ,stest_id in number) return varchar2 is
	cresult   varchar2(50);
	ccount number;
begin
	select count(d.insp_result)
	into   ccount
	from   sajet.g_qc_sn a, sajet.g_qc_lot b, sajet.g_sn_testitem_header c, sajet.g_sn_testitem_detail d
	where  b.qc_lotno = slotno and a.qc_lotno = b.qc_lotno and a.recid = c.recid and c.recid = d.recid and
		   d.item_id = stest_id and d.insp_result = 'NG';

    if  ccount>0 then
        cresult:='NG';
     else
        cresult:='OK';

     end if;


	return cresult;
exception
	when others then
		return 'NG';
end;
/

