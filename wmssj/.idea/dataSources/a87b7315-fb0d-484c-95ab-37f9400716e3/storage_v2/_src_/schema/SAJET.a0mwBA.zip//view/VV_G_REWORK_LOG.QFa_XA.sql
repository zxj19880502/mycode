create view VV_G_REWORK_LOG as
select distinct b.serial_number,to_char(b.wip_out_time,'yyyy-mm-dd') ti
from sajet.g_rework_log b
where b.process_id='100026'


/

