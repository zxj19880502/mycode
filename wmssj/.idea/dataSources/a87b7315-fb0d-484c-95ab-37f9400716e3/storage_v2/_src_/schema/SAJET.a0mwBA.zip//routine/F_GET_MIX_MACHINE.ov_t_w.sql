create function f_get_mix_machine(svalue in varchar2) return varchar2 is
	v_moption varchar2(50);
	-- V_MODEL   VARCHAR2(50);
	t_moption varchar2(50);
	-- T_MODEL   VARCHAR2(50);
	v_result varchar2(50);
begin
	select m_option1 into v_moption from sajet.sys_machine where machine_id = svalue;
	if v_moption is null then
		t_moption := '';
	else
		t_moption := v_moption;
	end if;

	v_result := t_moption;

	return v_result;
exception
	when others then
		return sqlerrm;
end;


/

