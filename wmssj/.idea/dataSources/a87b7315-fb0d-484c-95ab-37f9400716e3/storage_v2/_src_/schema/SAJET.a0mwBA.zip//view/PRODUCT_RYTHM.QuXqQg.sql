create view PRODUCT_RYTHM as
  select t.out_process_time, t.riqi, t.shiduan,t.sizespec,b.process_name,count(serial_number) sn_num
  from sajet.base_sn_travel t,
       (select case
                 when sysdate <
                      to_date(to_char(sysdate, 'yyyy-mm-dd ') || '8:30:00',
                              'yyyy-mm-dd hh24:mi:ss') then
                  to_date(TO_CHAR(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - 1
                 else
                  to_date(TO_CHAR(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd')
               end riqi
          from dual) a,sajet.sys_process b
 where a.riqi = t.riqi and t.PROCESS_ID=b.process_id group by t.out_process_time, t.riqi, t.shiduan,t.sizespec,b.process_name
union
SELECT t.out_process_time, t.riqi, t.shiduan,t.die_option1 sizespec,t.process_name,count(t.rc_no) sn_num FROM SAJET.BASE_TRAVEL_RC T,(select case
                 when sysdate <
                      to_date(to_char(sysdate, 'yyyy-mm-dd ') || '8:30:00',
                              'yyyy-mm-dd hh24:mi:ss') then
                  to_date(TO_CHAR(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - 1
                 else
                  to_date(TO_CHAR(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd')
               end riqi
          from dual) a WHERE A.RIQI=T.RIQI group by t.out_process_time, t.riqi,t.shiduan,t.die_option1,t.process_name


/

