create function jackcheckcsnrule(wo  varchar2
										   ,csn varchar2) return varchar2 as
	language java name 'JackCheckCSNRule.Entry(java.lang.String,java.lang.String) return java.lang.String';


/

