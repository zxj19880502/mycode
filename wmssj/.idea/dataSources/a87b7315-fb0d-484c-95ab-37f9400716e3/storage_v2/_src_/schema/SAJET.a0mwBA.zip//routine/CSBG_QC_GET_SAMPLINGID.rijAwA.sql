create procedure       csbg_qc_get_samplingid(tsampling_type in varchar2
														,tsampling_id   out number) is
begin
	select sampling_id
	into   tsampling_id
	from   sajet.sys_qc_sampling_plan
	where  sampling_type = tsampling_type and rownum = 1;
exception
	when others then
		tsampling_id := 0;
end;


/

