create function f_get_timefep(ctype in varchar2) return date is

	ctime         number;
	cyesterday_20 date;
	ctoday_8      date;
	ctoday_24     date;

	cdate_tima date;

	--根据当前时间，获取白夜班的开始时间
begin
	ctime         := to_number(to_char(sysdate, 'hh24'));
	cyesterday_20 := trunc(sysdate - 1) + 20 / 24;
	ctoday_8      := trunc(sysdate) + 8 / 24;
	ctoday_24     := trunc(sysdate) + 20 / 24;

	if (ctime > 8) and (ctime < 20) then
		cdate_tima := ctoday_8;
	else
		cdate_tima := cyesterday_20;
	
	end if;


	<<endp>>
	return cdate_tima;
exception
	when others then
		return null;
end;
/

