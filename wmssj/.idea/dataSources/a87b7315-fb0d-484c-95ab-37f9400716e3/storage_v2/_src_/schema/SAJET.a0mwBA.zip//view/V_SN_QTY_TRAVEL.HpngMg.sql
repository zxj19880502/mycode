create view V_SN_QTY_TRAVEL as
  select work_order,
      serial_number,
       part_id,
       pdline_id,
       stage_id,
       /*DECODE(process_id,'0','N/A',process_id)*/ process_id,
        nvl(in_process_shift,'N/A') shift_name,--投入班别
       in_process_time work_time,---投入时间
       1 wip_in_qty,
       0 pass_qty,
       0 fail_qty
  from sajet.g_sn_travel
  where PROCESS_ID<>'100011'
  union all
  select work_order,
      serial_number,
       part_id,
       pdline_id,
       stage_id,
       /*DECODE(process_id,'0','N/A',process_id)*/ process_id,
      nvl(in_process_shift,'N/A') shift_name,--投入班别
       out_process_time work_time,---产出时间
       0 wip_in_qty,--投入数量
      (case when current_status<>1 then 1 else  0  end  ) pass_qty,
       (case when current_status=1 then 1 else  0  end  ) fail_qty
  from sajet.g_sn_travel
  where PROCESS_ID<>'100011'
union all
select work_order,
      serial_number,
       part_id,
       pdline_id,
       stage_id,
      /* DECODE(process_id,'0','N/A',process_id)*/ process_id,
       nvl(in_process_shift,'N/A') shift_name,--投入班别
       in_process_time work_time,---投入时间
       1 wip_in_qty,
       0 pass_qty,
       0 fail_qty
  from sajet.g_sn_status
 where in_process_time is not null
   and out_process_time is null
   and PROCESS_ID<>'100011'
   union all
   select work_order,
      serial_number,
       part_id,
       pdline_id,
       stage_id,
      /*DECODE(process_id,'0','N/A',process_id)*/ process_id,
        nvl(in_process_shift,'N/A') shift_name,--投入班别
       in_process_time work_time,---投入时间
       1 wip_in_qty,
       0 pass_qty,
       0 fail_qty
  from sajet.g_sn_status
  where in_process_time is  null
   and out_process_time is null
   and PROCESS_ID<>'100011'


/

