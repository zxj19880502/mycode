create procedure       csbg_ckrt_csn(trev in varchar2
											   ,tres out varchar2) is
	csn sajet.g_sn_status.customer_sn%type;
begin
	tres := 'SN ERR';
	select nvl(customer_sn, 'N/A') into csn from sajet.g_sn_status where serial_number = trev and rownum = 1;
	if csn <> 'N/A' then
		tres := 'CSN NOT NULL';
	else
		tres := 'OK';
	end if;
exception
	when others then
		tres := 'NO SN';
end;


/

