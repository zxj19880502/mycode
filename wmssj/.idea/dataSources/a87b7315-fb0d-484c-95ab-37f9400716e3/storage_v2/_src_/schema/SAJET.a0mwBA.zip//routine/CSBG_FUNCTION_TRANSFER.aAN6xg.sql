create procedure       csbg_function_transfer(trev            in varchar2
														,tsn             in varchar2
														,tdefect         in varchar2
														,tnow            in date
														,temp            in varchar2
														,tterminalid     in number
														,cnext_processid in number
														,tres            out varchar2
														,tnextproc       out varchar2) is
begin
	if trev = 'END' then
		sajet.csbg_function_error_go(tterminalid, tsn, tdefect, tnow, temp, tres, tnextproc, cnext_processid);
		tnextproc := '';
	else
		tres := 'COMMAND ERROR';
	end if;
exception
	when others then
		tres      := 'CSBG_Function_transfer error';
		tnextproc := '';
end;


/

