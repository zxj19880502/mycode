create procedure       csbg_tooling_change(toldtoolseq   in varchar2
													 ,two           in varchar2
													 ,told_toolsnid in number
													 ,tnew_toolsnid in number
													 ,tprocessid    in number
													 ,tterminalid   in number
													 ,tempid        in number
													 ,tnow          in date
													 ,tres          out varchar2) is
	c_newtoolseq sajet.g_tooling_sn_status.tooling_seq%type;
begin
	--TOOLING SN CHANGE
	sajet.csbg_get_toolseq(tnow, tres, c_newtoolseq);
	--INSERT 原來的TOOLING TO HISTORY
	insert into sajet.g_ht_tooling_sn_status
		select * from sajet.g_tooling_sn_status where tooling_seq = toldtoolseq;
	--UPDATE 原來的TOOLING
	update sajet.g_tooling_sn_status set tooling_seq = c_newtoolseq where tooling_seq = toldtoolseq;
	--UPDATE NEW TOOLING
	update sajet.g_tooling_sn_status
	set    work_order = two, process_id = tprocessid, terminal_id = tterminalid, serial_number = 'N/A',
		   get_userid = tempid, get_time = tnow, tooling_seq = c_newtoolseq
	where  tooling_sn_id = tnew_toolsnid;
	--UPDATE 原來的TOOLING
	update sajet.g_tooling_sn_status
	set    work_order = 'N/A', process_id = null, terminal_id = null, serial_number = null, tooling_seq = null,
		   get_userid = null, get_time = null
	where  tooling_sn_id = told_toolsnid;
	commit;
	tres := 'OK';
exception
	when others then
		tres := 'CSBG_FIXTURE_INPUT ERROR! ';
		rollback;
end;


/

