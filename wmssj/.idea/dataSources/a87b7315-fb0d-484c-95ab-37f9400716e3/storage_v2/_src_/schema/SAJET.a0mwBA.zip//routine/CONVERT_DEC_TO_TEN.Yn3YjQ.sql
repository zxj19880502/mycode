create function       Convert_DEC_To_Ten(TT in varchar2,TCHAR in varchar2) return number is
--10???33??(10????26????I.O.S???)
stt varchar2(12) ;--33?????
sremainder varchar2(2);--??
nremainder number;
squotient varchar2(2);--?
nquotient number;
bytes varchar2(50);
ttlength number;
idx number;
res number;
str varchar2(1);
i number;
iDec number;
cchar varchar2(2);
begin
  ttlength:=0;
  res:=0;
  select length(TT) into ttlength from dual;
  bytes:='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
   for i in 1..Length(TCHAR)
   loop
       cchar:=substr(TCHAR,i,1);
       bytes:=replace(bytes,cchar,'');
   end loop;
  bytes:=TRIM(bytes);
  iDec:=Length(bytes);

  for i in 1..ttlength
    loop
      str:=substr(TT,i,1);--???????
      idx:=INSTR(bytes,str,1,1)-1;--????????????
      res:=res+idx*iDec**(ttlength-i);
    end loop;
 return res;
end;


/

