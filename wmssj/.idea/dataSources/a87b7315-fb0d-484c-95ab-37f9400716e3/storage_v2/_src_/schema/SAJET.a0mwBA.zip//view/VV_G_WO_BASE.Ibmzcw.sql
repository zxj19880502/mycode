create view VV_G_WO_BASE as
select a.work_order,c.part_no,a.version,sajet.sj_wostatus_result(a.wo_status) WOSTATUS,a.target_qty,
       b.input_qty,b.output_qty,b.scrap_qty,a.wo_type,a.wo_rule,a.part_id,a.WO_CREATE_DATE,
       a.WO_SCHEDULE_DATE,a.WO_DUE_DATE,a.default_pdline_id,a.start_process_id,a.end_process_id,a.customer_id,
       a.update_userid,a.update_time,a.release_date,a.model_name,a.factory_id,a.cust_recno,a.cust_sndno,
       a.WO_START_DATE,a.WO_CLOSE_DATE,a.route_id,a.work_flag,a.wo_status,d.customer_code,e.pdline_name,b.route_name,
       m.START_PROCESS,n.END_PROCESS,
       a.wo_option3,a.wo_option4,a.wo_option5,a.wo_option6,a.wo_option7,a.wo_option8,a.wo_option9,a.wo_option10,
       a.erp_id,a.bom_type,a.error_qty,a.release_qty,a.org_id,a.erp_qty,
       a.PO_NO,a.SALES_ORDER,a.MASTER_WO,a.REMARK,a.WO_OPTION1,decode(a.WO_OPTION2,1,'浆料段',2,'成型段',3,'成品段',4,'高纯段') WO_OPTION2
from
sajet.g_wo_base a,
sajet.sys_customer d,
sajet.sys_pdline e,
(select a.work_order,a.START_PROCESS_ID,b.process_name START_PROCESS from sajet.g_wo_base a,sajet.sys_process b
where a.START_PROCESS_ID=b.process_id)m,
(select a.work_order,a.END_PROCESS_ID,b.process_name END_PROCESS from sajet.g_wo_base a,sajet.sys_process b
where a.END_PROCESS_ID=b.process_id)n,
(select a.work_order,
       a.wo_type,
       e.part_no,
       f.route_name,
       a.target_qty,
       a.input_qty,
       a.output_qty,
       nvl(b.wip_qty, 0) wip_qty,
       nvl(d.scrap_qty, 0) scrap_qty,
       sajet.sj_wostatus_result(a.wo_status) status,
       a.wo_create_date,
       a.wo_schedule_date,
       a.wo_due_date
  from sajet.g_wo_base a,
       (select a.work_order, sum(current_qty) wip_qty
          from sajet.g_rc_status a
         where a.current_status not in ('1','9')
         group by a.work_order) b,
       (select a.work_order, sum(current_qty) scrap_qty
          from sajet.g_rc_status a
         where a.current_status = '1'
         group by a.work_order) d,
       sajet.sys_part e,
       sajet.sys_rc_route f
 where a.work_order = b.work_order(+)
   and a.work_order = d.work_order(+)
   and a.part_id = e.part_id
   and a.route_id = f.route_id
   and a.wo_option2 in (1,4)
 union all
 select a.work_order,
       a.wo_type,
       e.part_no,
       f.route_name,
       a.target_qty,
       h.input_qty,
       j.output_qty,
       nvl(b.wip_qty, 0) wip_qty,
       nvl(d.scrap_qty, 0) scrap_qty,
       sajet.sj_wostatus_result(a.wo_status) status,
       a.wo_create_date,
       a.wo_schedule_date,
       a.wo_due_date
  from sajet.g_wo_base a,
       (select m.work_order,m.part_id,m.node_content,n.input_qty from
(select a.work_order,a.part_id,b.node_content from
sajet.g_wo_base a,sajet.sys_rc_route_detail b
where a.route_id=b.route_id and
b.node_id in (select next_node_id from sajet.sys_rc_route_detail where node_content='START'))m,
(select work_order,part_id,process_id,sum(input_qty) input_qty from
(select work_order,part_id,process_id,count(1) input_qty from
(select distinct b.work_order,b.part_id,b.serial_number,b.process_id,max(b.wip_in_time) wip_in_time from
sajet.sys_rc_route_detail a,sajet.g_sn_travel b
where a.node_id in (select next_node_id from sajet.sys_rc_route_detail where node_content='START')
and a.node_content=b.process_id and b.current_status in (0,1,2)
group by b.work_order,b.part_id,b.serial_number,b.process_id)
group by work_order,part_id,process_id
union all
select work_order,part_id,process_id,count(1) input_qty from
(select distinct b.work_order,b.part_id,b.serial_number,b.process_id,max(b.wip_in_time) wip_in_time from
sajet.sys_rc_route_detail a,sajet.g_sn_status b
where a.node_id in (select next_node_id from sajet.sys_rc_route_detail where node_content='START')
and a.node_content=b.process_id and b.wip_in_time is not null and b.wip_out_time is null
and b.current_status<>1
group by b.work_order,b.part_id,b.serial_number,b.process_id)
group by work_order,part_id,process_id)
group by work_order,part_id,process_id)n
where m.work_order=n.work_order(+) and m.node_content=n.process_id(+) and m.part_id=n.part_id(+))h,
(select m.work_order,m.part_id,m.node_content,n.output_qty from
(select a.work_order,a.part_id,b.node_content from
sajet.g_wo_base a,sajet.sys_rc_route_detail b,sajet.sys_rc_route c
where a.route_id=b.route_id and b.route_id=c.route_id and c.enabled='Y' and
b.next_node_id in (select node_id from sajet.sys_rc_route_detail where node_content='END'))m,
(select work_order,part_id,process_id,count(1) output_qty from
(select distinct b.work_order,b.part_id,b.serial_number,b.process_id,max(b.wip_out_time) wip_out_time from
sajet.sys_rc_route_detail a,sajet.g_sn_travel b,sajet.sys_rc_route c
where a.next_node_id in (select node_id from sajet.sys_rc_route_detail where node_content='END')
and a.node_content=b.process_id and b.current_status in (0,1,2) and a.route_id=c.route_id and c.enabled='Y'
and a.node_content <> '100011'
group by b.work_order,b.part_id,b.serial_number,b.process_id)
group by work_order,part_id,process_id)n
where m.work_order=n.work_order(+) and m.node_content=n.process_id(+) and m.part_id=n.part_id(+))j,
       (select a.work_order, count(serial_number) wip_qty
          from sajet.g_sn_status a
         where a.out_pdline_time is null
           and a.current_status <> '1'
         group by a.work_order) b,
       (select a.work_order, count(serial_number) scrap_qty
          from sajet.g_sn_status a
         where a.current_status = '1'
         group by a.work_order) d,
       sajet.sys_part e,
       sajet.sys_rc_route f
 where a.work_order = b.work_order(+)
   and a.work_order = d.work_order(+)
   and a.work_order=h.work_order(+)
   and a.part_id=h.part_id(+)
   and a.work_order=j.work_order(+)
   and a.part_id=j.part_id(+)
   and a.part_id = e.part_id
   and a.route_id = f.route_id
   and a.wo_option2 in ('2', '3'))b,
   sajet.sys_part c
where a.work_order=b.work_order(+) and a.part_id=c.part_id and a.CUSTOMER_ID=d.customer_id(+) and
      a.DEFAULT_PDLINE_ID=e.pdline_id(+) and a.work_order=m.work_order(+) and a.work_order=n.work_order(+)
      and a.START_PROCESS_ID=m.START_PROCESS_ID(+) and a.END_PROCESS_ID=n.END_PROCESS_ID(+)
order by a.work_order


/

