create FUNCTION       
       Sj_Msd_Reelstatus_Result(svalue IN VARCHAR2) RETURN VARCHAR2 IS
str VARCHAR2(16); s NUMBER; i NUMBER;
BEGIN
  IF svalue = '0' THEN
    str := 'Open';
  ELSIF svalue = '1' THEN
    str := 'BakeIn';
  ELSIF svalue = '2' THEN
    str := 'BakeOut';
  ELSIF svalue = '3' THEN
    str := 'DryIn';
  ELSIF svalue = '4' THEN
    str := 'DryOut';
  ELSIF svalue = '5' THEN
    str := 'Repack';
  ELSE
    str := '';
  END IF;
  RETURN str;
END;


/

