create view V_GCL_PART as
SELECT PART_ID,
       PART_NO,
       B.MODEL_NAME,
       CUST_PART_NO,
       VENDOR_PART_NO,
       VERSION,
       PART_TYPE,
       MATERIAL_TYPE,
       SPEC1,
       SPEC2,
       UOM,
       A.RULE_SET,
       A.ROUTE_ID,
       c.route_name,
       A.LOT_SIZE,
       OPTION1,
       a.enabled,
       b.model_id
  FROM SAJET.SYS_PART A, sajet.sys_MODEL B, SAJET.SYS_RC_ROUTE c
 WHERE A.MODEL_ID = B.MODEL_ID
   and a.route_id = c.route_id(+)
 ORDER BY A.PART_NO


/

