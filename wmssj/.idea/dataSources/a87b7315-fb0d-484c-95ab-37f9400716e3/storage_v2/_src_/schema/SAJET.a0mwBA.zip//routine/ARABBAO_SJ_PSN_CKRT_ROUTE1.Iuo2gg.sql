create procedure       arabbao_sj_psn_ckrt_route1(terminalid in varchar2
															,psn        in varchar2
															,tres       out varchar2) as
begin
	arabbao_time_ckrt_route1(terminalid, psn, tres);
end;


/

