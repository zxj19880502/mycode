create function f_get_status(status in varchar2) return varchar2 is
    result varchar2(50);
begin
    --'I', '入库 ','P','领用 ','U','上线','D','下线','R','维修','M','保养'
    if status = 'L' then
        result := '在线';
    elsif status = 'U' then
        result := '下线';
    elsif status = 'S' then
        result := '报废';
    elsif status = 'C' then
        result := '清洗';
    else
        result := status;
    end if;
    return(result);
exception
    when others then
        result := '';
        return result;
end;


/

