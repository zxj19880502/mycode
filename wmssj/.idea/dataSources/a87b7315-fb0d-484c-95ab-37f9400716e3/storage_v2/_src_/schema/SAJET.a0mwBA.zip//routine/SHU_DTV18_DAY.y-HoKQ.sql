create function shu_dtv18_day(svalue in varchar2) return varchar2 is
	v_day varchar2(5);

begin
	begin
		select a.set_char
		into   v_day
		from   sajet.sys_barcode_day a
		where  to_char(a.set_date, 'mm-dd') = to_char(sysdate, 'mm-dd');
	exception
		when no_data_found then
			v_day := '';
	end;
	return upper(v_day);
exception
	when others then
		return 'shu_dtv18_day:' || sqlerrm;
end;
/

