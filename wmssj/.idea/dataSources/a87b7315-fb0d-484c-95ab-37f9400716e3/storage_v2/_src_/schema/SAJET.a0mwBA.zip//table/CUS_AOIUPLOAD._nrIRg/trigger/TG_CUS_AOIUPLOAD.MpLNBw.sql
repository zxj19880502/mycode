create trigger TG_CUS_AOIUPLOAD
  before insert
  on CUS_AOIUPLOAD
  for each row
declare
	-- local variables here
begin
	select serial_number
	into   :new.serial_number
	from   wiq.cus_snlink_relation
	where  link_no = (select link_no from wiq.cus_snlink_relation where serial_number = :new.pcbid) and
		   numbers = :new.array_no;
end tg_cus_aoiupload;


/

