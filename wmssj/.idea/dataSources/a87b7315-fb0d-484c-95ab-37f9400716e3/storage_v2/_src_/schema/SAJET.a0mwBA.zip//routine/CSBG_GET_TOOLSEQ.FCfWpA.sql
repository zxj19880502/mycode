create procedure       csbg_get_toolseq(tnow      in date
												  ,tres      out varchar2
												  ,ptool_seq out number) is
begin
	select to_char(tnow, 'YYYYMMDD') || lpad(sajet.s_tool_seq.nextval, 7, 0) into ptool_seq from dual;
	tres := 'OK';
exception
	when others then
		tres := 'CSBG_GET_TOOLSEQ ERR';
end;


/

