create function       snstatus_result(svalue in varchar2) return varchar2 is
	str varchar2(16);
	s   number;
	i   number;
begin
	if svalue = '0' then
		str := 'Good';
	elsif svalue = '1' then
		str := 'Fail';
	else
		str := '';
	end if;
	return str;
end;


/

