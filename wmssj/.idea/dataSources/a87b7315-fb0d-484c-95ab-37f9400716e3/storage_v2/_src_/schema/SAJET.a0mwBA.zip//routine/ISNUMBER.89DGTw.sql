create FUNCTION       ISNUMBER(p_in VARCHAR2) RETURN VARCHAR2 AS  
  I NUMBER;   
begin
  IF p_in IS NULL THEN
    RETURN 'FALSE';
  ELSE   
    i := to_number(p_in);   
    return 'TRUE';
  END IF;    
exception         
  when others   then     
    return 'FALSE';   
end;


/

