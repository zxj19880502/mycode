create procedure bc_revoke_csn(two    in varchar2
										 ,tstart in varchar2
										 ,tend   in varchar2
										 ,tempid in number
										 ,tres   out varchar2) is
	/*c_count   number;
    i_qty     number;
    c_total   number;
    c_panel   sajet.g_sn_status.panel_no%type;
    c_part    sajet.g_wo_base.part_id%type;
    c_route   sajet.g_wo_base.route_id%type;
    c_version sajet.g_wo_base.version%type;*/
	---   add by emily 回收客户序号
begin
	insert into sajet.g_wo_customer_sn_deletebk
		(work_order, customer_sn, update_userid, update_time)
		select work_order, customer_sn, tempid, sysdate
		from   (select a.customer_sn, a.work_order
				 from   sajet.g_wo_customer_sn a, sajet.g_wo_base c
				 where  a.work_order = c.work_order(+) and a.work_order = two
				 minus
				 select a.customer_sn, a.work_order
				 from   sajet.g_sn_status a
				 where  a.work_order = two
				 order  by customer_sn, work_order)
		where  customer_sn >= tstart and customer_sn <= tend;
	delete from sajet.g_wo_customer_sn
	where  (customer_sn, two) in (select a.customer_sn, a.work_order
								  from   sajet.g_wo_customer_sn a, sajet.g_wo_base c
								  where  a.work_order = c.work_order(+) and a.work_order = two
								  minus
								  select a.customer_sn, a.work_order
								  from   sajet.g_sn_status a
								  where  a.work_order = two) and work_order = two and customer_sn >= tstart and
		   customer_sn <= tend;



	tres := 'OK';
exception
	when others then
		tres := 'Insert Fail.';
end;


/

