create procedure arabbao_sj_getpartno_wo(trev in varchar2
												   ,tres out varchar2) is
	c_count number;
	part    varchar2(80);

begin
	select count(*)
	into   c_count
	from   (select model_id from sajet.g_sn_status where work_order = trev group by model_id);
	if c_count = 1 then
		select part_no
		into   part
		from   sajet.sys_part
		where  part_id = (select model_id from sajet.g_wo_base where work_order = trev);
		tres := part;
	elsif c_count = 0 then
		tres := '0:WO ERR';
	else
		tres := '0:Release SN ERR';
	end if;
exception
	when others then
		tres := '0:OTHERS ERR';
end;
/

