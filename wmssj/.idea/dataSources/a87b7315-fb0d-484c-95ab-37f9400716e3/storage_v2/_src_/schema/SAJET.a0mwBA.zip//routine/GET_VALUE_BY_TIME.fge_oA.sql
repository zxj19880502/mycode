create function get_value_by_time(intime in date --输入sysdate时间
                                             ) return varchar is
  str    varchar(20);
  cTime  sajet.sys_base.param_value%type;
  v_hour varchar(20);
  v_second varchar(20);
  v_time number;
begin

  select param_value
    into cTime
    from sajet.sys_base
   where param_name = 'TIME_SECTION'
     and rownum = 1;

     select to_char(intime,'hh24')*60/cTime + trunc(to_char(intime,'mi')/cTime) into str from dual;

/*  if cTime = '60' then
    select to_char(intime, 'HH24') into v_hour from dual;
    str:=v_hour;

  end if;

  if cTime = '30' then
    select to_char(intime, 'HH24') into v_hour from dual;
    select to_char(intime, 'MI') into v_second from dual;
   v_time:=to_number(v_hour)*2 + trunc(to_number(v_second)/30,0);
   str:=to_char(v_time);
  end if;*/

  /* if TO_CHAR(intime,'hh24:mi:ss')>='00:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='00:29:59' then str:='00';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='00:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='00:59:59'  then str:='01';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='01:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='01:29:59'  then str:='02';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='01:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='01:59:59'  then str:='03';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='02:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='02:29:59'  then str:='04';

  elsif TO_CHAR(intime,'hh24:mi:ss')>='02:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='02:59:59'  then str:='05';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='03:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='03:29:59'  then str:='06';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='03:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='03:59:59'  then str:='07';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='04:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='04:29:59'  then str:='08';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='04:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='04:59:59'  then str:='09';

  elsif TO_CHAR(intime,'hh24:mi:ss')>='05:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='05:29:59'  then str:='10';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='05:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='05:59:59'  then str:='11';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='06:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='06:29:59'  then str:='12';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='06:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='06:59:59'  then str:='13';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='07:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='07:29:59'  then str:='14';

  elsif TO_CHAR(intime,'hh24:mi:ss')>='07:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='07:59:59'  then str:='15';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='08:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='08:29:59'  then str:='16';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='08:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='08:59:59'  then str:='17';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='09:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='09:29:59'  then str:='18';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='09:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='09:59:59'  then str:='19';

  elsif TO_CHAR(intime,'hh24:mi:ss')>='10:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='10:29:59'  then str:='20';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='10:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='10:59:59'  then str:='21';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='11:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='11:29:59'  then str:='22';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='11:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='11:59:59'  then str:='23';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='12:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='12:29:59'  then str:='24';

  elsif TO_CHAR(intime,'hh24:mi:ss')>='12:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='12:59:59'  then str:='25';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='13:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='13:29:59'  then str:='26';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='13:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='13:59:59'  then str:='27';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='14:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='14:29:59'  then str:='28';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='14:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='14:59:59'  then str:='29';

  elsif TO_CHAR(intime,'hh24:mi:ss')>='15:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='15:29:59'  then str:='30';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='15:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='15:59:59'  then str:='31';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='16:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='16:29:59'  then str:='32';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='16:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='16:59:59'  then str:='33';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='17:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='17:29:59'  then str:='34';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='17:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='17:59:59'  then str:='35';

  elsif TO_CHAR(intime,'hh24:mi:ss')>='18:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='18:29:59'  then str:='36';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='18:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='18:59:59'  then str:='37';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='19:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='19:29:59'  then str:='38';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='19:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='19:59:59'  then str:='39';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='20:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='20:29:59'  then str:='40';

  elsif TO_CHAR(intime,'hh24:mi:ss')>='20:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='20:59:59'  then str:='41';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='21:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='21:29:59'  then str:='42';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='21:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='21:59:59'  then str:='43';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='22:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='22:29:59'  then str:='44';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='22:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='22:59:59'  then str:='45';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='23:00:00' and TO_CHAR(intime,'hh24:mi:ss')<='23:29:59'  then str:='46';
  elsif TO_CHAR(intime,'hh24:mi:ss')>='23:30:00' and TO_CHAR(intime,'hh24:mi:ss')<='23:59:59'  then str:='47';
  end if;*/
  return to_char(intime, 'yyyymmdd')||lpad(str,2,0);
end;


/

