create procedure command_test as

  tsajet1     varchar2(50);
  tsajet2     varchar2(50);
  tsajet3     varchar2(50);
  tsajet4     varchar2(50);
  tsajet5     clob;
  tsajet6     varchar2(50);
  tlineid     number;
  tstageid    number;
  tprocessid  number;
  tterminalid number;
  tnow        date;
  trev        varchar2(50);
  tres        varchar2(50);
  tnextproc   varchar2(50);

begin
  tsajet1     := '12';
  tsajet2     := 'TEST_ITEM';
  tsajet3     := 'DBN17N4229A0A51927';
  tsajet4     := '2';
  tsajet5     := 'test1:testdata1,test2:testdata2,test3:testdata3,test4:testdata4,test5:testdata5,test6:testdata6,test7:testdata7,test8:testdata8,test9:testdata9,test10:testdata10,test11:testdata11,test12:testdata12,test13:testdata13,test14:testdata14,test15:testdata15,test16:testdata16,test17:testdata17,test18:testdata18,test19:testdata19,test20:testdata20,test21:testdata21,test22:testdata22,test23:testdata23,test24:testdata24,test25:testdata25,test26:testdata26,test27:testdata27,test28:testdata28,test29:testdata29,test30:testdata30,test31:testdata31,test32:testdata32,test33:testdata33,test34:testdata34,test35:testdata35,test36:testdata36,test37:testdata37,test38:testdata38,test39:testdata39,test40:testdata40,test41:testdata41,test42:testdata42,test43:testdata43,test44:testdata44,test45:testdata45,test46:testdata46,test47:testdata47,test48:testdata48,test49:testdata49,test50:testdata50,test51:testdata51,test52:testdata52,test53:testdata53,test54:testdata54,test55:testdata55,test56:testdata56,test57:testdata57,test58:testdata58,test59:testdata59,test60:testdata60,test61:testdata61,test62:testdata62,test63:testdata63,test64:testdata64,test65:testdata65,test66:testdata66,test67:testdata67,test68:testdata68,test69:testdata69,test70:testdata70,test71:testdata71,test72:testdata72,test73:testdata73,test74:testdata74,test75:testdata75,test76:testdata76,test77:testdata77,test78:testdata78,test79:testdata79,test80:testdata80,test81:testdata81,test82:testdata82,test83:testdata83,test84:testdata84,test85:testdata85,test86:testdata86,test87:testdata87,test88:testdata88,test89:testdata89,test90:testdata90,test91:testdata91,test92:testdata92,test93:testdata93,test94:testdata94,test95:testdata95,test96:testdata96,test97:testdata97,test98:testdata98,test99:testdata99,test100:testdata100,test101:testdata101,test102:testdata102,test103:testdata103,test104:testdata104,test105:testdata105,test106:testdata106,test107:testdata107,test108:testdata108,test109:testdata109,test110:testdata110,test111:testdata111,test112:testdata112,test113:testdata113,test114:testdata114,test115:testdata115,test116:testdata116,test117:testdata117,test118:testdata118,test119:testdata119,test120:testdata120,test121:testdata121,test122:testdata122,test123:testdata123,test124:testdata124,test125:testdata125,test126:testdata126,test127:testdata127,test128:testdata128,test129:testdata129,test130:testdata130,test131:testdata131,test132:testdata132,test133:testdata133,test134:testdata134,test135:testdata135,test136:testdata136,test137:testdata137,test138:testdata138,test139:testdata139,test140:testdata140,test141:testdata141,test142:testdata142,test143:testdata143,test144:testdata144,test145:testdata145,test146:testdata146,test147:testdata147,test148:testdata148,test149:testdata149,test150:testdata150,test151:testdata151,test152:testdata152,test153:testdata153,test154:testdata154,test155:testdata155,test156:testdata156,test157:testdata157,test158:testdata158,test159:testdata159,test160:testdata160,test161:testdata161,test162:testdata162,test163:testdata163,test164:testdata164,test165:testdata165,test166:testdata166,test167:testdata167,test168:testdata168,test169:testdata169,test170:testdata170,test171:testdata171,test172:testdata172,test173:testdata173,test174:testdata174,test175:testdata175,test176:testdata176,test177:testdata177,test178:testdata178,test179:testdata179,test180:testdata180,test181:testdata181,test182:testdata182,test183:testdata183,test184:testdata184,test185:testdata185,test186:testdata186,test187:testdata187,test188:testdata188,test189:testdata189,test190:testdata190,test191:testdata191,test192:testdata192,test193:testdata193,test194:testdata194,test195:testdata195,test196:testdata196,test197:testdata197,test198:testdata198,test199:testdata199,test200:testdata200,';
  tsajet6     := '';
  tlineid     := 0;
  tstageid    := 0;
  tprocessid  := 100179;
  tterminalid := 10000744;
  tnow        := sysdate;
  sajet.command_code_fu_test(tsajet1, tsajet2, tsajet3, tsajet4, tsajet5, tsajet6, tlineid, tstageid, tprocessid,
                 tterminalid, tnow, trev, tres, tnextproc);

end;


/

