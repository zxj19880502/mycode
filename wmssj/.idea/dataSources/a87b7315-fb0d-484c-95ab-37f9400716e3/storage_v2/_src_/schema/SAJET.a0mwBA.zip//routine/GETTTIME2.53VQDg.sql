create function getttime2(ttime in date) return varchar2 is
  ttime1  varchar2(5);
  ttime2  varchar2(5);
  result1 varchar2(15);
begin
  ttime1 := to_char(ttime, 'YYYY');
  ttime2 := to_char(ttime, 'MM');
  if to_char(ttime, 'MM') < '10' then
    result1:= ttime1 || ttime2;
  elsif to_char(ttime, 'MM') = '10' then
    result1 := ttime1 || 'A';
  elsif to_char(ttime, 'MM') = '11' then
    result1 := ttime1 || 'B';
  elsif to_char(ttime, 'MM') = '12' then
    result1 := ttime1 || 'C';
  end if;
  return result1;

EXCEPTION
  WHEN OTHERS THEN
    RETURN SQLERRM;
END;


/

