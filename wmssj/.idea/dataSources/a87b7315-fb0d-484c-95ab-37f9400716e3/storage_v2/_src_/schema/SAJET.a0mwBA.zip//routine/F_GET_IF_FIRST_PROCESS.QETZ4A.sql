create function f_get_if_first_process(sRouteID   in varchar2,
                                                  sProcessID in varchar2)
  return varchar2 is
  vprocessid   number;
  vnextprocess number;
  vsheetname   varchar2(20);
  vstageid     number;
  vnodeid      number;
  vnextnode    number;
begin
  sajet.sj_get_firstprocess(sRouteID,
                            vprocessid,
                            vnextprocess,
                            vsheetname,
                            vstageid,
                            vnodeid,
                            vnextnode);
  if vprocessid <> sProcessID then
    return 'N';
  else
    return 'Y';
  end if;
end;


/

