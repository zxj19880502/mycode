create function shu_wo_base1(svalue in varchar2) return varchar2 is
	v_wo sajet.g_wo_base.work_order%type;

begin
	begin
		select a.work_order
		into   v_wo
		from   sajet.g_wo_base a, sajet.sys_part b
		where  a.part_id = b.part_id and a.work_order = svalue and rownum = 1;
	exception
		when no_data_found then
			v_wo := '';
	end;
	return upper(v_wo);
exception
	when others then
		return 'SHU_WO_ERR:' || sqlerrm;
end;


/

