create view V_WO_PROCESS_OUTPUT_DEFECT as
  select work_order,
       a.part_id,
       a.process_id,
       decode(a.process_id, 100031, sum(wip_in_qty), sum(wip_out_good_qty)) out_good,
       decode(a.process_id, 100031, 0, sum(wip_out_scrap_qty)) out_scrap,
       to_char(wip_out_time, 'yyyy/mm/dd') wip_out_date
  from sajet.g_rc_travel a
 where a.process_id <> 100030
 group by a.work_order,
          a.part_id,
          a.process_id,
          to_char(wip_out_time, 'yyyy/mm/dd')
union all
select work_order,
       part_id,
       process_id,
       sum(out_good) out_good,
       sum(out_scrap) out_scrap,
       wip_out_date
  from (select a.work_order,
               b.part_id,
               process_id,
               0 out_good,
               sum(qty) out_scrap,
               to_char(a.update_time, 'yyyy/mm/dd') wip_out_date
          from sajet.g_rc_travel_defect a, sajet.g_wo_base b
         where a.process_id = 100030
           and a.work_order = b.work_order
         group by a.work_order,
                  b.part_id,
                  process_id,
                  to_char(a.update_time, 'yyyy/mm/dd')
        union all
        select work_order,
               part_id,
               process_id,
               sum(wip_out_good_qty) out_good,
               0 out_scrap,
               to_char(wip_out_time, 'yyyy/mm/dd') wip_out_date
          from g_rc_travel
         where process_id = 100030
           and wip_out_time is not null
         group by work_order,
                  part_id,
                  process_id,
                  to_char(wip_out_time, 'yyyy/mm/dd'))
 group by work_order, part_id, process_id, wip_out_date


/

