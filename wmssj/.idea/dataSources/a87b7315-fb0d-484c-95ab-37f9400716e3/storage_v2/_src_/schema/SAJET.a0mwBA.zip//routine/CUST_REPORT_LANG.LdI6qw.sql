create FUNCTION       CUST_REPORT_LANG(TLANG IN VARCHAR2, TTYPE IN VARCHAR2, SVALUE IN VARCHAR2) RETURN VARCHAR2 IS
STR VARCHAR2(25);
BEGIN
  IF TTYPE = 'LINK TYPE' THEN
    IF TLANG = '繁體中文' THEN
      IF SVALUE = '1' THEN
        RETURN '按鈕';
      ELSE
        RETURN '右鍵選單';
      END IF;
    ELSE
      IF SVALUE = '1' THEN
        RETURN 'Button';
      ELSE
        RETURN 'Context Menu';
      END IF;
    END IF;
  ELSE
    IF TLANG = '繁體中文' THEN
      IF SVALUE = '1' THEN
        RETURN '是';
      ELSIF SVALUE = '0'THEN
        RETURN '否';
      ELSIF SVALUE = '2' THEN
        RETURN '擇一必要';
      ELSE
        RETURN SVALUE;
      END IF;
    ELSE
      IF SVALUE = '1' THEN
        RETURN 'Yes';
      ELSIF SVALUE = '0'THEN
        RETURN 'No';
      ELSIF SVALUE = '2' THEN
        RETURN 'Alternative';
      ELSE
        RETURN SVALUE;
      END IF;
    END IF;
  END IF;
END;


/

