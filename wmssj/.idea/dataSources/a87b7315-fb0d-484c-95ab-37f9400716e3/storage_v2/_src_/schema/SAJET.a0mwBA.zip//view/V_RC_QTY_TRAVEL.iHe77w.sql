create view V_RC_QTY_TRAVEL as
  select work_order,
       rc_no,
       part_id,
       pdline_id,
       stage_id,
       process_id,
       nvl(in_process_shift,'N/A') shift_name,--投入班别
       in_process_time work_time,---投入时间
       wip_in_qty,--投入数量
       0 pass_qty,
       0 fail_qty
  from sajet.g_rc_status
 where in_process_time is not null
   and out_process_time is null
   union all
   select work_order,
       rc_no,
       part_id,
       pdline_id,
       stage_id,
       process_id,
       nvl(in_process_shift,'N/A') shift_name,--投入班别
       in_process_time work_time,---投入时间
       wip_in_qty,--投入数量
       0 pass_qty,
       0 fail_qty
       from sajet.g_rc_travel
       union all
       select work_order,
       rc_no,
       part_id,
       pdline_id,
       stage_id,
       process_id,
       nvl(out_process_shift,'N/A') shift_name,--产出班别
       out_process_time work_time,---投入时间
       0 wip_in_qty,--投入数量
      (case when current_status<>1 then wip_in_qty else  0  end  ) pass_qty,
       (case when current_status=1 then wip_in_qty else  0  end  ) fail_qty
       from sajet.g_rc_travel


/

