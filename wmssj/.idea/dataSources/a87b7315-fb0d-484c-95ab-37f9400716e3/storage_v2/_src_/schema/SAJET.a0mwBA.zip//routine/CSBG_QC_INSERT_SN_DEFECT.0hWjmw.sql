create procedure       csbg_qc_insert_sn_defect(tdefectdata in varchar2
														  ,tqclotno    in varchar2
														  ,tqccnt      in varchar2
														  ,tterminalid in number
														  ,tlineid     in number
														  ,tstageid    in number
														  ,tprocessid  in number
														  ,tmodelid    in number
														  ,tempid      in number
														  ,tres        out varchar2) is
	/*---------------------------------
    DATE : 2005/05/17
    ----------------------------------*/
	istart    number;
	iend      number;
	c_linkstr varchar2(1);
	--================DEFECT==================
	c_sn          sajet.g_sn_status.serial_number%type;
	c_defectqty   number;
	c_defectcode  sajet.sys_defect.defect_code%type;
	c_defectid    number;
	c_insptime    varchar2(25);
	c_defectlevel sajet.sys_defect.defect_level%type;
	c_wo          sajet.g_wo_base.work_order%type;
begin
	istart    := 0;
	iend      := 0;
	c_linkstr := '@';
	tres      := 'OK';
	loop
		begin
			istart := iend + 1;
			iend   := instr(tdefectdata, c_linkstr, istart, 1);
			exit when(iend = 0) or(tres <> 'OK');
			c_sn          := substr(tdefectdata, istart, iend - istart);
			istart        := iend + 1;
			iend          := instr(tdefectdata, c_linkstr, istart, 1);
			c_defectcode  := substr(tdefectdata, istart, iend - istart);
			istart        := iend + 1;
			iend          := instr(tdefectdata, c_linkstr, istart, 1);
			c_defectqty   := to_number(substr(tdefectdata, istart, iend - istart));
			istart        := iend + 1;
			iend          := instr(tdefectdata, c_linkstr, istart, 1);
			c_defectid    := to_number(substr(tdefectdata, istart, iend - istart));
			istart        := iend + 1;
			iend          := instr(tdefectdata, c_linkstr, istart, 1);
			c_defectlevel := substr(tdefectdata, istart, iend - istart);
			istart        := iend + 1;
			iend          := instr(tdefectdata, c_linkstr, istart, 1);
			c_insptime    := substr(tdefectdata, istart, iend - istart);
			begin
				insert into sajet.g_qc_sn_defect
					(qc_lotno, serial_number, qc_cnt, defect_id, defect_level, location, defect_qty)
				values
					(tqclotno, c_sn, tqccnt, c_defectid, c_defectlevel, 'N/A', c_defectqty);
			exception
				when others then
					tres := 'INSERT SN DEFECT ERROR';
			end;
			if tres = 'OK' then
				begin
					--Insert G_SN_DEFECT
					select work_order into c_wo from sajet.g_sn_status where serial_number = c_sn and rownum = 1;
					sajet.csbg_defect_input(tlineid, tstageid, tprocessid, tterminalid, c_sn, c_defectcode,
											to_date(c_insptime, 'yyyymmddhh24miss'), tempid, c_wo, tmodelid, c_defectqty);
				exception
					when others then
						tres := 'Call CSBG_DEFECT_INPUT ERROR!';
				end;
			end if;
		exception
			when others then
				tres := 'GET SN DEFECT DATE ERROR  !! ' || sqlerrm;
		end;
	end loop;
exception
	when others then
		tres := 'Execute (CSBG_Qc_Insert_Sn_Defect) Error!';
end;


/

