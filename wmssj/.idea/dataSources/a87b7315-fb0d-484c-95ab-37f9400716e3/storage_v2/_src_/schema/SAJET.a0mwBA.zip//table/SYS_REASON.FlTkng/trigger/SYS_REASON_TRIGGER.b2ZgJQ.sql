create trigger SYS_REASON_TRIGGER
  after insert or update or delete
  on SYS_REASON
  for each row
declare
    ncount number;
begin
    if inserting then
        insert into sajet.g_tri_data
            (data_id, data_table, update_user, update_time)
        values
            (:new.REASON_ID, 'SAJET.SYS_REASON', :new.update_userid, sysdate);

    end if;

exception
    when others then
        insert into sajet.g_tri_log
            (table_name, param1, param2, param3, clog, row_id, update_time)
        values
            ('sajet.SYS_REASON', 'REASON_ID', :new.REASON_ID, null, 'SYS_REASON_trigger error', null, sysdate);

end;

/

