create PROCEDURE BITLAND_CHECK_COA(TSN          in varchar2,
                                              TCOANO       in varchar2,
                                              TTERMINALID  in varchar2,
                                              TEMP         in varchar2,
                                              TITEM_PARTID out varchar2,
                                              TWO          out varchar2,
                                              TRES         out varchar2) IS
  ssn       varchar2(100);
  curstatus number;
  empid     number;
  wo        sajet.g_sn_status.work_order%type;
  --itempartid sajet.g_wo_bom.item_part_id%type;
BEGIN
  TRES      := 'OK';
  ssn       := 'N/A';
  curstatus := -1;
  empid     := 0;
  if TSN is null then
    TRES := 'sn is null';
  elsif TCOANO is null then
    TRES := 'Coa No is null';
  elsif TEMP is null then
    TRES := 'emp no is null';
  end if;

  if TRES != 'OK' then
    return;
  end if;
  sajet.Sj_Get_Empid(TEMP, empid);
  if empid = 0 then
    TRES := 'No this EMP No(' || TEMP || ')';
  end if;
  if TRES != 'OK' then
    return;
  end if;
  select sc.serial_number, sc.status
    into ssn, curstatus
    from sajet.g_sn_coa sc
   where sc.coa_no = TCOANO;
  if ssn is not null then
    --？？？？coa no
    TRES := 'This coa no(' || TCOANO || ') has been used';
  elsif curstatus != 1 then
    --？？？？？？
    TRES := 'This coa no(' || TCOANO || ') not out warehouse';
  else
    --找此COA是否在WorkingBOM中
    begin
      select ss.work_order
        into TWO
        from sajet.g_sn_status ss
       where ss.serial_number = TSN; --Find WO
      select wb.item_part_id
        into TITEM_PARTID --比?WorkingBOM
        from sajet.sys_part p, sajet.g_sn_coa sc, sajet.g_wo_bom wb
       where p.part_id = sc.part_id
         and sc.part_id = wb.item_part_id
         and wb.work_order = TWO
         and sc.coa_no = TCOANO;
    exception
      when others then
        TRES := SQLERRM;
        return;
    end;
  end if;
exception
  when NO_DATA_FOUND then
    --？？？？coa no
    TRES := 'No this coa no(' || TCOANO || ')record';
  WHEN OTHERS THEN
    TRES := SQLERRM;
    rollback;
end;
/

