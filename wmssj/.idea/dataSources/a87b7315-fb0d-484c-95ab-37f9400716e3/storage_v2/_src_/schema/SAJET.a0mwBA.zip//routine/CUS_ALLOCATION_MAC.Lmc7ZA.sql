create procedure       cus_allocation_mac(tvendor in number
													,tcnt    in number
													,temp    in number
													,tres    out varchar2) is
	cursor t_mac is
		select rownum as rnm, mac, captcha
		from   (select mac, captcha from cus_mac_base where status = 1 order by mac)
		where  rownum <= tcnt;
	tmac t_mac%rowtype;
begin
	for tmac in t_mac loop
		insert into cus_mac_allocation
			(mac, captcha, vendor_id, update_emp)
		values
			(tmac.mac, tmac.captcha, tvendor, temp);
		update cus_mac_base set status = 2 where mac = tmac.mac;
	end loop;
	tres := 'OK';
exception
	when others then
		tres := 'NG;MAC分配發生錯誤';
		rollback;
end cus_allocation_mac;


/

