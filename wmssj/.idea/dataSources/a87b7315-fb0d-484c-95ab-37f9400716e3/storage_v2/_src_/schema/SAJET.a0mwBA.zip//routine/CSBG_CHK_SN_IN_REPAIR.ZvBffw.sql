create procedure       csbg_chk_sn_in_repair(tsn             in varchar2
													   ,tres            out varchar2
													   ,cnext_processid out number) is
	croute_id         number;
	cprocessid        number;
	cstatus           varchar2(10);
	cnext_process     varchar2(25);
	crepair_processid number;
begin
	select route_id, process_id, current_status
	into   croute_id, cprocessid, cstatus
	from   sajet.g_sn_status
	where  serial_number = tsn;
	--SN 必須為良品
	if cstatus <> '0' then
		tres := 'SN FAIL';
		goto endp;
	end if;
	--SN目前應到的站
	begin
		select next_process_id, b.process_name
		into   cnext_processid, cnext_process
		from   sajet.sys_route_detail a, sajet.sys_process b
		where  a.route_id = croute_id and a.process_id = cprocessid and a.result = '0' and a.enabled = 'Y' and
			   a.necessary = 'Y' and a.next_process_id = b.process_id and rownum = 1;
	exception
		when others then
			tres := 'Route End';
			goto endp;
	end;
	--檢查目前SN所在站別是否有維修站
	begin
		select next_process_id
		into   crepair_processid
		from   sajet.sys_route_detail a, sajet.sys_process b
		where  a.route_id = croute_id and a.process_id = cnext_processid and a.result = '1' and a.enabled = 'Y' and
			   a.next_process_id = b.process_id and rownum = 1;
	exception
		when others then
			tres := cnext_process || ' - No Repair Process';
			goto endp;
	end;
	tres := 'OK';
	<<endp>>
	null;
exception
	when others then
		tres := 'Input_Defect error';
end;


/

