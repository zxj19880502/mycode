create procedure command_code(tlineid     in number
										,tstageid    in number
										,tprocessid  in number
										,tterminalid in number
										,tnow        in date
										,trev        in varchar2
										,tres        out varchar2
										,tnextproc   out varchar2) is
	tsajet1      varchar2(25);
	tsajet2      varchar2(25);
	tsajet3      varchar2(128);
	tsajet4      varchar2(128);
	tsajet4ton   varchar2(4096);
	tsajet5ton   varchar2(4096);
	c_buffer     varchar2(4096);
	c_head       number;
	cmd          number;
	c_number     number;
	c_start      number;
	c_end        number;
	c_psn        varchar2(35);
	c_temp       varchar2(255);
	c_item       sajet.sys_spc.spc_item%type;
	c_value      sajet.g_spc.spc_value%type;
	c_defect     sajet.sys_defect.defect_code%type;
	c_wo         sajet.g_sn_status.work_order%type;
	c_wo_seq     smt.g_wo_msl.wo_sequence%type;
	c_datecode   smt.g_smt_status.datecode%type;
	c_dbid       varchar2(20);
	c_type       number;
	c_eventid    number;
	t_type       varchar2(25);
	check_status varchar2(10);
	msl_status   varchar2(30);
	c_factory    number;
begin
	tres := 'Fail,Command fail';
	--
	if substr(trev, length(trev), 1) = ';' then
		c_buffer := trev;
	else
		c_buffer := trev || ';';
	end if;

	c_number := 1;
	c_start  := 1;
	c_end    := instr(c_buffer, ';', c_start, c_number);

	if c_end <= 3 then
		begin
			cmd := substr(c_buffer, c_start, c_end - c_start);
			-- INCREASE INDEX
			c_number := c_number + 1;
			c_start  := c_end + 1;
		exception
			when others then
				cmd := 999;
		end;
	else
		cmd := 999;
	end if;
	--

	if cmd = 1 then
		c_end := instr(c_buffer, ';', 1, c_number);
	
		if (c_end - c_start) <= 25 then
			tsajet2 := substr(c_buffer, c_start, c_end - c_start);
			sajet.sj_cksys_emp(tsajet2, tres);
		
			if tres = 'OK' then
				tres := 'OK;OK;';
			else
				tres := 'NG;[EC201] EMP NO NG 1;' || ' [' || tsajet2 || ']';
			end if;
		else
			tres := 'NG;[EC201] EMP NO NG 2;';
		end if;
	
	elsif cmd = 2 then
		c_end := instr(c_buffer, ';', 1, c_number);
	
		if (c_end - c_start) <= 25 then
			tsajet2 := substr(c_buffer, c_start, c_end - c_start);
			--SAJET.SJ_CKRT_SN(tsajet2, tres);
			sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
			if tres = 'OK' then
				--SAJET.SJ_CKRT_ROUTE(TTerminalid, tsajet2, tres);
				----CHECK MI
				begin
					select trim(param_value)
					into   check_status
					from   sys_base
					where  param_name = 'Check MI' and rownum = 1;
					if (check_status = 'Y') then
						begin
							select work_order
							into   c_wo
							from   sajet.g_sn_status
							where  serial_number = c_psn and rownum = 1;
						
							select wo_sequence, status
							into   c_wo_seq, msl_status
							from   sajet.g_mi_wo_msl a
							where  work_order = c_wo and a.line_id = tlineid and rownum = 1;
						exception
							when others then
								msl_status := '';
						end;
						if (msl_status = 'LOADOK') then
							tres := 'MSL not Input (' || c_wo || ')';
						elsif msl_status = '' then
							tres := 'MSL not Create(' || c_wo || ')';
						else
							tres := 'OK';
						end if;
						if tres <> 'OK' then
							t_type := 'MI'; -- EVENT TYPE:  MI
							begin
								select type_id
								into   c_type
								from   sajet.alarm_type_base
								where  type_name = t_type and enabled = 'Y' and rownum = 1;
								begin
									select factory_id
									into   c_factory
									from   sajet.sys_pdline
									where  pdline_id = tlineid and rownum = 1;
									select trim(param_value) || to_char(tnow, 'Y') ||
											lpad(sajet.s_alarm_code.nextval, 6, 0)
									into   c_eventid
									from   sajet.sys_base
									where  param_name = 'DBID';
									insert into sajet.alarm_event
										(event_id, event_status, type_id, event_level, factory_id, pdline_id, stage_id,
										 process_id, terminal_id, event_desc, record_time)
									values
										(c_eventid, 0, c_type, 3, c_factory, tlineid, tstageid, tprocessid, tterminalid,
										 tres, tnow);
								exception
									when others then
										tres := 'INSERT ALARM_EVENT Error';
								end;
							exception
								when others then
									tres := 'NO MI ALARM';
							end;
						end if;
					end if;
				exception
					when others then
						tres := 'OK';
				end;
				if tres = 'OK' then
					sajet.sj_ckrt_route(tterminalid, c_psn, tres);
					if tres = 'OK' then
						tres := 'OK;OK;';
					else
						tres := 'NG;[EC999] Route NG:' || tres || ';';
					end if;
				end if;
			else
				tres := 'NG;' || tres || ';';
			end if;
		else
			tres := 'NG;[EC202] SN NG2;';
		end if;
	elsif cmd = 3 then
		c_end := instr(c_buffer, ';', 1, c_number);
	
		if (c_end - c_start) <= 25 then
			tsajet2 := substr(c_buffer, c_start, c_end - c_start); -- GET EMP
			sajet.sj_cksys_emp(tsajet2, tres);
		
			-- INCREASE INDEX
			c_number := c_number + 1;
			c_start  := c_end + 1;
		
			if tres = 'OK' then
				-- CHECK EMP OK
				c_end := instr(c_buffer, ';', 1, c_number);
			
				if (c_end - c_start) <= 25 then
					tsajet3 := substr(c_buffer, c_start, c_end - c_start); -- GET SN
					--SAJET.SJ_CKRT_SN(tsajet3,tres);
					sajet.sj_ckrt_sn_psn(tsajet3, tres, c_psn);
				
					-- INCREASE INDEX
					c_number := c_number + 1;
					c_start  := c_end + 1;
				else
					tres := 'NG;[EC202] SN NG3;';
				end if;
			else
				-- CHECK EMP NG
				tres := 'NG;[EC201] EMP NO NG;';
			end if;
		
			if tres = 'OK' then
				-- CHECK SN OK
				--SAJET.SJ_CKRT_ROUTE(TTerminalID,tsajet3,tres);
				sajet.sj_ckrt_route(tterminalid, c_psn, tres);
			
				if tres <> 'OK' then
					-- CHECK ROUTE NG
					tres := 'NG;[EC999] Route NG:' || tres || ';';
				end if;
			else
				-- CHECK SN NG
				tres := 'NG;' || tres || ';';
			end if;
		
			if tres = 'OK' then
				-- CHECK ROUTE OK
				c_end := instr(c_buffer, ';', 1, c_number);
				if (c_end - c_start) = 2 then
					tsajet4 := substr(c_buffer, c_start, c_end - c_start); -- GET RESULT
				
					-- INCREASE INDEX
					c_number := c_number + 1;
					c_start  := c_end + 1;
				
					if tsajet4 = 'OK' then
						--SAJET.SJ_Go(TTerminalID,tsajet3,tnow,tres,tsajet2);
						sajet.sj_go(tterminalid, c_psn, tnow, tres, tsajet2);
					
						if substr(tres, 1, 2) = 'OK' then
							tres := 'OK;OK;';
						else
							tres := 'NG;[EC101] CALL DBA;';
						end if;
					elsif tsajet4 = 'NG' then
						tsajet5ton := substr(c_buffer, c_start, length(c_buffer) - c_start) || ';';
						c_number   := 1;
						c_start    := 1;
						loop
							c_end := instr(tsajet5ton, ';', 1, c_number);
							exit when c_end = 0;
						
							c_defect := trim(substr(tsajet5ton, c_start, c_end - c_start));
							sajet.sj_cksys_defect(c_defect, tres);
							if substr(tres, 1, 2) <> 'OK' then
								tres := 'NG;[EC203] ERROR CODE NG;' || ' [' || c_defect || ']';
								exit;
							end if;
						
							--Sajet.Sj_Nogo(TTerminalID, tsajet3,c_Defect,tnow,tres,tnextproc,tsajet2);
							sajet.sj_nogo(tterminalid, c_psn, c_defect, tnow, tres, tnextproc, tsajet2);
							if substr(tres, 1, 2) <> 'OK' then
								tres := 'NG;[EC101] CALL DBA;';
								exit;
							end if;
						
							c_start  := c_end + 1;
							c_number := c_number + 1;
						end loop;
					
						if tres = 'OK' then
							tres := 'OK;OK;';
							commit;
						else
							rollback;
						end if;
					else
						tres := 'NG;[EC101] RESULT NG;';
					end if;
				else
					tres := 'NG;[EC101] RESULT NG;';
				end if;
			
			end if;
		else
			tres := 'NG;[EC201] EMP NO NG;';
		end if;
	
		--ELSIF cmd = 4
		--THEN
	
	elsif cmd = 5 then
		sajet.sj_cksys_emp(tsajet2, tres);
		if tres = 'OK' then
			--SAJET.SJ_CKRT_SN(tsajet3,tres);
			sajet.sj_ckrt_sn_psn(tsajet3, tres, c_psn);
		end if;
	
		--If tres = 'OK' Then
		--SAJET.SJ_CKRT_ROUTE(TTerminalID,tsajet3,tres);
		--End If;
	
		if tres = 'OK' then
			c_number := 1;
			c_start  := 1;
			loop
				c_end := instr(tsajet4ton || ';', ';', 1, c_number);
				exit when c_end = 0;
				c_temp := substr(tsajet4ton || ';', c_start, c_end - c_start);
				if instr(c_temp, ':', 1, 1) = 0 then
					tres := 'SPC [Item:Value] Format Error!';
					exit;
				else
					c_item := trim(substr(c_temp, 1, instr(c_temp, ':', 1, 1) - 1));
					sajet.sj_chk_spc_item(c_item, tres);
					exit when tres <> 'OK';
				
					begin
						c_value := trim(substr(c_temp, instr(c_temp, ':', 1, 1) + 1,
											   length(c_temp) - instr(c_temp, ':', 1, 1)));
					exception
						when others then
							tres := 'Test Value Error' || ' - ' || c_value;
							exit;
					end;
				
					--SAJET.SJ_INSERT_SPC_ITEM(c_item,tsajet3,c_value,tlineid,tstageid,tprocessid,tterminalid,tsajet2,tnow,tres);
					sajet.sj_insert_spc_item(c_item, c_psn, c_value, tlineid, tstageid, tprocessid, tterminalid,
											 tsajet2, tnow, tres);
					exit when tres <> 'OK';
				end if;
				c_start  := c_end + 1;
				c_number := c_number + 1;
			end loop;
		end if;
	else
		tres := 'NG;[EC102] COMMAND NOT DEFINE.;';
	end if;
end;
/

