create trigger T_ED_EMP
  before insert
  on ED_EMP
  for each row
DECLARE
  C_EMPID NUMBER;
  C_EMPNO VARCHAR2(50);
  C_DATE  VARCHAR2(50);
BEGIN
  :NEW.LOG := 'OK';
  BEGIN
    SELECT TO_CHAR(UPDATE_TIME, 'yy/mm/dd')
      INTO C_DATE
      FROM SAJET.SYS_EMP
     WHERE EMP_NO = :NEW.EMP_NO;
    BEGIN
      IF C_DATE <> :NEW.EMP_UPDATETIME THEN
        UPDATE SAJET.SYS_EMP
           SET EMP_NAME    = :NEW.EMP_SURNAME || NVL(:NEW.EMP_NAME, ''),
               UPDATE_TIME = TO_DATE(:NEW.EMP_UPDATETIME, 'yyyy/mm/dd')
         WHERE EMP_NO = :NEW.EMP_NO;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        :NEW.LOG := SQLERRM;
        RETURN;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        SELECT NVL(MAX(EMP_ID), 10000000) + 1
          INTO C_EMPID
          FROM SAJET.SYS_EMP;
      
        INSERT INTO SAJET.SYS_EMP
          (EMP_ID, EMP_NO, EMP_NAME, PASSWD, UPDATE_TIME,FACTORY_ID)
        VALUES
          (C_EMPID,
           :NEW.EMP_NO,
           :NEW.EMP_SURNAME || NVL(:NEW.EMP_NAME, ''),
           SAJET.PASSWORD.ENCRYPT(:NEW.EMP_NO),
           TO_DATE(:NEW.EMP_UPDATETIME, 'yyyy/mm/dd'),
           '10010');
      EXCEPTION
        WHEN OTHERS THEN
          :NEW.LOG := SQLERRM;
          RETURN;
      END;
  END;
EXCEPTION
  WHEN OTHERS THEN
    :NEW.LOG := SQLERRM;
END;


/

