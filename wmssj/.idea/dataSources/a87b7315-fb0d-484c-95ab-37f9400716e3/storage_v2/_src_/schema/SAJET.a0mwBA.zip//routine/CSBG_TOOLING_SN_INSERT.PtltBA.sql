create procedure       csbg_tooling_sn_insert(t_tooling_id in varchar2
														,t_tooling_sn in varchar2
														,t_emp_id     in varchar2
														,tres         out varchar2) is
	v_tooling_sn_id number;
begin
	tres := 'OK';
	begin
		select nvl(max(tooling_sn_id), 0) + 1 into v_tooling_sn_id from sajet.sys_tooling_sn;
		if v_tooling_sn_id = 1 then
			select rpad(nvl(param_value, '1'), 5, '0') || '001'
			into   v_tooling_sn_id
			from   sajet.sys_base
			where  param_name = 'DBID';
		end if;
	exception
		when others then
			tres := ' GET TOOLING SN ID ERROR';
	end;
	if tres = 'OK' then
		insert into sajet.sys_tooling_sn
			(tooling_sn_id, tooling_sn, tooling_id, update_userid)
		values
			(v_tooling_sn_id, t_tooling_sn, t_tooling_id, t_emp_id);
		insert into sajet.g_tooling_sn_status
			(tooling_sn_id, used_count, last_maintain_time, work_order, process_id)
			select tooling_sn_id, 0, null, 'N/A', null from sajet.sys_tooling_sn where tooling_sn_id = v_tooling_sn_id;
		commit;
	end if;
exception
	when others then
		rollback;
		tres := '  CSBG_TOOLING_SN_INSERT ERROR';
end;


/

