create view V_PROCESS_A_FC as
select a.process_id,
               a.process_name,
               c.part_no,
               c.option1,
               sum(b.wip_in_qty) IN_QTY,
               0 OUT_QTY,
               0 SCRAP_QTY,
              d.emp_name in_name,
              e.emp_name ,
              a.update_time
          from sajet.sys_process a, sajet.g_rc_travel b, sajet.sys_part c,sajet.sys_emp d,sajet.sys_emp e
         where a.process_id = b.process_id
           and b.part_id = c.part_id
           and b.wip_in_empid=d.emp_id(+)
           and b.wip_out_empid=e.emp_id(+)
         group by a.process_id, a.process_name, c.part_no, c.option1,d.emp_name,
              e.emp_name,a.update_time


/

