create procedure CK_EMP_PW(EMPNO IN VARCHAR2,EMPPW OUT VARCHAR2,RES OUT VARCHAR2) is

begin
  RES:='OK';
   select PASSWORD.decrypt(PASSWD) INTO EMPPW from sajet.sys_emp where emp_no =EMPNO;
   EXCEPTION
     WHEN OTHERS THEN
       RES:='ERROR';
end CK_EMP_PW;


/

