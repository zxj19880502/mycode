create view SYS_PN_BASE_RULE_VIEW as
  select '11S' Label_Rule,a."CUST_NO",a."CUST_MODEL",a."PART_NO",a."COMPONENT_PART_NO",a."CUSTOMER_PART_NO",a."CUSTOMER_PART_DESC",a."CUSTOMER_CPU_PART",a."CUSTOMER_FRU_PART",a."WMS",a."FLAG",a."REMARK",a."UPDATE_USER_ID",a."UPDATE_TIME",a."COUNTRY"
  from sajet.sys_pn_base a
 where length(customer_fru_part) <> 10
union (select '8S' Label_Rule,a."CUST_NO",a."CUST_MODEL",a."PART_NO",a."COMPONENT_PART_NO",a."CUSTOMER_PART_NO",a."CUSTOMER_PART_DESC",a."CUSTOMER_CPU_PART",a."CUSTOMER_FRU_PART",a."WMS",a."FLAG",a."REMARK",a."UPDATE_USER_ID",a."UPDATE_TIME",a."COUNTRY"
  from sajet.sys_pn_base a
 where length(customer_fru_part) = 10)


/

