create trigger T_CLOG_PART_NEW
  before insert
  on CUS_CLOG_PART_BASE
  for each row
declare
	-- local variables here
begin
	select sys_guid() into :new.keyid from dual;
end t_clog_part_new;


/

