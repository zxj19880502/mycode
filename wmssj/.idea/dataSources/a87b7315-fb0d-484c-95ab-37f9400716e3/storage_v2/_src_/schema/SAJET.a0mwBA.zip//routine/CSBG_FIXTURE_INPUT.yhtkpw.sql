create procedure       csbg_fixture_input(two           in varchar2
													,tsn           in varchar2
													,ttool         in varchar2
													,tprocessid    in number
													,tterminalid   in number
													,tempid        in varchar2
													,p_tooling_seq in number
													,tnow          in date
													,tres          out varchar2) is
	c_wo       sajet.g_sn_status.work_order%type;
	ctool_snid sajet.sys_tooling_sn.tooling_sn_id%type;
begin
	select tooling_sn_id into ctool_snid from sajet.sys_tooling_sn where tooling_sn = ttool;
	update sajet.g_tooling_sn_status
	set    work_order = two, process_id = tprocessid, terminal_id = tterminalid, serial_number = tsn,
		   get_userid = tempid, get_time = tnow, tooling_seq = p_tooling_seq
	where  tooling_sn_id = ctool_snid;
	tres := 'OK';
exception
	when others then
		tres := 'CSBG_FIXTURE_INPUT ERROR! ';
end;


/

