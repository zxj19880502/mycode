create procedure Check_Box(TBOXNO IN VARCHAR2,
                                      TRES   OUT varchar2) is
  TCOUNT    number;
  TCOUNT1    number;

BEGIN
  --判断料卷号是否锁定
  TRES := 'OK';
  SELECT COUNT(*)
    INTO TCOUNT
    FROM SAJET.SYS_BOX_LOCK A
   WHERE A.ENABLED = 'Y'
     AND A.BOX_NO = TBOXNO;
  IF TCOUNT>0 THEN
    TRES := '此料卷号已锁定！';
    goto endp;
  END IF;
  --判断料卷号或料号是否达到红色预警

  select COUNT(*)  INTO TCOUNT1
                  from (select b.part_no,
                               T.box_no,
                               case
                                 when (sysdate - t.update_time) >= f.ywarn_time and
                                      (sysdate - t.update_time) < f.rwarn_time then
                                  '黄色预警'
                                 when (sysdate - t.update_time) >= f.rwarn_time then
                                  '红色预警'
                                 else
                                  '正常'
                               end warn
                          from sajet.wms_stock     T,
                               sajet.sys_part      b,
                               sajet.sys_part_warn f
                         where T.part_id = b.part_id
                           and f.part_id = b.part_id
                           and t.box_no=TBOXNO
                        union
                        select b.part_no,
                               T.box_no,
                               case
                                 when (sysdate - t.update_time) >= 120 and (sysdate - t.update_time) < 180 then
                                  '黄色预警'
                                 when (sysdate - t.update_time) >= 180 then
                                  '红色预警'
                                 else
                                  '正常'
                               end warn
                          from sajet.wms_stock T, sajet.sys_part b
                         where T.part_id = b.part_id  and t.box_no=TBOXNO) dd
                 where warn = '红色预警';
  IF TCOUNT1>0 THEN
    TRES := '料号达到红色预警!';
    goto endp;
  END IF;

  <<endp>>
   null;
EXCEPTION
  WHEN OTHERS THEN
    TRES := SQLERRM;
    ROLLBACK;
END;


/

