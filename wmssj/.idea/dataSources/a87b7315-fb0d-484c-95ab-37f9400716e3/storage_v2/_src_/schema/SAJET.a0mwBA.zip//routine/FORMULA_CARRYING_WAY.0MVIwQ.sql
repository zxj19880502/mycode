create FUNCTION       
            FORMULA_CARRYING_WAY(SVALUE IN VARCHAR2) RETURN VARCHAR2 IS
STR VARCHAR2(100);
BEGIN
  IF SVALUE = '0' THEN
    STR := 'None';
  ELSIF SVALUE = '1' THEN
    STR := 'Round Off';
  ELSIF SVALUE = '2' THEN
    STR := 'Leaves unconditionally';
  ELSE
    STR := 'Unknown';
  END IF;
  RETURN STR;
END;


/

