create function       pc_get_version(srowid in varchar2) return varchar2 is
	str       varchar2(255);
	c_type    sajet.pc_version_link.version_type%type;
	c_program sajet.pc_version_link.program_type_id%type;
	c_name    sajet.pc_version_link.version_name_id%type;
	c_version sajet.pc_version_link.version_id%type;
	c_desc    sajet.pc_program_version.version_desc%type;
begin
	select version_type, program_type_id, version_name_id, version_id
	into   c_type, c_program, c_name, c_version
	from   sajet.pc_version_link
	where  rowid = srowid and rownum = 1;
	if c_type = 0 then
		str := '';
	elsif c_type = 1 then
		select a.version_1 || '.' || a.version_2 || '.' || a.version_3 || '.' || a.version_4, version_desc
		into   str, c_desc
		from   sajet.pc_program_version a
		where  a.version_id = c_version and rownum = 1;
	elsif c_type = 2 then
		select a.version_1 || '.' || a.version_2 || '.' || a.version_3 || '.' || a.version_4, version_desc
		into   str, c_desc
		from   sajet.pc_program_version a, sajet.pc_program_version_name b
		where  a.program_type_id = b.program_type_id and a.version_name_id = b.version_name_id and
			   b.program_type_id = c_program and b.version_name_id = c_name and a.version_id = b.default_version and
			   a.enabled = 'Y' and rownum = 1;
	elsif c_type = 3 then
		select a.version_1 || '.' || a.version_2 || '.' || a.version_3 || '.' || a.version_4, version_desc
		into   str, c_desc
		from   sajet.pc_program_version a
		where  program_type_id = c_program and version_name_id = c_name and
			   (version_1 || version_2 || version_3 || version_4) =
			   (select max(version_1 || version_2 || version_3 || version_4)
				from   sajet.pc_program_version a
				where  program_type_id = c_program and version_name_id = c_name and enabled = 'Y') and enabled = 'Y';
	elsif c_type = 4 then
		select a.version_1 || '.' || a.version_2 || '.' || a.version_3 || '.' || a.version_4, version_desc
		into   str, c_desc
		from   sajet.pc_program_version a
		where  program_type_id = c_program and version_name_id = c_name and
			   (version_1 || version_2 || version_3 || version_4) =
			   (select max(version_1 || version_2 || version_3 || version_4)
				from   sajet.pc_program_version a
				where  release_time = (select max(release_time)
									   from   sajet.pc_program_version
									   where  program_type_id = c_program and version_name_id = c_name and
											  release_time <= sysdate and enabled = 'Y') and program_type_id = c_program and
					   version_name_id = c_name and enabled = 'Y') and program_type_id = c_program and
			   version_name_id = c_name and enabled = 'Y';
	end if;
	return str || '*' || c_desc;
exception
	when others then
		return '*';
end;


/

