create view V_ABCD as
select wo_status,part_no,process_name,pdline_name,stage_name,out_process_time
from sajet.G_SN_TRAVEL a,sajet.g_wo_base b, sajet.sys_part c,sajet.sys_process d,sajet.sys_pdline e,sajet.sys_stage f
where serial_number='201970300002' and a.work_order=b.work_order and c.part_id=a.part_id and a.process_id=d.process_id and a.pdline_id=e.pdline_id and a.stage_id=f.stage_id
order by to_char(out_process_time) asc


/

