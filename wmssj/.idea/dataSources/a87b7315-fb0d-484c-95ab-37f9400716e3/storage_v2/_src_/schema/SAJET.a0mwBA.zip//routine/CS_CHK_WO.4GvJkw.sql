create procedure       cs_chk_wo(trev       in varchar2
										   ,tprocessid in number
										   ,tres       out varchar2) is
	ok varchar2(25);
begin
	sajet.sj_chk_wo_input(trev, ok);
	if ok = 'OK' then
		sajet.cs_chk_input_qty(trev, tprocessid, ok);
	end if;
	tres := ok;
end;


/

