create procedure bc_revoke_sn(two    in varchar2
										,tstart in varchar2
										,tend   in varchar2
										,tempid in number
										,tres   out varchar2) is
	/*c_count   number;
    i_qty     number;
    c_total   number;
    c_panel   sajet.g_sn_status.panel_no%type;
    c_part    sajet.g_wo_base.part_id%type;
    c_route   sajet.g_wo_base.route_id%type;
    c_version sajet.g_wo_base.version%type;*/
	---序号的回收表
begin
	insert into sajet.g_wo_sn_deletebk
		(work_order, serial_number, update_userid, update_time)
		select work_order, serial_number, tempid, sysdate
		from   sajet.g_sn_status
		where  work_order = two and process_id = 0 and serial_number >= tstart and serial_number <= tend;

	insert into sajet.g_sn_status_ht
		(select *
		 from   sajet.g_sn_status
		 where  work_order = two and process_id = 0 and serial_number >= tstart and serial_number <= tend);


	--删除g_wo_sn
	delete from sajet.g_wo_sn a
	where  work_order = two and
		   a.serial_number in
		   (select serial_number
			from   sajet.g_sn_status
			where  work_order = two and process_id = 0 and serial_number >= tstart and serial_number <= tend);

	delete from sajet.g_sn_status
	where  work_order = two and process_id = 0 and serial_number >= tstart and serial_number <= tend;



	insert into sajet.g_wo_panel_ht
		(select *
		 from   sajet.g_wo_panel
		 where  work_order = two and panel_no not in (select panel_no from sajet.g_sn_status where work_order = two));

	delete from sajet.g_wo_panel
	where  work_order = two and panel_no not in (select panel_no from sajet.g_sn_status where work_order = two);
	tres := 'OK';
exception
	when others then
		tres := 'Insert Fail.';
end;
/

