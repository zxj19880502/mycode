create procedure       csbg_wo_material(trev in varchar2
												  ,two  in varchar2
												  ,temp in varchar2
												  ,tres out varchar2) as
	c_lotno  varchar2(50);
	c_partno varchar2(50);
	c_partid number;
	c_cnt    number;
	cempid   number;
begin
	--刷入值是否為PART NO + WYMD 
	c_partno := substr(trev, 1, length(trev) - 4);
	c_lotno  := substr(trev, length(trev) - 3, 4);
	begin
		select part_id into c_partid from sajet.sys_part where part_no = c_partno and rownum = 1;
	exception
		when others then
			--刷入值是否為WO + PROESSID (LOT NO 填WO) 
			c_lotno := substr(trev, 1, length(trev) - 6);
			begin
				select part_id into c_partid from sajet.g_wo_base where work_order = c_lotno and rownum = 1;
			exception
				when others then
					tres := 'NO KPNO';
					goto endp;
			end;
	end;
	sajet.sj_get_empid(temp, cempid);
	begin
		select item_part_id
		into   c_partid
		from   sajet.g_wo_bom
		where  work_order = two and item_part_id = c_partid and rownum = 1;
	exception
		when others then
			tres := 'NOT IN BOM';
			goto endp;
	end;
	select count(*)
	into   c_cnt
	from   sajet.g_wo_material
	where  work_order = two and part_id = c_partid and lot_no = c_lotno and rownum = 1;
	if c_cnt = 0 then
		insert into sajet.g_wo_material
			(work_order, part_id, lot_no, update_time, update_userid)
		values
			(two, c_partid, c_lotno, sysdate, cempid);
	end if;
	tres := 'OK';
	<<endp>>
	null;
exception
	when others then
		tres := 'CSBG_WO_MATERIAL ERR';
end;


/

