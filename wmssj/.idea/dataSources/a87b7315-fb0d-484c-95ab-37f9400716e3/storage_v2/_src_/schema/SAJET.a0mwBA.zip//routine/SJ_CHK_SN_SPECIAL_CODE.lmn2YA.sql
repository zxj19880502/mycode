create FUNCTION SJ_CHK_SN_SPECIAL_CODE(V_SN   IN VARCHAR2,
                                                  V_CODE IN VARCHAR2)
  RETURN VARCHAR2 IS
  TRES VARCHAR2(5);
  TSTR VARCHAR2(50);
BEGIN
  TRES := 'NG';
  IF LENGTH(V_SN) = LENGTH(V_CODE) THEN
    SELECT REGEXP_SUBSTR(V_SN,
                         REPLACE(REPLACE(V_CODE, '%', '.'),
                                 '*',
                                 '[[:alnum:]]'))
      INTO TSTR
      FROM DUAL;
    IF TSTR IS NOT NULL THEN
      TRES := 'OK';
    END IF;
  END IF;
  RETURN TRES;
END;


/

