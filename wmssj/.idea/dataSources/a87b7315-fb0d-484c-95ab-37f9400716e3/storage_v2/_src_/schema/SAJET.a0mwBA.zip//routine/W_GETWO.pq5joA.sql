create FUNCTION W_GETWO (sValue IN VARCHAR2)
   RETURN VARCHAR2
IS
c_wo varchar2(25);
BEGIN
    select work_order into c_wo from sajet.g_wo_base
    where work_order=sValue;

    return c_wo;
exception
  when others then
    return 'NA';
END W_GETWO;
/

