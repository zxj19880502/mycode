create procedure       csbg_chk_shipping_out(trev       in varchar2
													   ,tcontainer in varchar2
													   ,tres       out varchar2) is
	ccnt       number;
	ccontainer varchar2(25);
	cvehno     varchar2(25);
begin
	select count(*)
	into   ccnt
	from   sajet.g_shipping_sn
	where  (container = tcontainer or vehicle_no = tcontainer) and (pallet_no = trev or carton_no = trev) and
		   rownum = 1;
	if ccnt = 0 then
		begin
			select container, vehicle_no
			into   ccontainer, cvehno
			from   sajet.g_shipping_sn
			where  (pallet_no = trev or carton_no = trev) and rownum = 1;
			tres := 'Shipping Error-' || ccontainer || '(' || cvehno || ')';
		exception
			when others then
				tres := 'Pallet (Carton) Error!!';
		end;
	else
		tres := 'OK';
	end if;
exception
	when others then
		tres := 'CSBG_CHK_SHIPPING_OUT error';
end;


/

