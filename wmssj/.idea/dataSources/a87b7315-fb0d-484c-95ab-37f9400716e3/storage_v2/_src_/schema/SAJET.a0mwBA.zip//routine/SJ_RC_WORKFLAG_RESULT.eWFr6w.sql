create function       
       SJ_RC_WORKFLAG_RESULT(svalue in varchar2) return varchar2 is
str varchar2(30); s number; i number;
begin
  if svalue = '0' then
    str := 'Initial';
  elsif svalue = '8' then
    str := 'Scrap';
  elsif svalue = '2' then
    str := 'Release';
  elsif svalue = '3' then
    str := 'WIP';
  elsif svalue = '4' then
    str := 'Hold';
  elsif svalue ='5' then
    str :='Cancel';
  elsif svalue = '6' then
    str := 'Close';
  elsif svalue = '9' then
    str := 'Break';
  elsif svalue = 'N/A' then
    str := 'N/A';
  else
    str := 'Unknown';
  end if;
  return str;
end;


/

