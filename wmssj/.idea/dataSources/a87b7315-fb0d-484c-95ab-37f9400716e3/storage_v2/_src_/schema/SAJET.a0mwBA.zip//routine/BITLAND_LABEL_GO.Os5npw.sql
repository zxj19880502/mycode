create PROCEDURE       BITLAND_LABEL_GO(TSN in varchar2,TTREMINALID in varchar2,TEMPNO in varchar2,TRES out varchar2)IS
nextprocess varchar2(30);
empid number;
--sncount number;
psn varchar2(80);
BEGIN
  TRES:='OK';
  nextprocess:='N/A';
  --sncount:=0;
  if TSN is null then
    TRES:='sn is null';
    elsif TTREMINALID is null then
    TRES:='Terminal ID is null';
    elsif TEMPNO is  null then
    TRES:='Emp no is null';
  end if;
  sajet.Sj_Get_Empid(TEMPNO,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMPNO||')';
    end if;
   /* select count(*) into sncount from sajet.g_sn_status ss where ss.serial_number=TSN;
    if sncount=0 then
      TRES:='No this sn('||TSN||') record';
    end if;*/
    sajet.sj_ckrt_sn_psn(TSN,TRES,psn);--？？sn？？？？
    if TRES!='OK'then
      return;
    end if;
      if TRES='OK' then
        sajet.sj_transfer2(TTREMINALID,TSN,'N/A',sysdate,TEMPNO,TRES,nextprocess);
        if TRES='OK' then
           commit;
        else
           rollback;
        end if;
      end if;
exception
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

