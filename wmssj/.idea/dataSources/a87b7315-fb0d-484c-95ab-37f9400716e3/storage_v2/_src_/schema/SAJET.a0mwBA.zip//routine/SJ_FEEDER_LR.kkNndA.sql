create FUNCTION       Sj_Feeder_Lr(svalue IN VARCHAR2) RETURN VARCHAR2 IS
str VARCHAR2(16);
BEGIN
  IF svalue = '0' THEN
    str := 'S';
  ELSIF svalue = '1' THEN
    str := 'L';
  ELSIF svalue = '2' THEN
    str := 'R';
  ELSE
    str := 'Unknown';
  END IF;
  RETURN str;
END;


/

