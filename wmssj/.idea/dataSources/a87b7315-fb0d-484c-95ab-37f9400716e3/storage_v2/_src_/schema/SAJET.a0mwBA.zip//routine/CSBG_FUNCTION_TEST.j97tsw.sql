create procedure csbg_function_test(trev      in varchar2
													,tres      out varchar2
													,ttoolres  out varchar2
													,tnextproc out varchar2) is
	istart        number;
	iend          number;
	inum          number;
	c_data        varchar2(50);
	c_version     varchar2(50);
	c_line        varchar2(8);
	c_terminal    varchar2(25);
	c_emp         varchar2(50);
	c_kpsn        varchar2(25);
	c_mac         varchar2(15);
	c_testtime    date;
	c_defect      varchar2(50);
	c_terminal_id number;
	cempid        number;
	c_sn          varchar2(100);
begin
	--拆碼讀取收到資料
	--格式:VERSION;LINE;TERMINAL(前五碼是line);EMP NO;KPSN;MAC;TEST TIME;DEFECT;
	inum       := 1;
	istart     := 1;
	c_version  := 'N/A';
	c_line     := 'N/A';
	c_terminal := 'N/A';
	c_emp      := 'N/A';
	c_kpsn     := 'N/A';
	c_mac      := 'N/A';
	c_testtime := sysdate;
	c_defect   := 'N/A';
	for inum in 1 .. 8 loop
		iend := instr(trev, ';', 1, inum);
		if inum < 8 then
			c_data := trim(substr(trev, istart, iend - istart));
		else
			c_data := trim(substr(trev, istart, length(trev) - istart + 1)); --DEFECT多筆
		end if;
		if (c_data is not null) then
			if inum = 1 then
				c_version := c_data;
			elsif inum = 2 then
				c_line := c_data;
			elsif inum = 3 then
				c_terminal := c_data;
			elsif inum = 4 then
				c_emp := c_data;
			elsif inum = 5 then
				c_kpsn := c_data;
			elsif inum = 6 then
				c_mac := c_data;
			elsif inum = 7 then
				c_testtime := to_date(c_data, 'HH24:MI:SS MM-DD-YYYY');
			elsif inum = 8 then
				c_defect := c_data;
			end if;
		end if;
		istart := iend + 1;
	end loop;
	--TERMINAL中前5 碼是LINE
	c_line     := substr(c_terminal, 1, 5);
	c_terminal := substr(c_terminal, 6, length(c_terminal));
	sajet.sj_get_empid(c_emp, cempid);
	--找序號
	begin
		select serial_number into c_sn from sajet.g_sn_keyparts where item_part_sn = c_kpsn;
	exception
		when others then
			tres := 'KPSN ERROR';
			goto endp;
	end;
	sajet.sj_ckrt_sn(c_sn, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	c_terminal_id := c_terminal; --文字檔傳過來的是Terminal ID
	--找TERMINAL ID
	/*
      BEGIN
        SELECT TERMINAL_ID INTO C_TERMINAL_ID
        FROM SAJET.SYS_TERMINAL
        WHERE TERMINAL_NAME = C_TERMINAL;
      EXCEPTION
        WHEN OTHERS THEN
          TRES := 'TERMINAL ERROR';
        GOTO ENDP;
      END;
    */
	--CHECK ROUTE
	sajet.sj_ckrt_route(c_terminal_id, c_sn, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	--檢查治具
	csbg_chk_tooling(c_sn, c_terminal_id, tres, ttoolres);
	if tres <> 'OK' then
		goto endp;
	end if;
	--UPDATE 治具次數及測試序號
	sajet.csbg_sn_tooling(c_sn, c_terminal_id, tres);
	if tres <> 'OK' then
		rollback;
		goto endp;
	end if;
	--過站
	sajet.csbg_function_go(c_terminal_id, c_sn, c_testtime, c_emp, c_defect, tres, tnextproc);
	if tres <> 'OK' then
		rollback;
		goto endp;
	end if;
	if c_mac <> 'N/A' then
		--INSERT MAC TABLE
		insert into sajet.g_sn_mac_map
			(serial_number, mac_id, create_time, emp_id)
		values
			(c_sn, c_mac, c_testtime, cempid);
	end if;
	commit;
	if ttoolres <> 'N/A' then
		tres := tres || '-' || ttoolres;
	end if;
	<<endp>>
	null;
exception
	when others then
		tres := 'CSBG_FUNCTION_TEST ERROR! ';
		rollback;
end;


/

