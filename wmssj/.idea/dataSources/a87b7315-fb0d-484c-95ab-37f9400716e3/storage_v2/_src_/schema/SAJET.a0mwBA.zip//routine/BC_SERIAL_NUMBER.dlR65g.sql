create PROCEDURE       bc_serial_number(two in varchar2, TVALUE in varchar2,
  TQTY in number, tempid in number, tres out varchar2) is
tmodel sajet.g_wo_base.part_id%type;
troute sajet.g_wo_base.route_id%type;
tversion sajet.g_wo_base.version%type;
sn sajet.g_sn_status.serial_number%type; i number;
begin
  select nvl(PART_ID,0), nvl(ROUTE_ID,0), Version into tmodel, troute, tversion
    from sajet.g_wo_base where work_order = two and rownum = 1;
  for i in 1..TQTY loop
    sn := TVALUE || Translate(lpad(i, 2),' ','0');
    insert Into SAJET.G_SN_STATUS
     (WORK_ORDER,SERIAL_NUMBER,PART_ID,ROUTE_ID,Version,EMP_ID,PANEL_NO)
       values(two, sn, tmodel, troute, tversion, tempid, TVALUE);
  end loop;
  tres := 'OK';
exception
   when others then
    tres := 'Insert Fail.';
end;


/

