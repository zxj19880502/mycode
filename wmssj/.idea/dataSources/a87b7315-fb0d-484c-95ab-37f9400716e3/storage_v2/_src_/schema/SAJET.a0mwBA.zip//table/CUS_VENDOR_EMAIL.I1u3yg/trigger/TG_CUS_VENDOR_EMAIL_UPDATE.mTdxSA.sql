create trigger TG_CUS_VENDOR_EMAIL_UPDATE
  before update
  on CUS_VENDOR_EMAIL
  for each row
declare
	-- local variables here
begin
	select replace(:new.mail_addr, ',', ';') into :new.mail_addr from dual;
end tg_cus_vendor_email_update;


/

