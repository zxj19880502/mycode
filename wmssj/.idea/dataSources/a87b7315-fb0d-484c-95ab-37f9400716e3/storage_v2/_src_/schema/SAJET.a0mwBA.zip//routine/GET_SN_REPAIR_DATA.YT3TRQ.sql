create function       
                                     GET_SN_REPAIR_DATA(TRECID in varchar2,TREASONID IN VARCHAR2
                   ,TTABLENAME IN VARCHAR2) return varchar2
is
str varchar2(1000); s number; i number;
TYPE CURSOR_TYPE is ref cursor;
DATA_CURSOR CURSOR_TYPE;
V_SQL varchar2(1000);
s_Data varchar2(1000);

--CURSOR DATA_CURSOR IS
  /*SELECT NVL(TTABLENAME,'N/A') TTABLENAME
    FROM SAJET.G_SN_REPAIR_LOCATION A
        ,SAJET.SYS_PART B
   WHERE RECID = TRECID AND REASON_ID = TREASONID
     AND A.ITEM_ID = B.PART_ID(+);*/
   --EXECUTE IMMEDIATE  C_SEQ;
--DATA_RECORD DATA_CURSOR%ROWTYPE;
begin
  V_SQL := ' SELECT NVL('||TTABLENAME||',''N/A'') '||TTABLENAME||' '||
      ' FROM SAJET.G_SN_REPAIR_LOCATION A '||
          ' ,SAJET.SYS_PART B '||
     ' WHERE RECID = '''||TRECID||''' AND REASON_ID = '''||TREASONID||''' '||
       ' AND A.ITEM_ID = B.PART_ID(+)' ;

    IF NOT DATA_CURSOR%ISOPEN THEN
      OPEN DATA_CURSOR for V_SQL;
    END IF;

    LOOP
       FETCH DATA_CURSOR INTO s_Data;
       EXIT WHEN DATA_CURSOR%NOTFOUND OR DATA_CURSOR%NOTFOUND IS NULL;
       --IF s_Data <> 'N/A' THEN
          str := str || s_Data ||',';
       --END IF;
       /*FETCH DATA_CURSOR INTO DATA_RECORD;
       EXIT WHEN DATA_CURSOR%NOTFOUND OR  DATA_CURSOR%NOTFOUND IS NULL;
       IF DATA_RECORD.TTABLENAME <>'N/A' THEN
           str := str || DATA_RECORD.TTABLENAME||',';
       END IF;*/
    END LOOP;
    CLOSE DATA_CURSOR;
    --dbms_output.put_line(str);
    str := SUBSTR(STR,1,LENGTH(STR)-1);
  return str;
end;


/

