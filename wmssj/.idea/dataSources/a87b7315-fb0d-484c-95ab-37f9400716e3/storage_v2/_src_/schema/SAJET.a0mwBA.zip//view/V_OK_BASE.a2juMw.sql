create view V_OK_BASE as
select a.wip_out_time,a.serial_number,a.sizespec
from sajet.base_sn_travel a
where a.process_id = '100026'
and a.work_flag = 0
and a.current_status in (0,2)


/

