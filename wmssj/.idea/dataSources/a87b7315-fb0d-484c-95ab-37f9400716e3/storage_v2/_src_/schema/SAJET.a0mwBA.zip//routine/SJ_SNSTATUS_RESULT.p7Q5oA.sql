create function       
       SJ_SNStatus_Result(svalue in varchar2) return varchar2 is
str varchar2(100); s number; i number;
begin
  if svalue = '0' then
    str := 'Good';
  elsif svalue = '1' then
    str := 'Fail';
  elsif svalue = '2' then
    str := 'Fail(Center)-Accept';
  elsif svalue = '3' then
    str := 'Fail(Center)-Repair';
  elsif svalue = '4' then
    str := 'Good(Center)-Finish';
  elsif svalue = '7' then
    str := 'Defect Confirm';

  elsif svalue='A' then
     str :='Fail(KP)';
  elsif svalue='B' then
     str :='Good(KP)';
  else
    str := '';
  end if;
  return str;
end;


/

