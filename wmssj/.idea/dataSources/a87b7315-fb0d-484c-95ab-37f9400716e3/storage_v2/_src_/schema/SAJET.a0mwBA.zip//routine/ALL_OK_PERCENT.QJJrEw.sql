create function ALL_ok_percent(Sdate in varchar2,ssizespec in varchar2) return varchar2 is
  Result varchar2(10);
  x_count number;
  y_count number;
begin
   x_count := 0;
  y_count := 0;
  result:='0';
  select count(t.SERIAL_NUMBER)
    into x_count
    from sajet.v_sn_travel_simple t,sajet.g_wo_base a
   where t.PROCESS_ID =100026
     and t.output_date = Sdate and t.WORK_ORDER=a.work_order and a.wo_type<>'客返工单'
     and t.CURRENT_STATUS in('0','2') and t.sizespec=ssizespec;
     
   if x_count=0 then 
     Result:='0%';
   ELSE
     select count(t.SERIAL_NUMBER)
    into y_count
    from sajet.v_sn_travel_simple t,sajet.g_wo_base a
   where t.output_date = Sdate and t.CURRENT_STATUS='1' and t.sizespec=ssizespec and t.WORK_ORDER=a.work_order and a.wo_type<>'客返工单' ; 
   Result:=to_char(round((x_count/(x_count+y_count))*100,2))||'%';
   end if;
  return(Result);
end ALL_ok_percent;


/

