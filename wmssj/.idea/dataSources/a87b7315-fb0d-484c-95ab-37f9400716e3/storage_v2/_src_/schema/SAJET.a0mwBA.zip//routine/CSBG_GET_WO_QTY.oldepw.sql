create procedure       csbg_get_wo_qty(trev in varchar2
												 ,tres out varchar2) is
	cinput number;
begin
	select input_qty into cinput from sajet.g_wo_base where work_order = trev and rownum = 1;
	tres := 'OK -WO INPUT QTY:' || cinput;
exception
	when others then
		tres := 'CSBG_GET_WO_QTY error';
end;


/

