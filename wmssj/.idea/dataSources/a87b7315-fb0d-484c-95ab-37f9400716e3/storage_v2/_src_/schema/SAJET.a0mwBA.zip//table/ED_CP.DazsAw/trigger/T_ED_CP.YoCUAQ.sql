create trigger T_ED_CP
  before insert
  on ED_CP
  for each row
declare
	c_partid   number;
	c_partname varchar2(50);
begin
	:new.log := 'OK';
	begin
		begin
			select part_id into c_partid from sajet.sys_part where part_no = :new.cp_part;
		exception
			when others then
				:new.log := '廠內料號不存在';
				return;
		end;
		select cust_part_no
		into   c_partname
		from   sajet.sys_cust_part
		where  cust_part_no = :new.cp_customer_part and part_id = c_partid;
		begin
			update sajet.sys_cust_part
			set    customer_name = :new.cp_customer, update_time = to_date(:new.cp_updatetime, 'yyyy/mm/dd'),
				   update_user = :new.cp_user
			where  cust_part_no = :new.cp_customer_part and part_id = c_partid;
		exception
			when others then
				:new.log := sqlerrm;
				return;
		end;
	exception
		when others then
			begin
				insert into sajet.sys_cust_part
					(part_id, cust_part_no, customer_name, update_time, update_user)
				values
					(c_partid, :new.cp_customer_part, :new.cp_customer, to_date(:new.cp_updatetime, 'yyyy/mm/dd'),
					 :new.cp_user);
			exception
				when others then
					:new.log := sqlerrm;
					return;
			end;
	end;
exception
	when others then
		:new.log := sqlerrm;
end;


/

