create procedure       csbg_remove_assy_kpsn(trev       in varchar2
													   ,tprocessid in number
													   ,tres       out varchar2) as
begin
	--刪除此SN以前組裝紀錄,允許重裝
	delete sajet.g_sn_keyparts where serial_number = trev and process_id = tprocessid;
	tres := 'OK';
exception
	when others then
		tres := 'OK';
end;


/

