create function SJ_REWORK_LOTN(sWO in varchar2) return varchar2 is
sResult varchar2(50);
C_LOTSEQ number;
begin
  select SJ_REWORK_LOTNO.Nextval into C_LOTSEQ from dual;

  sResult:='LOT'||to_char(sysdate,'yyyymmdd')||LPAD(C_LOTSEQ,5,'0');
  return sResult;
end;


/

