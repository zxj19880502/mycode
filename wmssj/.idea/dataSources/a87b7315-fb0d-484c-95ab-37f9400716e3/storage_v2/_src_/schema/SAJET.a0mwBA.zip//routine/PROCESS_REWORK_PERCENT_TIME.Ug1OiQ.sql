create function PROCESS_REWORK_PERCENT_TIME(SDATE1   IN VARCHAR2,
                                                       SDATE2   IN VARCHAR2,
                                                       SPROCESS IN NUMBER)
  return varchar2 is
  Result  varchar2(10);
  x_count number;
  y_count number;
begin
  x_count := 0;
  y_count := 0;
  result  := '0';
  select count(t.SERIAL_NUMBER)
    into x_count
    from sajet.v_sn_travel_simple t
   where t.PROCESS_ID = SPROCESS
     and t.CURRENT_STATUS = '4'
     AND T.output_date >= to_char(SDATE1, 'yyyymmdd')
     AND T.output_date < to_char(SDATE2, 'yyyymmdd');

  if x_count = 0 then
    Result := '0';
  ELSE
    select count(t.SERIAL_NUMBER)
      into y_count
      from sajet.v_sn_travel_simple t
     where t.PROCESS_ID = SPROCESS
       AND T.output_date>= to_char(SDATE1, 'yyyymmdd')
     AND T.output_date < to_char(SDATE2, 'yyyymmdd');
    Result := to_char(round((x_count / y_count) * 100, 2)) || '%';
  end if;

  return(Result);
end PROCESS_REWORK_PERCENT_TIME;


/

