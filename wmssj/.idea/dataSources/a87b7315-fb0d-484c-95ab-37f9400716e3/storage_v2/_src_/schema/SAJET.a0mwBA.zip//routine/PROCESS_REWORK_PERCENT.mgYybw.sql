create function PROCESS_REWORK_PERCENT(Sdate      in varchar2,
                                                  Sprocessid in number,
                                                  Ssizespec in varchar2)
  return varchar2 is
  Result  varchar2(10);
  x_count number;
  y_count number;
begin
  x_count := 0;
  y_count := 0;
  result:='0';
  select count(t.SERIAL_NUMBER)
    into x_count
    from sajet.v_sn_travel_simple t
   where t.PROCESS_ID = Sprocessid
     and t.output_date = Sdate
     and t.CURRENT_STATUS = '4' and t.sizespec=ssizespec;
     
   if x_count=0 then 
     Result:='0%';
   ELSE
     select count(t.SERIAL_NUMBER)
    into y_count
    from sajet.v_sn_travel_simple t
   where t.PROCESS_ID = Sprocessid
     and t.output_date = Sdate and t.sizespec=ssizespec; 
   Result:=to_char(round((x_count/y_count)*100,2))||'%';
   end if;

  return(Result);
end PROCESS_REWORK_PERCENT;


/

