create FUNCTION       WMS_GET_APP_SRC(TTO_Box IN varchar2) RETURN VARCHAR2 IS
SRC_BOX SAJET.WMS_STOCK.BOX_NO%TYPE;
C_INTER SAJET.WMS_STOCK.INTERFACE_TYPE%TYPE;
BEGIN
  select a.from_box into SRC_BOX from sajet.wms_append_track a where  a.to_box=TTO_Box;
  select interface_type into C_INTER from
  (select a.interface_type from sajet.wms_stock_track a
  where a.box_no=SRC_BOX and a.box_qty>0 order by a.update_time) where rownum=1;
  if C_INTER='APPEND' then
    SRC_BOX:=WMS_GET_APP_SRC(SRC_BOX);
  else
    SRC_BOX:=SRC_BOX;
  end if;
  RETURN SRC_BOX;
END;


/

