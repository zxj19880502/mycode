create FUNCTION       WAREHOUSE_TYPE(SVALUE IN VARCHAR2) RETURN VARCHAR2 is
STR VARCHAR2(16);
BEGIN
  IF SVALUE = '0' THEN
    STR := '良品';
  ELSIF SVALUE = '1' THEN
    STR := '不良品';
  ELSIF SVALUE = '2' THEN
    STR := '待判定';
  ELSIF SVALUE = '3' THEN
    STR := 'Sample';
  ELSIF SVALUE = '4' THEN
    STR := '报废';
  ELSE
    STR := 'Unknown';
  END IF;
  RETURN STR;
END;


/

