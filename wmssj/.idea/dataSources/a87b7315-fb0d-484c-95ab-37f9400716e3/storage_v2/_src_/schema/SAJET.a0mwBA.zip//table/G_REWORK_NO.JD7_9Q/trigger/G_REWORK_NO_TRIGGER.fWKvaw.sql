create trigger G_REWORK_NO_TRIGGER
  before insert
  on G_REWORK_NO
  for each row
declare
	c_type    number;
	c_eventid number;
	t_type    varchar2(25);
	c_factory sajet.sys_factory.factory_id%type;
	c_emp     sajet.sys_emp.emp_no%type;
begin
	t_type := 'REWORK'; -- EVENT TYPE:  MI
	begin
		select type_id
		into   c_type
		from   sajet.alarm_type_base
		where  type_name = t_type and enabled = 'Y' and rownum = 1;
		begin
			select factory_id, emp_no
			into   c_factory, c_emp
			from   sajet.sys_emp
			where  emp_id = :new.emp_id and rownum = 1;
			select trim(param_value) || to_char(sysdate, 'Y') || lpad(sajet.s_alarm_code.nextval, 6, 0)
			into   c_eventid
			from   sajet.sys_base
			where  param_name = 'DBID';
			insert into sajet.alarm_event
				(event_id, event_status, type_id, event_level, factory_id, pdline_id, stage_id, process_id, terminal_id,
				 event_desc, record_time)
			values
				(c_eventid, 0, c_type, 1, c_factory, 0, 0, 0, 0,
				 'REWORK_NO: [' || :new.rework_no || ']  EMP_NO: [' || c_emp || ']  ' || :new.condition, sysdate);
		end;
	end;
end;


/

