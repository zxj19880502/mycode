create function f_get_defectcout_alam(cserial_number in varchar2) return varchar2 is
	pragma autonomous_transaction; --自治
	cqty varchar2(10);

begin
	select count(*) into cqty from sajet.g_sn_defect_qty a where a.serial_number = cserial_number;
	update sajet.g_sn_defect_qty a set a.is_alarm = 'OVER' where a.serial_number = cserial_number;
	commit;
	<<endp>>
	return cqty;
exception
	when others then
		return '';
end;
/

