create view V_BASE_SN_TRAVEL_CP as
select a.sizespec,a.wip_out_time
from sajet.base_sn_travel a
where a.process_id='100026' and
a.current_status in (0,1,2,4)


/

