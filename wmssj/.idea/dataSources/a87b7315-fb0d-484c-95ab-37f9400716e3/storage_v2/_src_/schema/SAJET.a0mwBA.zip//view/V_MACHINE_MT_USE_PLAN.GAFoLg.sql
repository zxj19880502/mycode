create view V_MACHINE_MT_USE_PLAN as
select a.machine_id
      ,nvl(c.plan_id,d.plan_id) plan_id
from sajet.sys_machine a
    ,sajet.sys_machine_mt_use_plan c
    ,sajet.sys_machine_mt_use_plan_T d
where a.machine_id = c.machine_id(+)
and a.machine_type_id = d.machine_type_id(+)


/

