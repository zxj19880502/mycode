create trigger T_IOMACHINE_SETUP
  before insert
  on G_IOMACHINE_STEUP
  for each row
declare
  -- local variables here
begin
  :NEW.ID:=SAJET.SEQ_CONVEYER_SETUP.NEXTVAL;
end T_IOMACHINE_SETUP;


/

