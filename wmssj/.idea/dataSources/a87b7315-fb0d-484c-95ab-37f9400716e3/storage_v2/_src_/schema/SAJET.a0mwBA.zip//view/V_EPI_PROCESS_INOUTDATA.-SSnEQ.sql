create view V_EPI_PROCESS_INOUTDATA as
select INDATA.machine_CODE,INDATA.machine_TYPE ,INDATA.runno,INDATA.current_Inday as current_day,INDATA.process_id ,INDATA.InSheft as Sheft,INDATA.wip_in_Qty,outDATA.win_out_Qty from
(select A.current_Inday,A.process_id ,A.InSheft,sum(A.WIP_IN_QTY) as wip_in_Qty,A.machine_CODE,A.machine_TYPE,runno from (select to_char(t.In_Process_Time - 8.5 / 24, 'yyyy/mm/dd') current_Inday,t.process_id,substr(T.RC_NO,0,3) as machine_CODE,substr(T.RC_NO,0,1) as machine_TYPE,substr(t.rc_no,-1,1) as runno,t.wip_in_qty,case when to_char(t.In_Process_Time, 'hh24mi') between '0830' and '2030' then '白班'
    else '夜班'  end  as InSheft from sajet.g_rc_travel t
   where t.process_id in ('100125','100167','100168') and  t.in_process_time is not null )A group by a.current_Inday,a.process_id,InSheft,machine_CODE,machine_TYPE,runno)INDATA,

   (select A.current_outday,A.process_id ,A.outSheft,sum(A.WIP_out_good_QTY) as win_out_Qty,A.machine_CODE,A.machine_TYPE,runno from (select to_char(t.out_Process_Time - 8.5 / 24, 'yyyy/mm/dd') current_outday,t.process_id,substr(T.RC_NO,0,3) as machine_CODE,substr(T.RC_NO,0,1) as machine_TYPE,substr(t.rc_no,-1,1) as runno,t.wip_out_good_qty,case when to_char(t.out_Process_Time, 'hh24mi') between '0830' and '2030' then '白班'
    else '夜班'  end  as OutSheft from sajet.g_rc_travel t
   where t.process_id in ('100125','100167','100168') and  t.out_process_time is not null )A group by a.current_outday,a.process_id,outSheft,machine_CODE,machine_TYPE,runno)outDATA
   where INDATA.current_Inday=outDATA.current_outday(+)
   and indata.process_id=outdata.process_id(+)
   and indata.InSheft=outdata.outSheft(+)
   AND indata.machine_CODE=outdata.machine_CODE(+)
   AND indata.machine_TYPE=outdata.machine_TYPE(+)
   AND indata.runno=outdata.runno(+)


/

