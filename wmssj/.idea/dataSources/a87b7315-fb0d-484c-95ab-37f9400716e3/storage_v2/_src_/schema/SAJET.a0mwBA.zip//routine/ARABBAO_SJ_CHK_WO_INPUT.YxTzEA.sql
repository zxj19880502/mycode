create procedure       arabbao_sj_chk_wo_input(trev in varchar2
														 ,tres out varchar2) is
	c_status varchar2(1);
	c_wotype varchar2(25);
begin
	select wo_status, wo_type into c_status, c_wotype from sajet.g_wo_base where work_order = trev and rownum = 1;
	if c_status = '0' then
		tres := 'WO INIT';
	elsif c_status = '1' then
		tres := 'WO PREPARE';
		/*ELSIF C_STATUS = '4' THEN
           TRES := 'WO HOLD';
        ELSIF C_STATUS = '5' THEN
           TRES := 'WO CANCEL';
        ELSIF C_STATUS = '6' THEN
           TRES := 'WO COMPLETE';*/
		--ELSIF C_WOTYPE <> '1' THEN
		--   TRES := 'WO TYPE ERR';
	else
		tres := 'OK';
	end if;
exception
	when others then
		tres := 'WO ERR';
end;


/

