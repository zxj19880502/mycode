create view V_QC_DEFECT_NEW as
select a.SERIAL_NUMBER,m.MODEL_NAME,m.DEFECT_CODE,m.EMP_NAME,
       m.QC_TIME,m.ROW_FLAG,m.FLAG,m.START_TIME from
sajet.base_sn_travel a,
(SELECT MODEL_NAME,
       SERIAL_NUMBER,
       DEFECT_CODE,
       EMP_NAME,
       QC_TIME， ROW_FLAG，FLAG,START_TIME
  FROM (SELECT D.MODEL_NAME,
               A.SERIAL_NUMBER,
               B.DEFECT_CODE,
               A.REC_TIME,
               F.EMP_NAME,
               E.QC_LOTNO,
               ROW_NUMBER() OVER(PARTITION BY A.LOCATION ORDER BY A.REC_TIME ASC) AS ROW_FLAG,
               G.FLAG,
               TO_CHAR(E.START_TIME, 'YYYY/MM/DD') QC_TIME,E.START_TIME
          FROM SAJET.G_SN_DEFECT A,
               SAJET.SYS_DEFECT B,
               SAJET.SYS_PART C,
               SAJET.SYS_MODEL D,
               SAJET.G_QC_LOT E,
               SAJET.SYS_EMP F,
               (SELECT SERIAL_NUMBER,
                       QC_LOTNO,START_TIME,
                       ROW_NUMBER() OVER(PARTITION BY SERIAL_NUMBER ORDER BY START_TIME ASC) AS FLAG
                  FROM (SELECT SERIAL_NUMBER, QC_LOTNO, START_TIME
                          FROM (SELECT M.SERIAL_NUMBER,
                                       N.QC_LOTNO,
                                       N.START_TIME
                                  FROM SAJET.G_SN_DEFECT M, SAJET.G_QC_LOT N
                                 WHERE M.LOCATION = N.QC_LOTNO
                                   --AND M.SERIAL_NUMBER = 'GCL6C07170618063'
                                   AND M.PROCESS_ID = 100026
                                 GROUP BY M.SERIAL_NUMBER,
                                          N.QC_LOTNO,
                                          N.START_TIME))) G
         WHERE A.DEFECT_ID = B.DEFECT_ID
           AND A.PART_ID = C.PART_ID
           AND C.MODEL_ID = D.MODEL_ID
           AND A.PROCESS_ID = 100026
           AND A.PROCESS_ID = E.PROCESS_ID
           AND A.LOCATION = E.QC_LOTNO
           AND E.INSP_EMPID2 = F.EMP_ID
           AND A.SERIAL_NUMBER = G.SERIAL_NUMBER
           AND A.LOCATION = G.QC_LOTNO
           AND E.START_TIME=G.START_TIME
        --AND A.serial_number = 'GCL6C07170618063'
        )
 WHERE ROW_FLAG < 5
   AND FLAG < 5)m
where a.PROCESS_ID=100026 and a.CURRENT_STATUS=4 and a.SERIAL_NUMBER=m.serial_number and
to_char(a.WIP_OUT_TIME,'yyyy-mm-dd')=to_char(m.start_time,'yyyy-mm-dd')


/

