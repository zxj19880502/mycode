create procedure       cs_chk_input(temp in number
											  ,trev in varchar2
											  ,tres out varchar2) is
	cworkdate varchar2(8);
	cworktime number;
	crowid    varchar2(25);
begin
	if temp = trev then
		tres := 'OK';
	else
		tres := 'EMP NG';
	end if;
end;


/

