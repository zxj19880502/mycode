create procedure       csbg_qc_get_lotno(tterminalid in number
												   ,tlotno      out varchar2
												   ,tres        out varchar2) is
begin
	select 'QCLOT' || b.pdline_name || to_char(sysdate, 'YYMMDD') || lpad(sajet.s_qc_code.nextval, 5, '0')
	into   tlotno
	from   sajet.sys_terminal a, sajet.sys_pdline b
	where  a.terminal_id = tterminalid and a.pdline_id = b.pdline_id;
	tres := 'OK';
exception
	when others then
		tres := 'Create QC Lot No Error ';
end;


/

