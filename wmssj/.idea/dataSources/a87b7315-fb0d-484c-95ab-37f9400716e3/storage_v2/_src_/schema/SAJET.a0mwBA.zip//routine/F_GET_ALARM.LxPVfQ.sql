create function f_get_alarm(cevent_id in number) return varchar2 is
	pragma autonomous_transaction; --自治
	cqty varchar2(25);

begin
	cqty := cevent_id;
	update sajet.alarm_event a set a.event_status = to_char(sysdate, 'yymmdd') where a.event_id = cevent_id;
	commit;
	<<endp>>
	return cqty;
exception
	when others then
		return '';
end;
/

