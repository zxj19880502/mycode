create view VV_ZJ_REWORK as
select a.sizespec,a.WIP_OUT_TIME
from sajet.base_sn_travel a,sajet.g_wo_base b,
sajet.v_g_re_log m
where a.process_id='100026' and a.WORK_ORDER=b.work_order and b.wo_type in ('正常工单','内返工单') and
(to_date(m.ti,'yyyy-mm-dd')<to_date(to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd'),'yyyy-mm-dd') or (to_char(a.wip_out_time-8.5/24,'yyyy-mm-dd')=m.ti and m.qty>1))
and a.current_status in (0,1,2,4) and a.SERIAL_NUMBER=m.serial_number


/

