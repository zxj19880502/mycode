create procedure csbg_wo_inputsn2(trev in varchar2
											,two  in varchar2
											,temp in varchar2
											,tres out varchar2) is
	cempid   number;
	cstatus  varchar2(1);
	csn      sajet.g_sn_status.serial_number%type;
	cmodelid number;
	crouteid number;
	ctarget  number;
	ccnt     number;
	ccode    sajet.g_wo_param.parame_value%type;
	cdefault sajet.g_wo_param.parame_value%type;
	cwo      sajet.g_wo_base.work_order%type;
begin
	/*====
       工單投入序號(不由Barcode Center 展序號)
       2005/04/14 CREATE
    ====*/
	sajet.sj_get_empid(temp, cempid);
	select wo_status, part_id, route_id, target_qty
	into   cstatus, cmodelid, crouteid, ctarget
	from   sajet.g_wo_base
	where  work_order = two and rownum = 1;
	begin
		select serial_number into csn from sajet.g_sn_status where serial_number = trev;
		tres := 'SN DUP';
		goto endp;
	exception
		when others then
			tres := 'OK';
	end;
	--檢查此工單數量是否允許再投入SN
	select count(*) into ccnt from sajet.g_sn_status where work_order = two;
	ccnt := ccnt + 1;
	if ccnt > ctarget then
		tres := 'WO FULL !!';
		goto endp;
	end if;


	--檢查是否符合序號規則----BEGIN-----
	if length(trev) <> 16 then
		tres := 'Length Error(16)';
		goto endp;
	end if;

	cwo := substr(trev, 2, length(trev) - 8);
	if cwo <> two then
		tres := 'WO NOT MATCH(' || two || ')';
		goto endp;
	end if;


	/*
     SELECT PARAME_VALUE INTO CCODE FROM SAJET.G_WO_PARAM
     WHERE WORK_ORDER = TWO
     AND MODULE_NAME = 'SERIAL NUMBER RULE'
     AND PARAME_NAME = 'Serial Number Code'
     AND PARAME_ITEM = 'Code';
     SELECT PARAME_VALUE INTO CDEFAULT FROM SAJET.G_WO_PARAM
     WHERE WORK_ORDER = TWO
     AND MODULE_NAME = 'SERIAL NUMBER RULE'
     AND PARAME_NAME = 'Serial Number Code'
     AND PARAME_ITEM = 'Default';
     -- 序號長度
     IF LENGTH(TREV) <> LENGTH(CCODE) THEN
       TRES:='SN LENGTH ERR!!';
       GOTO ENDP;
     END IF;
     --固定?
     FOR I IN 1 .. LENGTH(CCODE) LOOP
       IF (SUBSTR(CCODE,I,1)='A') OR (SUBSTR(CCODE,I,1)='C') OR (SUBSTR(CCODE,I,1)='L') THEN
         IF SUBSTR(TREV,I,1) <> SUBSTR(CDEFAULT,I,1) THEN
           TRES:='SN RULE NOT MATCH!!';
           GOTO ENDP;
         END IF;
       END IF;
     END LOOP;
     --------------------------END-------
    
    */
	--INSERT SN_STATUS
	insert into sajet.g_sn_status
		(work_order, part_id, serial_number, route_id, emp_id, model_id)
	values
		(two, cmodelid, trev, crouteid, cempid, cmodelid);
	tres := 'OK';
	<<endp>>
	null;
exception
	when others then
		tres := 'CSBG_WO_INPUTSN ERR';
		rollback;
end;
/

