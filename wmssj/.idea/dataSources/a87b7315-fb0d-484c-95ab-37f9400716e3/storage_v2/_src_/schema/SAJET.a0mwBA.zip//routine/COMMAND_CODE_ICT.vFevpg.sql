create PROCEDURE Command_Code_Ict(tsajet1     IN VARCHAR2,
                                                  tsajet2     IN VARCHAR2,
                                                  tsajet3     IN VARCHAR2,
                                                  tsajet4     IN VARCHAR2,
                                                  tsajet4ton  IN VARCHAR2,
                                                  tsajet5ton  IN VARCHAR2,
                                                  tlineid     IN NUMBER,
                                                  tstageid    IN NUMBER,
                                                  tprocessid  IN NUMBER,
                                                  tterminalid IN NUMBER,
                                                  tnow        IN DATE,
                                                  trev        IN VARCHAR2,
                                                  tres        OUT VARCHAR2,
                                                  tnextproc   OUT VARCHAR2) IS
  c_head   NUMBER;
  cmd      NUMBER;
  c_PANEL  VARCHAR2(25);
  SSNN     VARCHAR2(100);
  c_Number NUMBER;
  e_Number NUMBER;
  c_Start  NUMBER;
  e_Start  NUMBER;
  c_End    NUMBER;
  e_End    NUMBER;
  f_Start  NUMBER;
  f_Number NUMBER;
  f_End    NUMBER;
  i_error  NUMBER; --???值是第几?板的??
  --e_Error    NUMBER;
  e_Error     NUMBER;
  c_Temp      VARCHAR2(4000);
  e_Temp      VARCHAR2(4000);
  f_Temp      VARCHAR2(4000);
  c_Item      Sajet.SYS_SPC.SPC_ITEM%TYPE;
  c_Value     Sajet.G_SPC.SPC_VALUE%TYPE;
  c_Defect    SAJET.SYS_DEFECT.DEFECT_CODE%TYPE;
  mc_Defect   SAJET.SYS_DEFECT.DEFECT_CODE%TYPE;
  V_SPC_ID    SAJET.SYS_SPC.SPC_ID%TYPE;
  V_RECID     SAJET.TEMP_API_SN.RECID%TYPE;
  v_count     number;
  v_spcValue  VARCHAR(100);
  v_empID     number;
  v_spcRESULT number;
  v_wo        sajet.g_sn_status.work_order%type;
  v_part      sajet.g_sn_status.part_id%type;
BEGIN
  tres := 'Fail,Command fail';
  --c_head := INSTR (trev, ',', 1, 1);
  cmd := TO_NUMBER(tsajet1);

  IF cmd = 1 THEN
    SAJET.Sj_Cksys_Emp(tsajet2, tres);

    IF TRES = 'OK' THEN
      TRES := 'OK;OK';
    ELSE
      TRES := 'NG;[EC201] EMP NO NG';
    END IF;
  ELSIF cmd = 2 THEN
    SAJET.Sj_Ckrt_Sn(tsajet2, tres);
    IF tsajet3 = '' THEN
      SAJET.SJ_CKRT_ODC_VERSION(tsajet2, tsajet3, TRES);
    END IF;
    IF Tres = 'OK' THEN
      SAJET.Sj_Ckrt_Route(TTerminalid, tsajet2, tres);

      IF TRES = 'OK' THEN
        TRES := 'OK;OK';
      ELSE
        TRES := 'NG;[EC999] Route NG:' || TRES;
      END IF;
    END IF;

  ELSIF cmd = 3 THEN
    SAJET.Sj_Cksys_Emp(tsajet2, tres);

    IF SUBSTR(TRES, 1, 2) = 'OK' THEN
      -- CHECK EMP OK
      SAJET.Sj_Ckrt_Sn(tsajet3, tres);
    ELSE
      -- CHECK EMP NG
      TRES := 'NG;[EC201] EMP NO NG';
    END IF;

    IF SUBSTR(TRES, 1, 2) = 'OK' THEN
      -- CHECK SN OK
      SAJET.Sj_Ckrt_Route(TTerminalID, tsajet3, tres);

      IF SUBSTR(TRES, 1, 2) <> 'OK' THEN
        -- CHECK ROUTE NG
        TRES := 'NG;[EC999] Route NG:' || TRES || '';
      END IF;
    ELSE
      -- CHECK SN NG
      TRES := 'NG;[EC202] SN NG';
    END IF;

    IF SUBSTR(tres, 1, 2) = 'OK' THEN
      -- CHECK ROUTE OK
      IF tsajet4 = 'OK' THEN
        SAJET.Sj_Go(TTerminalID, tsajet3, tnow, tres, tsajet2);

        IF SUBSTR(TRES, 1, 2) = 'OK' THEN
          TRES := 'OK;OK';
        ELSE
          TRES := 'NG;[EC101] CALL DBA';
        END IF;
      ELSIF tsajet4 = 'NG' THEN
        --            c_Temp := tsajet5ton || ';';
        c_Temp   := tsajet5ton;
        c_Number := 1;
        c_Start  := 1;

        LOOP
          c_End := INSTR(c_Temp, ';', 1, c_Number);
          EXIT WHEN c_End = 0;
          c_Defect := Trim(SUBSTR(c_Temp, c_Start, c_End - c_Start));
          /* IF UPPER(c_Defect)='EOPEN'THEN
              mc_Defect:='ICT002';
           END IF;
           IF UPPER(c_Defect)='ESHORT'THEN
              mc_Defect:='ICT003';
           END IF;
           IF UPPER(c_Defect)='ECOMP'THEN
              mc_Defect:='ICT004';
           END IF;
          \* if UPPER(c_Defect)='ECD'THEN
              mc_Defect:='ICT005';
           end if;*\
           IF UPPER(c_Defect)='EICOPEN'THEN
              mc_Defect:='ICT001';
           END IF;
           IF UPPER(c_Defect)='EONPOWER'THEN
              mc_Defect:='ICT007';
           END IF;*/
          /* if UPPER(c_Defect)='ESOCKET'THEN
             mc_Defect:='ICT009';
          end if;  */

          Sajet.Sj_Cksys_Defect(c_Defect, Tres);
          IF SUBSTR(TRES, 1, 2) <> 'OK' THEN
            TRES := 'NG;[EC203] ERROR CODE NG;' || ' [' || c_Defect || ']';
            EXIT;
          END IF;

          -- Sajet.Sj_Nogo(TTerminalID, tsajet3,c_Defect,tnow,tres,tnextproc,tsajet2);

          sj_repair_input_record(tterminalid,tsajet3,c_Defect,tsajet2);
          sj_repair_input_record_count(tterminalid,tsajet3,c_Defect, tsajet2);--add by joseph 20151117 增加??procdure
          select count
            into v_count
            from sajet.g_sn_defect_count
           where serial_number = tsajet3
             and terminal_id = TTerminalID;
          if v_count >= 3 then
            Sajet.Sj_Nogo(TTerminalID,
                          tsajet3,
                          c_Defect,
                          tnow,
                          tres,
                          tnextproc,
                          tsajet2);
          end if;
          IF SUBSTR(TRES, 1, 2) <> 'OK' THEN
            TRES := 'NG;[EC101] CALL DBA;';
            EXIT;
          END IF;
          c_Defect := '';

          c_Start  := c_End + 1;
          c_Number := c_Number + 1;
        END LOOP;

        IF SUBSTR(Tres, 1, 2) = 'OK' THEN
          TRES := 'OK;OK;';
          COMMIT;
        ELSE
          ROLLBACK;
        END IF;
      ELSE
        TRES := 'NG;[EC101] RESULT NG;';
      END IF;

    END IF;

  ELSIF cmd = 4 THEN
    TRES := 'OK';
    BEGIN
      SELECT PANEL_NO
        INTO c_PANEL
        FROM SAJET.G_SN_STATUS
       WHERE SERIAL_NUMBER = tsajet2
         AND ROWNUM = 1;

    exception
      when others then
        tres := 'NG;NO SN;';
    end;

    IF tsajet3 = '' THEN
      SAJET.SJ_CKRT_ODC_VERSION(tsajet2, tsajet3, TRES);
    END IF;

    IF TRES = 'OK' THEN
      declare
        cursor SN is
          select SERIAL_NUMBER
            from SAJET.G_SN_STATUS
           where PANEL_NO = c_PANEL;
        SNN SN%ROWTYPE;
      BEGIN
        FOR SNN IN SN LOOP
          exit when SN%notfound;
          SAJET.Sj_Ckrt_Sn(SNN.SERIAL_NUMBER, tres);
          IF Tres = 'OK' THEN
            SAJET.Sj_Ckrt_Route(TTerminalid, SNN.SERIAL_NUMBER, tres);

            IF TRES = 'OK' THEN
              TRES := 'OK;OK;';
            ELSE
              TRES := 'NG;' || TRES || ';';
              goto endcmd4;
            END IF;
          ELSE
            TRES := 'NG;[EC202] SN NG;';
          end if;
        END LOOP;

        <<endcmd4>>
        null;

      END;

    END IF;

  ELSIF cmd = 5 THEN
    SAJET.Sj_Cksys_Emp(tsajet2, tres);
    IF tres = 'OK' THEN
      SAJET.Sj_Ckrt_Sn(tsajet3, tres);
    END IF;

    IF tres = 'OK' THEN
      SELECT SPC_ID
        INTO V_SPC_ID
        FROM SAJET.SYS_SPC
       WHERE SPC_ITEM = 'FCT TEST'
         AND ROWNUM = 1;
      sajet.sj_get_empid(tsajet2, v_empID);
      f_Start    := 2;
      f_End      := 0;
      f_Number   := 1;
      f_end      := INSTR(tsajet5ton, ',', f_Start, f_Number);
      v_spcValue := Trim(SUBSTR(tsajet5ton, f_Start, f_End - f_Start));
      if tsajet4 = 'OK' then
        v_spcRESULT := 0;

      else
        v_spcRESULT := 1;
      end if;

      select t.work_order, t.part_id
        into v_wo, v_part
        from sajet.g_sn_status t
       where t.serial_number = tsajet3
         and rownum = 1;

      INSERT INTO SAJET.G_SPC
        (SPC_ID,
         SERIAL_NUMBER,
         UPDATE_TIME,
         SPC_VALUE,
         PDLINE_ID,
         STAGE_ID,
         PROCESS_ID,
         TERMINAL_ID,
         EMP_ID,
         SPC_RESULT,
         WORK_ORDER,
         PART_ID)
      VALUES
        (V_SPC_ID,
         tsajet3,
         SYSDATE,
         nvl(v_spcValue, 0),
         tlineid,
         tstageid,
         tprocessid,
         tterminalid,
         v_empID,
         v_spcRESULT,
         v_wo,
         v_part);
      /*INSERT INTO SAJET.G_SPC(SPC_ID,SERIAL_NUMBER,UPDATE_TIME,WORK_ORDER,PDLINE_ID,STAGE_ID,PROCESS_ID,TERMINAL_ID,EMP_ID,SPC_RESULT)
      VALUES (V_SPC_ID,tsajet3,SYSDATE,v_spcValue,tlineid,tstageid,tprocessid,tterminalid,v_empID,v_spcRESULT);*/
      tres := 'OK;OK;';
    END IF;

  ELSIF cmd = 6 THEN

    TRES := 'OK';

    SAJET.Sj_Cksys_Emp(tsajet2, tres);
    BEGIN
      SELECT PANEL_NO
        INTO c_PANEL
        FROM SAJET.G_SN_STATUS
       WHERE SERIAL_NUMBER = tsajet3
         AND ROWNUM = 1;

      SAJET.SJ_GET_MAXID('RECID', 'SAJET.TEMP_API_SN', 6, TRES, V_RECID);

      IF SUBSTR(tres, 1, 2) = 'OK' THEN
        INSERT INTO SAJET.TEMP_API_SN
          SELECT V_RECID, T.SERIAL_NUMBER, 'OK'
            FROM SAJET.G_SN_STATUS T
           WHERE T.PANEL_NO = c_PANEL;
      END IF;

    exception
      when others then
        tres := 'NG;NO SN;';
    end;

    IF SUBSTR(tres, 1, 2) = 'OK' THEN

      declare
        cursor SN is
          select SERIAL_NUMBER
            from SAJET.G_SN_STATUS
           where PANEL_NO = c_PANEL;
        SNN SN%ROWTYPE;
        --NN %ROWTYPE;
        --TT SN%ROWTYPE;

      begin

        FOR SNN IN SN LOOP
          exit when SN%notfound;
          IF SUBSTR(TRES, 1, 2) = 'OK' THEN
            -- CHECK EMP OK
            SAJET.Sj_Ckrt_Sn(SNN.SERIAL_NUMBER, tres);
          ELSE
            -- CHECK EMP NG
            TRES := 'NG;[EC201] EMP NO NG;';
          END IF;

          IF SUBSTR(TRES, 1, 2) = 'OK' THEN
            -- CHECK SN OK
            SAJET.Sj_Ckrt_Route(TTerminalID, SNN.SERIAL_NUMBER, tres);

            IF SUBSTR(TRES, 1, 2) <> 'OK' THEN
              -- CHECK ROUTE NG
              TRES := 'NG;[EC999] Route NG:' || TRES || ';';
              goto endcmd6;
            END IF;
          ELSE
            -- CHECK SN NG
            TRES := 'NG;[EC202] SN NG;';
          END IF;

          IF SUBSTR(tres, 1, 2) = 'NG' THEN
            goto endcmd6;
          END IF;
        end loop;
        IF tsajet4 = 'OK' THEN
          FOR SNN IN SN LOOP
            exit when SN%notfound;
            /*IF SUBSTR(TRES,1,2) = 'OK' THEN                -- CHECK EMP OK
               SAJET.Sj_Ckrt_Sn(SNN.SERIAL_NUMBER,tres);
            ELSE                        -- CHECK EMP NG
               TRES := 'NG;[EC201] EMP NO NG;';
            END IF;

            IF SUBSTR(TRES,1,2) = 'OK' THEN                -- CHECK SN OK
               SAJET.Sj_Ckrt_Route(TTerminalID,SNN.SERIAL_NUMBER,tres);

               IF SUBSTR(TRES,1,2) <> 'OK' THEN                -- CHECK ROUTE NG
                  TRES := 'NG;[EC999] Route NG:'||TRES||';';
               END IF;
            ELSE                        -- CHECK SN NG
               TRES := 'NG;[EC202] SN NG;';
            END IF;

            IF SUBSTR(tres,1,2) = 'OK' THEN*/
            SAJET.Sj_Go(TTerminalID,
                        SNN.SERIAL_NUMBER,
                        tnow,
                        tres,
                        tsajet2);
            -- END IF;
          END LOOP;
        ELSE
          c_Temp   := tsajet5ton;
          c_Number := 1;
          c_Start  := 1;

          LOOP
            c_End := INSTR(c_Temp, ';', 1, c_Number);
            EXIT WHEN c_End = 0;
            e_Error := TO_NUMBER(Trim(SUBSTR(c_Temp,
                                             c_Start,
                                             c_End - c_Start)));
            select serial_number
              into SSNN
              from (select row_number() over(order by serial_number) a,
                           serial_number
                      from sajet.g_sn_status
                     where panel_no = c_PANEL
                     order by serial_number)
             where a = e_Error;

            c_Start  := c_End + 1;
            c_Number := c_Number + 1;
            c_End    := INSTR(c_Temp, ';', 1, c_Number);
            e_Temp   := Trim(SUBSTR(c_Temp, c_Start, c_End - c_Start));
            e_Number := 1;
            e_Start  := 1;

            LOOP
              e_end := INSTR(e_Temp, ',', 1, e_Number);
              EXIT WHEN e_End = 0;
              c_Defect := Trim(SUBSTR(e_Temp, e_Start, e_End - e_Start));
              --SAJET.Sj_Ckrt_Route(TTerminalID,SSNN,tres);

              --Sajet.Sj_Nogo(TTerminalID, SSNN,c_Defect,tnow,tres,tnextproc,tsajet2);
              --modify by amy.lee20151010
              sj_repair_input_record(tterminalid, SSNN, c_Defect, tsajet2); ------modify by joseph 20151117去除????

              select count
                into v_count
                from sajet.g_sn_defect_count
               where serial_number = SSNN
                 and terminal_id = TTerminalID;
              if v_count >= 3 then
                Sajet.Sj_Nogo(TTerminalID,
                              SSNN,
                              c_Defect,
                              tnow,
                              tres,
                              tnextproc,
                              tsajet2);
              end if;
              UPDATE SAJET.TEMP_API_SN T
                 SET T.STATUS = 'NG'
               WHERE T.RECID = V_RECID
                 and serial_number = SSNN;
              e_Start  := e_End + 1;
              e_Number := e_Number + 1;
            END LOOP;
            sj_repair_input_record_count(tterminalid, SSNN,c_Defect, tsajet2);--add by joseph 20151117 增加??procdure
            c_Start  := c_End + 1;
            c_Number := c_Number + 1;
          END LOOP;

          COMMIT;

          /*FOR SNN IN SN LOOP
          exit when SN%notfound;
          SAJET.Sj_Ckrt_Route(TTerminalID,SNN.SERIAL_NUMBER,tres);
          IF SUBSTR(TRES,1,2) <> 'OK' THEN                -- CHECK ROUTE NG
          SAJET.Sj_Go(TTerminalID,SNN.SERIAL_NUMBER,tnow,tres,tsajet2);
          END IF;*/
          --END LOOP;

        end if;
        <<endcmd6>>
        null;
      END;

      declare
        --cursor SN is select SERIAL_NUMBER from SAJET.G_SN_STATUS where PANEL_NO = c_PANEL;
        CURSOR TSN IS
          SELECT T.SERIAL_NUMBER
            FROM SAJET.TEMP_API_SN T
           WHERE T.RECID = V_RECID
             AND T.STATUS = 'OK';
        TEMP TSN%ROWTYPE;

      begin

        FOR TEMP IN TSN LOOP
          exit when TSN%notfound;

          SAJET.Sj_Go(TTerminalID, TEMP.SERIAL_NUMBER, tnow, tres, tsajet2);

        END LOOP;

      END;

      delete sajet.temp_api_sn t where t.recid = V_RECID;

    END IF;

  ELSE
    TRES := 'NG;[EC102] COMMAND NOT DEFINE.;';

  END IF;
EXCEPTION
  WHEN OTHERS THEN
    TRES := tsajet1 || '-' || TSAJET2 || '-' || SQLERRM;
END;


/

