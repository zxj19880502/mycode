create procedure csbg_wip_go(tterminalid   in number
									   ,two           in varchar2
									   ,tpartno       in varchar2
									   ,tsn           in varchar2
									   ,tfirstprocess in varchar2
									   ,tqty          in number
									   ,tpassqty      in number
									   ,tfailqty      in number
									   ,tsumdefectqty in number
									   ,tempid        in number
									   ,tdefectdata   in varchar2
									   ,ttester       in number
									   ,tmachine      in number
									   ,tmold         in number
									   ,tslot         in varchar2
									   ,tres          out varchar2) is
	-----TERMINAL---------------
	clineid     number;
	cstageid    number;
	cprocessid  number;
	cterminalid number;
	--------------------------------------
	c_model_id        number;
	crouteid          number;
	inflag            boolean;
	outflag           boolean;
	c_out_pdline_time date;
	c_in_pdline_time  date;
	-----------DEFECT--------------
	istart         number;
	iend           number;
	inum           number;
	c_defectid     number;
	c_defectqty    number;
	c_defectcode   sajet.sys_defect.defect_code%type;
	c_sumdefectqty number;
	c_wipqty       number;
	tnow           date;
begin
	tres     := 'OK';
	tnow     := sysdate;
	c_wipqty := tpassqty + tfailqty;
	--再次檢查工單的狀態
	sajet.sj_chk_wo_input(two, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	sajet.sj_get_place(tterminalid, clineid, cstageid, cprocessid);
	if tres <> 'OK' then
		goto endp;
	end if;
	select part_id, route_id into c_model_id, crouteid from sajet.g_wo_base where work_order = two and rownum = 1;
	--紀錄機台,模具,檢驗人員,槽位
	sajet.csbg_sn_resource_input(two, tsn, cprocessid, tterminalid, ttester, tmachine, tmold, tslot, tnow, tempid,
								 c_wipqty, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	--良品數記102 PASS QTY
	sajet.csbg_transation_count(clineid, cstageid, cprocessid, tempid, tnow, tsn, two, c_model_id, 0, tpassqty, tqty,
								'0', tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	--不良數記102 FAIL QTY
	sajet.csbg_transation_count(clineid, cstageid, cprocessid, tempid, tnow, tsn, two, c_model_id, 1, tfailqty, tqty,
								'0', tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	--============DEFECT=============================================================================
	c_sumdefectqty := 0;
	if (tdefectdata <> 'N/A') then
		begin
			istart := 0;
			iend   := 0;
			loop
				istart := iend + 1;
				iend   := instr(tdefectdata, '@', istart, 1);
				exit when(iend = 0) or tres <> 'OK';
				c_defectid     := substr(tdefectdata, istart, iend - istart);
				istart         := iend + 1;
				iend           := instr(tdefectdata, '@', istart, 1);
				c_defectcode   := substr(tdefectdata, istart, iend - istart);
				istart         := iend + 1;
				iend           := instr(tdefectdata, '@', istart, 1);
				c_defectqty    := substr(tdefectdata, istart, iend - istart);
				c_sumdefectqty := c_sumdefectqty + c_defectqty;
				begin
					sajet.csbg_defect_input(clineid, cstageid, cprocessid, tterminalid, tsn, c_defectcode, tnow, tempid,
											two, c_model_id, c_defectqty);
				exception
					when others then
						tres := 'INSERT SN DEFECT ERROR';
						goto endp;
				end;
			end loop;
		exception
			when others then
				tres := 'GET DEFECT DATA ERROR';
				goto endp;
		end;
	end if;
	--只有第一站需要加WIP QTY ,非第一站時過QC 已經填WIP QTY
	if tfirstprocess = 'Y' then
		sajet.csbg_update_sn(two, c_model_id, crouteid, clineid, cstageid, cprocessid, tterminalid, tsn, '0', tnow,
							 tempid, c_wipqty, tres);
	else
		sajet.csbg_update_sn(two, c_model_id, crouteid, clineid, cstageid, cprocessid, tterminalid, tsn, '0', tnow,
							 tempid, 0, tres);
	end if;
	if tres <> 'OK' then
		goto endp;
	end if;
	insert into sajet.g_sn_travel
		(work_order, serial_number, part_id, version, route_id, pdline_id, stage_id, process_id, terminal_id,
		 next_process, current_status, work_flag, in_process_time, out_process_time, in_pdline_time, out_pdline_time,
		 enc_cnt, pallet_no, carton_no, container, qc_no, qc_result, customer_id, warranty, rework_no, emp_id,
		 shipping_id, customer_sn, wip_process, wip_qty)
		select work_order, serial_number, part_id, version, route_id, pdline_id, stage_id, process_id, terminal_id,
			   next_process, current_status, work_flag, in_process_time, out_process_time, in_pdline_time,
			   out_pdline_time, enc_cnt, pallet_no, carton_no, container, qc_no, qc_result, customer_id, warranty,
			   rework_no, emp_id, shipping_id, customer_sn, wip_process, c_wipqty
		from   sajet.g_sn_status
		where  serial_number = tsn and rownum = 1;
	--檢查是否為工單的投入站
	sajet.csbg_wo_input_qty(cprocessid, tsn, c_wipqty, tnow, tempid, inflag, tres);
	if tres <> 'OK' then
		goto endp;
	end if;
	<<endp>>
	null;
	if tres = 'OK' then
		commit;
	else
		rollback;
	end if;
exception
	when others then
		tres := 'CSBG_WIP_GO Error';
		rollback;
end;


/

