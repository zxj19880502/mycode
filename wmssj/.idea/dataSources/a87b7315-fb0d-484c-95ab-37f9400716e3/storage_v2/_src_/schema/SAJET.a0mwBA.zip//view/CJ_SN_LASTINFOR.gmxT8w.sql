create view CJ_SN_LASTINFOR as
select a.serial_number,
       a.out_process_time,
       row_number() over(partition by a.serial_number order by a.out_process_time desc) rank,
       a.current_status
  from sajet.g_sn_travel a
 where a.process_id = 100026
   and to_char(a.out_process_time - 8.5 / 24, 'yyyymmdd') =
       to_char(sysdate - 8.5 / 24, 'yyyymmdd')


/

