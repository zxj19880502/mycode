create view VV_HUNLIAO as
select times,shift,sum(qty3) qty3 from
(select to_char(to_char(a.in_process_time-8.5/24,'yyyy-mm-dd')) times,sajet.worksshifet_param(a.in_process_time-8.5/24) shift,
count(1) qty3
from
sajet.g_rc_travel a
where a.process_id='100007'
group by to_char(to_char(a.in_process_time-8.5/24,'yyyy-mm-dd')),sajet.worksshifet_param(a.in_process_time-8.5/24)
union all
select to_char(to_char(a.in_process_time-8.5/24,'yyyy-mm-dd')) times,sajet.worksshifet_param(a.in_process_time-8.5/24) shift,
count(1) qty3
from
sajet.g_rc_status a
where a.process_id='100007' and a.out_process_time is null
group by to_char(to_char(a.in_process_time-8.5/24,'yyyy-mm-dd')),sajet.worksshifet_param(a.in_process_time-8.5/24))
group by times,shift


/

