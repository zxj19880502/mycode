create view V_QWEQWR as
select  b.process_name,c.pdline_name,d.stage_name
from sajet.sys_process b,sajet.sys_pdline c,sajet.sys_stage d,sajet.sys_terminal a
where
a.process_id=b.process_id
and a.pdline_id=c.pdline_id
and a.stage_id=d.stage_id


/

