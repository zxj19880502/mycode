create function f_cus_splitstr(str in clob
										 ,i   in number := 0
										 ,sep in varchar2 := ',') return varchar2
/**************************************
    * Name:        splitstr
    * Function:    返回字符串被指定字符分割后的指定??字符串。
    * Parameters:  str: 待分割的字符串。
                   i: 返回第几???。?i?0返回str中的所有字符，?i 超?可被分割的???返回空。
                   sep: 分隔符，默?逗?，也可以指定字符或字符串。?指定的分隔符不存在于str中?返回sep中的字符。
    * Example:     select splitstr('abc,def', 1) as str from dual;  得到 abc
                   select splitstr('abc,def', 3) as str from dual;  得到 空
    **************************************/
 is
	t_i     number;
	t_count number;
	t_str   varchar2(4000);
begin
	if i = 0 then
		t_str := str;
	elsif instr(str, sep) = 0 then
		t_str := sep;
	else
		select count(*) into t_count from table(f_cus_split(str, sep));
	
		if i <= t_count then
			select str
			into   t_str
			from   (select rownum as item, column_value as str from table(f_cus_split(str, sep)))
			where  item = i;
		end if;
	end if;

	return t_str;
end;


/

