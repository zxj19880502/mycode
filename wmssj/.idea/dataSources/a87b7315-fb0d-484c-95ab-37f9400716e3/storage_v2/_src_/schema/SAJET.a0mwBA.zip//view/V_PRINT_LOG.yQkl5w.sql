create view V_PRINT_LOG as
select rc_no, print_time, label_type
  from (select label_type,
               label_content rc_no,
               print_time,
               row_number() over(partition by label_content/*, label_type */order by print_time desc) print_order
          from sajet.g_print_log
         where label_type in ('流程单', '派工信息单'))
 where print_order = 1


/

