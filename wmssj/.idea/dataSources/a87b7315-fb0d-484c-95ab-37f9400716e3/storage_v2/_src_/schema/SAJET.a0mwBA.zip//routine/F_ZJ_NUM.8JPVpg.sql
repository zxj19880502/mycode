create function F_ZJ_NUM(SSN IN VARCHAR2) return number is
  Result number;
  
begin
  Result:=0;
  SELECT COUNT(T.SERIAL_NUMBER)
    INTO Result
    FROM SAJET.G_SN_TRAVEL T
   WHERE T.SERIAL_NUMBER = SSN
     AND T.PROCESS_ID = 100026
     AND T.CURRENT_STATUS = '4';
     RETURN RESULT;
     
  EXCEPTION
    WHEN OTHERS THEN
      RESULT:=0;
      return(Result);
end F_ZJ_NUM;


/

