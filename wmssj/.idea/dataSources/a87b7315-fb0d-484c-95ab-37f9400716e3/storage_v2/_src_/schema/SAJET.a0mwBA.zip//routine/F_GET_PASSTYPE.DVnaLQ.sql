create function       f_get_passtype(tsn               in varchar2
                     ,tcurrent_status   in varchar2
                     ,tterminal_id      in varchar2
                     ,tout_process_time in date) return varchar2 is


  t_location varchar2(50);

begin
  t_location := '';
  if tcurrent_status = '0' then
    select test_values
    into   t_location
    from   (select a.test_values
         from   sajet.g_ict_test a
         where  a.serial_number = tsn and a.terminal_id = tterminal_id and
            a.update_time between tout_process_time and tout_process_time + 5 / 14400 and
            a.test_item = 'Judgment_Location'
         order  by update_time desc)
    where  rownum = 1;
  end if;
  return t_location;

exception
  when others then
    return null;
end;


/

