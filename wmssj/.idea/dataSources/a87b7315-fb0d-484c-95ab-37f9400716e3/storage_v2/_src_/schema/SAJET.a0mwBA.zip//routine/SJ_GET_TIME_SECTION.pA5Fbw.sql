create FUNCTION       sj_get_time_section(tnow in date) return varchar2 is
cTime varchar2(25);
cCount number;
cDate Date;
begin
   begin
      select param_value into cTime from sajet.sys_base where param_name = 'TIME_SECTION' and rownum = 1;
   exception
      when others then
         cTime := '60';
   end;
   begin
      cCount := to_number(cTime);
   exception
      when others then
         cCount := 60;
   end;
   return trunc((tNow - to_date(to_char(tNow,'yyyymmdd'),'yyyymmdd'))*24*60/cCount,0);
end;


/

