create procedure       csbg_chk_sys_toolsn(trev in varchar2
													 ,tres out varchar2) is
	ctoolsn     sajet.sys_tooling_sn.tooling_sn%type;
	cwo         sajet.g_wo_base.work_order%type;
	cused_count number;
	cday        number;
	ctoolsnid   number;
	ctoolid     number;
	cmaxuse     number;
	climituse   number;
	cusedtime   number;
	swarning    varchar2(20);
	c_toolsn    sajet.sys_tooling_sn.tooling_sn%type;
begin
	begin
		select tooling_sn, tooling_sn_id
		into   ctoolsn, ctoolsnid
		from   sajet.sys_tooling_sn
		where  tooling_sn = trev and enabled = 'Y' and rownum = 1;
	exception
		when others then
			tres := 'NO TOOL SN';
			goto endp;
	end;
	/*
      --TOOLING SN是否已被領走
      SELECT A.TOOLING_SN_ID,A.TOOLING_ID
            ,NVL(C.WORK_ORDER,'N/A'),C.USED_COUNT,TRUNC((SYSDATE - NVL(C.LAST_MAINTAIN_TIME,SYSDATE)))
      INTO CTOOLSNID,CTOOLID,CWO,CUSED_COUNT,CDAY
      FROM SAJET.G_TOOLING_SN_STATUS C
          ,SAJET.SYS_TOOLING_SN A
      WHERE A.TOOLING_SN = TREV
      AND C.TOOLING_SN_ID = A.TOOLING_SN_ID(+)
      AND A.ENABLED='Y';
      IF CWO <> 'N/A' THEN
        TRES:='Tool SN Used';
        GOTO ENDP;
      END IF;
    */
	csbg_chk_tooling_used(ctoolsnid, tres, swarning, c_toolsn);
	if tres <> 'OK' then
		goto endp;
	end if;
	if swarning <> 'N/A' then
		tres := 'OK' || '(' || swarning || ')';
	else
		tres := 'OK';
	end if;
	<<endp>>
	null;
exception
	when others then
		tres := 'CSBG_CHK_SYS_TOOLSN ERR';
end;


/

