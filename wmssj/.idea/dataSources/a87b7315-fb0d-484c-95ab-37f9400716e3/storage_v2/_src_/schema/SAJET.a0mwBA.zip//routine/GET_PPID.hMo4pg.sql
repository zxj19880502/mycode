create function get_ppid(ppid in varchar2) return varchar2 is
	csn1   varchar2(200);
	csn2   varchar2(200);
	csn3   varchar2(200);
	csn4   varchar2(200);
	csn5   varchar2(200);
	csn6   varchar2(200);
	csn7   varchar2(200);
	csn    varchar2(200);
	ccount number;
begin
	select count(*) into ccount from sajet.g_sn_customersn2 a where serial_number = ppid or customer_sn = ppid;
	if ccount = 0 then
		csn := '';
		goto endp;
	end if;
	select customer_sn into csn7 from sajet.g_sn_customersn2 a where serial_number = ppid or customer_sn = ppid;

	csn1 := substr(csn7, 1, 2);
	csn2 := substr(csn7, 3, 6);
	csn3 := substr(csn7, 9, 5);
	csn4 := substr(csn7, 14, 3);
	csn5 := substr(csn7, 17, 4);
	csn6 := substr(csn7, 21, 3);

	csn := csn1 || '-' || csn2 || '-' || csn3 || '-' || csn4 || '-' || csn5 || '-' || csn6; --+ csn2 + '-' + csn3 + '-' + csn4 + '-' + csn5 + '-' + csn6;
	<<endp>>
	return csn;
exception
	when others then
		return sqlerrm;
end;
/

