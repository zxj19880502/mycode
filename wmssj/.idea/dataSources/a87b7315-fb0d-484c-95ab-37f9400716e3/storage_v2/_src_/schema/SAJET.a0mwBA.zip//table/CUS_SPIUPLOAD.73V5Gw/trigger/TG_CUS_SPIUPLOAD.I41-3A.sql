create trigger TG_CUS_SPIUPLOAD
  before insert
  on CUS_SPIUPLOAD
  for each row
declare
	-- local variables here
begin
	select serial_number
	into   :new.serial_number
	from   wiq.cus_snlink_relation
	where  link_no = (select link_no from wiq.cus_snlink_relation where serial_number = :new.barcode) and
		   numbers = :new.arrayid;
end tg_cus_spiupload;


/

