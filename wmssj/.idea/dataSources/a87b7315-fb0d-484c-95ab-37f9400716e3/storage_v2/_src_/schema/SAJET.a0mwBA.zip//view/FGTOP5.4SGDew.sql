create view FGTOP5 as
select defect_id, defect_desc, totalnum
  from (select l.defect_id,K.defect_desc,k.totalnum from
(select distinct defect_id from (
select nvl(max(defect_id),'0') defect_Id,nvl(max(defect_desc),'0') defect_desc,nvl(max(totalnum),'0') totalnum from
(
select c.defect_id,c.defect_desc, count(a.defect_id) totalnum
          from sajet.g_sn_defect a, sajet.g_sn_travel b, sajet.sys_defect c
         where b.Current_Status = '4' and to_char(b.out_process_time,'yyyymmdd')=to_char(sysdate,'yyyymmdd')
           and a.serial_number = b.serial_number
           and a.process_id = b.process_id
           and a.rec_time=b.out_process_time
           and a.defect_id = c.defect_id
         group by c.defect_id, c.defect_desc
         order by count(a.defect_id) desc)
union
         select defect_id,defect_desc,totalnum from (
select c.defect_id,c.defect_desc, count(a.defect_id) totalnum
          from sajet.g_sn_defect a, sajet.g_sn_travel b, sajet.sys_defect c
         where b.Current_Status = '4' and to_char(b.out_process_time,'yyyymmdd')=to_char(sysdate,'yyyymmdd')
           and a.serial_number = b.serial_number
           and a.process_id = b.process_id
           and a.rec_time=b.out_process_time
           and a.defect_id = c.defect_id
         group by c.defect_id, c.defect_desc
         order by count(a.defect_id) desc)
         )) l
         left join
         (select defect_id,defect_desc,totalnum from (
select c.defect_id,c.defect_desc, count(a.defect_id) totalnum
          from sajet.g_sn_defect a, sajet.g_sn_travel b, sajet.sys_defect c
         where b.Current_Status = '4' and to_char(b.out_process_time,'yyyymmdd')=to_char(sysdate,'yyyymmdd')
           and a.serial_number = b.serial_number
           and a.process_id = b.process_id
           and a.rec_time=b.out_process_time
           and a.defect_id = c.defect_id
         group by c.defect_id, c.defect_desc
         order by count(a.defect_id) desc)) k on l.defect_id=k.defect_id order by k.totalnum desc)
 where rownum <= 5


/

