create PROCEDURE BITLAND_BIND_COA_SN(TSN in varchar2,TCOANO in varchar2,TMPART in varchar2,TITEM_PARTID in varchar2,TWO in varchar2,TTERMINALID in varchar2,TEMP in varchar2,TRES out varchar2)IS
empid number;
processid sajet.sys_process.process_id%type;
nextprocess varchar2(30);
--itempartid sajet.g_wo_bom.item_part_id%type;
BEGIN
  TRES:='OK';
  nextprocess:='N/A';
  empid:=0;
  if TSN is null then
    TRES:='sn is null';
    elsif TCOANO is null then
    TRES:='Coa No is null';
    elsif TEMP is  null then
    TRES:='emp no is null';
    elsif TWO is null then
    TRES:='WO is Null';
    end if;
    if TRES!='OK'then
      return;
    end if;
     sajet.Sj_Get_Empid(TEMP,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMP||')';
  end if;
  if TRES!='OK'then
    return;
   end if;
   select t.process_id into processid from sajet.sys_terminal t where t.terminal_id=TTERMINALID;
      update sajet.g_sn_coa sc set sc.serial_number=TSN,sc.update_time=sysdate,sc.update_user_id=empid,sc.status=2 where sc.coa_no=TCOANO;
      insert into sajet.g_ht_sn_coa select * from sajet.g_sn_coa sc where sc.coa_no=TCOANO;
      insert into sajet.g_sn_keyparts(work_order,serial_number,item_part_id,process_id,item_part_sn,update_userid,update_time,enabled,terminal_id,customer_part_sn)
      values(TWO,TSN,TITEM_PARTID,processid,TMPART,empid,sysdate,'Y',TTERMINALID,TCOANO);
      sajet.sj_transfer2(TTERMINALID,TSN,'N/A',sysdate,TEMP,TRES,nextprocess);
      if substr(TRES,0,2)='OK' then
        commit;
      else
           rollback;
      end if;
exception
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

