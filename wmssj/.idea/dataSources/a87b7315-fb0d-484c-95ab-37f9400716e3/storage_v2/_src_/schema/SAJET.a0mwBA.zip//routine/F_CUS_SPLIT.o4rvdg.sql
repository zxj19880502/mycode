create function f_cus_split(p_list clob
									  ,p_sep  varchar2 := ',') return tabletype
	pipelined
/**************************************
    * Name:        split
    * Function:    返回字符串被指定字符分割后的表?型。
    * Parameters:  p_list: 待分割的字符串。
                   p_sep: 分隔符，默?逗?，也可以指定字符或字符串。
    * Example:     SELECT *
                     FROM users
                    WHERE u_id IN (SELECT COLUMN_VALUE
                                     FROM table (split ('1,2')))
                   返回u_id?1和2的?行?据。
    **************************************/
 is
	l_idx  pls_integer;
	v_list varchar2(32676) := p_list;
begin
	loop
		l_idx := instr(v_list, p_sep);
	
		if l_idx > 0 then
			pipe row(substr(v_list, 1, l_idx - 1));
			v_list := substr(v_list, l_idx + length(p_sep));
		else
			pipe row(v_list);
			exit;
		end if;
	end loop;
end;


/

