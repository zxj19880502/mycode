create function       
       RMA_NO_STATUS(svalue in varchar2) return varchar2 is
str varchar2(16);
begin
  if svalue = '0' then
    str := 'Initial';
  elsif svalue = '1' then
    str := 'Open';
  elsif svalue = '2' then
    str := 'Closed';
  elsif svalue = 'N/A' then
    str := 'N/A';
  else
    str := 'Unknown';
  end if;
  return str;
end;


/

