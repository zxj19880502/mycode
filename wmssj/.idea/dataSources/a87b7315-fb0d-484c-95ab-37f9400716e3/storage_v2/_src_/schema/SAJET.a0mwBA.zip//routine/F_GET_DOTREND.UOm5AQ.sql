create function f_get_dotrend(stoday_yield    in varchar2
										,syeterday_yield in varchar2) return varchar2 is
	cdotrend varchar2(10);
	/*
    抓前一天的yield，比较上升还是下降
    */

begin


	if stoday_yield > syeterday_yield then
		cdotrend := 'UP';
	elsif stoday_yield < syeterday_yield then
		cdotrend := 'DOWN';
	else
		cdotrend := 'EQUAL';
	end if;


	return cdotrend;
exception
	when others then
		return '';
end;
/

