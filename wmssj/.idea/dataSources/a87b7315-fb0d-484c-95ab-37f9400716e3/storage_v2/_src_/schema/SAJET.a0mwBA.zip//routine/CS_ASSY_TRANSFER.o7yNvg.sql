create procedure cs_assy_transfer(tlineid     in number
											,tstageid    in number
											,tprocessid  in number
											,tterminalid in number
											,tsn         in varchar2
											,tnow        in date
											,tres        out varchar2
											,temp        in varchar2
											,trev        in varchar2) is
	cwo      varchar2(25);
	cmodelid number;
	ok       varchar2(25);
	tempid   number;
	inflag   boolean;
	outflag  boolean;
	intime   date;
	outtime  date;
begin
	select b.work_order, b.part_id, in_pdline_time, out_pdline_time
	into   cwo, cmodelid, intime, outtime
	from   sajet.g_sn_status b
	where  b.serial_number = tsn and rownum = 1;
	sajet.sj_get_empid(temp, tempid);
	sajet.sj_debit_material_one(tterminalid, tsn, cwo, temp, tlineid, tprocessid, tres);
	if tres = 'OK' then
	
		sajet.sj_chk_wo_input(cwo, ok);
		if ok <> 'OK' then
			tres := ok;
		else
		
			sajet.sj_wo_input_qty(tlineid, tstageid, tprocessid, tterminalid, tsn, tnow, tres, tempid, inflag);
			sajet.sj_wo_output_qty(tlineid, tstageid, tprocessid, tterminalid, tsn, tnow, tres, tempid, outflag);
			if inflag then
				intime := tnow;
			end if;
			if outflag then
				outtime := tnow;
			end if;
			update sajet.g_sn_status set customer_sn = trev where serial_number = tsn and rownum = 1;
			sajet.sj_transation_count(tlineid, tstageid, tprocessid, tempid, tnow, tsn, cwo, cmodelid, tres, 0);
			sajet.sj_update_sn(tlineid, tstageid, tprocessid, tterminalid, tsn, '0', tnow, tempid, intime, outtime);
		end if;
	end if;
exception
	when others then
		tres := 'cs_transfer error';
end;


/

