create procedure       csbg_assy_chk_part_rule(tprocessid in number
														 ,trev       in varchar2
														 ,tsn        in varchar2
														 ,u_partno   out varchar2
														 ,u_partid   out varchar2
														 ,u_partsn   out varchar2
														 ,tres       out varchar2) is
	v_work_order sajet.g_sn_status.work_order%type;
	v_model_id   number;
	v_sn         sajet.g_sn_status.serial_number%type;
	v_enabled    sajet.sys_part.enabled%type;
begin
	tres     := 'OK';
	u_partno := 'N/A';
	u_partsn := trev;
	select work_order, part_id
	into   v_work_order, v_model_id
	from   sajet.g_sn_status
	where  serial_number = tsn and rownum = 1;
	--找BOM表內,此站要裝的所有料的規則
	declare
		cursor rule_cursor is
			select part_id, length1, from1, to1, fix1, nvl(from2, 0) from2, nvl(to2, 0) to2, fix2
			from   sajet.sys_part_sn_rule
			where  part_id in
				   (select item_part_id
					from   sajet.g_wo_bom
					where  work_order = v_work_order and part_id = v_model_id and process_id = tprocessid);
		rule_record rule_cursor%rowtype;
	begin
		tres := 'RULE ERR';
		--檢查是否有符合的規則
		open rule_cursor;
		loop
			fetch rule_cursor
				into rule_record;
			exit when rule_cursor%notfound;
			--RULE1 
			if length(trev) = rule_record.length1 then
				if substr(trev, rule_record.from1, rule_record.to1 - rule_record.from1 + 1) = rule_record.fix1 then
					--若規則中KPSN長度與特徵所設的長度相同，則KPSN 紀錄N/A 
					if rule_record.length1 = rule_record.to1 - rule_record.from1 + 1 then
						u_partsn := 'N/A';
					end if;
					--RULE2 (若沒設就不檢查) 
					if rule_record.from2 <> 0 then
						if substr(trev, rule_record.from2, rule_record.to2 - rule_record.from2 + 1) = rule_record.fix2 then
							u_partid := rule_record.part_id;
							tres     := 'OK';
							exit;
						end if;
					else
						u_partid := rule_record.part_id;
						tres     := 'OK';
						exit;
					end if;
				end if;
			end if;
		end loop;
		close rule_cursor;
	end;
	if tres = 'OK' then
		begin
			select enabled, part_no
			into   v_enabled, u_partno
			from   sajet.sys_part
			where  part_id = u_partid and rownum = 1;
			if v_enabled <> 'Y' then
				tres := u_partno || ' Disabled !';
			else
				tres := 'OK';
			end if;
		exception
			when others then
				tres := 'NO KPNO';
		end;
	end if;
exception
	when others then
		tres := 'KPSN : ' || trev || '  ERROR! ';
end;


/

