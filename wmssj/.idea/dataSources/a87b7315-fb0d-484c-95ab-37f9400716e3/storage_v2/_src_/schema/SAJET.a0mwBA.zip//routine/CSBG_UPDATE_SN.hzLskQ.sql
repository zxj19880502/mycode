create procedure csbg_update_sn(two         in varchar2
										  ,tpartid     in number
										  ,trouteid    in number
										  ,tlineid     in number
										  ,tstageid    in number
										  ,tprocessid  in number
										  ,tterminalid in number
										  ,tsn         in varchar2
										  ,tstatus     in varchar2
										  ,tnow        in date
										  ,tempid      in varchar2
										  ,twipqty     in number
										  ,tres        out varchar2) is
	crouteid number;
	c_type   number;
begin
	begin
		select route_id into crouteid from sajet.g_sn_status where serial_number = tsn and rownum = 1;
		c_type := 1;
	exception
		when others then
			c_type := 0;
	end;
	if c_type = 0 then
		insert into sajet.g_sn_status
			(work_order, serial_number, part_id, route_id, pdline_id, stage_id, process_id, terminal_id, next_process,
			 current_status, in_process_time, out_process_time, emp_id, wip_process, wip_qty)
		values
			(two, tsn, tpartid, trouteid, tlineid, tstageid, tprocessid, tterminalid, 0, tstatus, null, tnow, tempid,
			 tprocessid, twipqty);
	else
		update sajet.g_sn_status
		set    pdline_id = tlineid, stage_id = tstageid, process_id = tprocessid, terminal_id = tterminalid,
			   in_process_time = out_process_time, out_process_time = tnow, emp_id = tempid, wip_qty = wip_qty + twipqty
		where  serial_number = tsn and rownum = 1;
	end if;
	/*
      INSERT INTO sajet.G_SN_TRAVEL
      (WORK_ORDER,SERIAL_NUMBER,MODEL_ID,VERSION,ROUTE_ID,PDLINE_ID,STAGE_ID,PROCESS_ID,TERMINAL_ID
      ,NEXT_PROCESS,CURRENT_STATUS,WORK_FLAG,IN_PROCESS_TIME,OUT_PROCESS_TIME,IN_PDLINE_TIME,OUT_PDLINE_TIME
      ,ENC_CNT,PALLET_NO,CARTON_NO,CONTAINER,QC_NO,QC_RESULT,CUSTOMER_ID,WARRANTY,REWORK_NO,EMP_ID,SHIPPING_ID
      ,CUSTOMER_SN,WIP_PROCESS,WIP_QTY)
      SELECT WORK_ORDER,SERIAL_NUMBER,MODEL_ID,VERSION,ROUTE_ID,PDLINE_ID,STAGE_ID,PROCESS_ID,TERMINAL_ID
      ,NEXT_PROCESS,CURRENT_STATUS,WORK_FLAG,IN_PROCESS_TIME,OUT_PROCESS_TIME,IN_PDLINE_TIME,OUT_PDLINE_TIME
      ,ENC_CNT,PALLET_NO,CARTON_NO,CONTAINER,QC_NO,QC_RESULT,CUSTOMER_ID,WARRANTY,REWORK_NO,EMP_ID,SHIPPING_ID
      ,CUSTOMER_SN,WIP_PROCESS,TWIPQTY FROM sajet.G_SN_STATUS WHERE serial_number = tsn AND ROWNUM = 1;
    */
	tres := 'OK';
exception
	when others then
		tres := 'CSBG_UPDATE_SN Error';
		rollback;
end;


/

