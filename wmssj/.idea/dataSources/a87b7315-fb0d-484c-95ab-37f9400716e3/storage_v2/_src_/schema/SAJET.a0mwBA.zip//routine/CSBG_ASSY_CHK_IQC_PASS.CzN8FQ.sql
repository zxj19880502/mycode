create procedure       csbg_assy_chk_iqc_pass(t_lotno  in varchar2
														,t_partsn in varchar2
														,tres     out varchar2) is
	c_qc_result sajet.g_iqc_lot.qc_result%type;
begin
	tres := 'OK';
	--檢查此批是否在IQC PASS
	begin
		select qc_result into c_qc_result from sajet.g_iqc_lot where lot_no = t_lotno and rownum = 1;
		if c_qc_result = 'N/A' then
			tres := 'PLEASE GO IQC';
		elsif c_qc_result <> '0' then
			tres := 'LOT NOT PASS FROM IQC';
		end if;
	exception
		when others then
			tres := 'NO IQC LOT NO';
	end;
	if tres = 'OK' then
		--檢查KPSN 是否在IQC BY PIECE 時有DEFECT
		if t_partsn <> 'N/A' then
			begin
				select qc_result into c_qc_result from sajet.g_iqc_detail where part_sn = t_partsn and rownum = 1;
				if c_qc_result <> '0' then
					tres := 'KPSN FAIL FROM IQC';
				end if;
			exception
				when others then
					tres := 'OK';
			end;
		end if;
	end if;
exception
	when others then
		tres := 'CSBG_ASSY_CHK_IQC_PASS ERROR';
end;


/

