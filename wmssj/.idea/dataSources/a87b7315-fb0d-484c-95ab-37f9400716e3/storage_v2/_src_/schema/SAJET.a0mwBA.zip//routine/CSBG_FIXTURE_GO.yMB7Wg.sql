create procedure       csbg_fixture_go(trev        in varchar2
												 ,tterminalid in number
												 ,tsn         in varchar2
												 ,ttool       in varchar2
												 ,tnow        in date
												 ,temp        in varchar2
												 ,ptool_seq   in varchar2
												 ,tres        out varchar2) is
	clineid      number;
	cstageid     number;
	cprocessid   number;
	cwo          varchar2(25);
	cempid       number;
	tprocessid   number;
	sok          varchar2(25);
	cnextprocess number;
begin
	if upper(trev) = 'END' then
		sajet.sj_get_empid(temp, cempid);
		sajet.sj_get_place(tterminalid, clineid, cstageid, cprocessid);
		select work_order, process_id, next_process
		into   cwo, tprocessid, cnextprocess
		from   sajet.g_sn_status
		where  serial_number = tsn and rownum = 1;
		sok := 'OK';
		if (tprocessid <> cprocessid) or (cprocessid = cnextprocess) then
			sajet.sj_go(tterminalid, tsn, tnow, sok, temp);
		end if;
		if sok = 'OK' then
			sajet.csbg_fixture_input(cwo, tsn, ttool, cprocessid, tterminalid, cempid, ptool_seq, tnow, sok);
		end if;
		tres := sok;
	else
		tres := 'COMMAND ERROR';
	end if;
exception
	when others then
		tres := 'CSBG_FIXTURE_GO ERR';
end;


/

