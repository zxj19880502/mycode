create procedure arabbao_sj_command(tsajet1     in varchar2
											  ,tsajet2     in varchar2
											  ,tsajet3     in varchar2
											  ,tsajet4     in varchar2
											  ,tsajet5     in varchar2
											  ,tsajet6     in varchar2
											  ,tsajet7     in varchar2
											  ,tsajet8     in varchar2
											  ,tsajet9     in varchar2
											  ,tsajet10    in varchar2
											  ,tsajet11    in varchar2
											  ,tlineid     in varchar2
											  ,tstageid    in varchar2
											  ,tprocessid  in varchar2
											  ,tterminalid in varchar2
											  ,temp        in out varchar2
											  ,tres        out varchar2) as
	c_wo      varchar2(40);
	c_model   varchar2(40);
	c_part_id varchar2(40);
	c_psn     varchar2(40);
	c_process varchar2(40);
	c_pempid  varchar2(40);
	c_pcsn    varchar2(100);


	-- ----------------
	-- CPSZ Arabbao 2016.02.29
	-- version 1.0
	-- for Packing,icc,sncheck
	-- ----------------


begin

	------------------------------Get ALL ARGS-----------------------------------
	if tsajet1 = '8' then
		tres := 'OK' || chr(27) || tsajet1 || chr(27) || tsajet2 || chr(27) || tsajet3 || chr(27) || tsajet4 || chr(27) ||
				tsajet5 || chr(27) || tsajet6 || chr(27) || tsajet7 || chr(27) || tsajet8 || chr(27) || tsajet9 ||
				chr(27) || tsajet10 || chr(27) || tsajet11 || chr(27) || tlineid || chr(27) || tstageid || chr(27) ||
				tprocessid || chr(27) || tterminalid || chr(27) || temp || chr(27);
	
		------------------------------CHECK EMP PRIVILEG------------------------------
	elsif tsajet1 = '1' or temp = 'N/A' then
		--TSAJET2 IS Emp NUM
		sajet.sj_cksys_emp(tsajet2, tres);
		if tres = 'OK' then
			sajet.sj_get_empid_keep(tsajet2, c_pempid, tres);
			if tres = 'OK' then
				sajet.sj_cksys_emp_process(tsajet2, tterminalid, tres);
				if tres = 'OK' then
					temp := tsajet2;
					tres := 'OK' || chr(27) || 'EMP OK';
				else
					tres := 'NO PRIVILEGE IN PROCESS';
				end if;
			else
				tres := 'EMP ERR';
			end if;
		else
			tres := 'EMP ERR';
		end if;
	
		------------------------------GET SN INFOS------------------------------
	elsif tsajet1 = '2' then
		begin
			sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
			if substr(tres, 1, 2) = 'OK' then
				sajet.tm_check_sn(c_psn, tres, c_wo);
				if substr(tres, 1, 2) = 'OK' then
					sajet.sj_ckrt_route(tterminalid, c_psn, tres); --Arabbao
					c_process := tres; --Arabbao
					tres      := 'OK'; --Arabbao
					if substr(tres, 1, 2) = 'OK' then
						select a.work_order, b.part_no, a.part_id
						into   c_wo, c_model, c_part_id
						from   sajet.g_wo_base a, sajet.sys_part b
						where  a.work_order = c_wo and a.part_id = b.part_id;
					
						select a.customer_sn into c_pcsn from g_sn_status a where a.serial_number = c_psn;
					
						tres := 'OK' || chr(27) || tsajet1 || chr(27) || tsajet2 || chr(27) || c_psn || chr(27) || c_wo ||
								chr(27) || c_model || chr(27) || c_process || chr(27) || c_pcsn || chr(27); --Arabbao
					end if;
				end if;
			end if;
		exception
			when others then
				tres := 'EXECUTE MIS_COMMAND_Arabbao ERROR(GET SN INFO)';
		end;
	
		-----------------------PASS/FAIL-----------------------------------------
		--TSAJET4 IS 'PASS' OR DEFCET CODE
	elsif tsajet1 = '3' then
		begin
			sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
			sajet.sj_ckrt_route(tterminalid, c_psn, tres);
			if substr(tres, 1, 2) = 'OK' then
				sajet.tm_test_result_arabbao(c_psn, tterminalid, tsajet4, temp, tres);
				if substr(tres, 1, 2) = 'OK' then
					tres := 'OK' || chr(27) || tsajet1 || chr(27);
				end if;
			end if;
		exception
			when others then
				tres := 'EXECUTE MIS_COMMAND_Arabbao ERROR(SET SN PASS/FAIL)';
		end;
	
		-----------------------ASSY-----------------------------------------
		--TSAJET2:SN
		--TSAJET3:CSN
	elsif tsajet1 = '4' then
		begin
			sajet.cs_chk_kps(tlineid, tstageid, tprocessid, tterminalid, tsajet2, sysdate, tres, '', tsajet3, '');
			if substr(tres, 1, 2) = 'OK' then
				sajet.cs_assy_transfer(tlineid, tstageid, tprocessid, tterminalid, tsajet2, sysdate, tres, temp,
									   tsajet3);
			end if;
		
		exception
			when others then
				tres := 'EXECUTE MIS_COMMAND_Arabbao ERROR(MAPPING)';
		end;
		-----------------------ASSY NewVersion-----------------------------------------
		--TSAJET2:SN
		--TSAJET3:CSN
		--The different of '40' and '4' is whether  the command return begin with 'OK'
	elsif tsajet1 = '40' then
		begin
			sajet.cs_chk_kps(tlineid, tstageid, tprocessid, tterminalid, tsajet2, sysdate, tres, '', tsajet3, '');
			if substr(tres, 1, 2) = 'OK' then
				sajet.cs_assy_transfer(tlineid, tstageid, tprocessid, tterminalid, tsajet2, sysdate, tres, temp,
									   tsajet3);
			end if;
			if tres = 'OK' then
				tres := 'OK' || chr(27) || tsajet1 || chr(27);
			end if;
		
		exception
			when others then
				tres := 'EXECUTE MIS_COMMAND_Arabbao ERROR(MAPPING)';
		end;
	
		-----------------------CANCEL_KPS-----------------------------------------
		--TSAJET2:SN
		--TSAJET3:CSN
	elsif tsajet1 = '5' then
		begin
			sajet.sj_get_empid_keep(temp, c_pempid, tres);
			sajet.cs_cancel_kps(tlineid, tstageid, tprocessid, tterminalid, tsajet2, tres, tsajet3, c_pempid, sysdate);
		exception
			when others then
				tres := 'EXECUTE MIS_COMMAND_Arabbao ERROR(CANCEL_KPS)';
		end;
	
		-----------------------WO HOLD-----------------------------------------
		--TSAJET2:WO TO BE HOLD
		--TSAJET3:MEMO
	
	elsif tsajet1 = '6' then
		begin
			sajet.sj_get_empid_keep(temp, c_pempid, tres);
			select a.wo_status into tres from g_wo_base a where a.work_order = tsajet2;
			if tres <> '3' then
				tres := 'THE WO CANNOT BEEN HOLD WHICH IS NOT WORK IN PROCESS';
			else
			
				update sajet.g_wo_base
				set    wo_status = 4, update_userid = c_pempid, update_time = sysdate
				where  work_order = tsajet2;
			
				insert into sajet.g_wo_status
					(work_order, wo_status, memo, update_userid)
				values
					(tsajet2, 4, tsajet3, c_pempid);
			
				insert into sajet.g_ht_wo_base
					select * from sajet.g_wo_base where work_order = tsajet2;
			
				tres := 'OK' || chr(27) || 'HOLD OK';
			end if;
		exception
			when others then
				tres := 'EXECUTE MIS_COMMAND_Arabbao ERROR(TO HOLD WO)';
		end;
	
		--------------------Check CSN NOT Exists-------------------------------------------
		--TSAJET2:CSN
	elsif tsajet1 = '7' then
		select count(*) into tres from g_sn_status a where a.customer_sn = tsajet2;
		if tres = 0 then
			tres := 'OK' || chr(27) || 'CSN NOT Exists';
		end if;
	
	end if; --MAIN IF

exception
	when others then
		tres := 'EXECUTE MIS_COMMAND_Arabbao ERROR(UNKNOW)';
end;


/

