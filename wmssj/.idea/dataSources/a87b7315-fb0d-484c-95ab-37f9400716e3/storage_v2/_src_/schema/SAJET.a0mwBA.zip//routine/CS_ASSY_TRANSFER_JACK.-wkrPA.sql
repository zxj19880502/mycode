create procedure cs_assy_transfer_jack(tlineid     in number
												 ,tstageid    in number
												 ,tprocessid  in number
												 ,tterminalid in number
												 ,tsn         in varchar2
												 ,tnow        in date
												 ,tres        out varchar2
												 ,temp        in varchar2
												 ,trev        in varchar2) is

	v_sn varchar2(100);
begin
	select nvl((select s.serial_number from sajet.g_sn_status s where s.serial_number = tsn or s.customer_sn = tsn), '')
	into   v_sn
	from   dual;
	cs_assy_transfer(tlineid, tstageid, tprocessid, tterminalid, v_sn, tnow, tres, temp, trev);

end;


/

