create procedure       cs_chk_kps_limite(trev in varchar2
												   ,tres out varchar2) is
begin
	tres := 'OK';
	if not ((substr(trev, 1, 1) >= 'A') and (substr(trev, 1, 1) <= 'Z')) then
		tres := 'A,CSN RULE NOT MATCH!!';
		goto endp; --*****GOTO ENDP*****
	end if;


	for i in 2 .. length(trev) loop
		if not (((substr(trev, i, 1) >= '0') and (substr(trev, i, 1) <= '9'))) then
			tres := '1,CSN RULE NOT MATCH!!';
			goto endp; --*****GOTO ENDP*****
		end if;
	end loop;

	<<endp>>
	null;

exception
	when others then
		tres := 'SAJET.cs_chk_kps_limite error';
end;


/

