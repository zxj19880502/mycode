create function       Convert_TT_To_Ten(TT in varchar2) return number is
--10？？？33？？(10？？？？26？？？(I.O.S？？))
stt varchar2(12) ;--33？？？？？
sremainder varchar2(2);--？？
nremainder number;
squotient varchar2(2);--？
nquotient number;
bytes varchar2(33);
ttlength number;
idx number;
res number;
str varchar2(1);
begin
  ttlength:=0;
  res:=0;
  select length(TT) into ttlength from dual;
  bytes:='0123456789ABCDEFGHJKLMNPQRTUVWXYZ';
  for i in 1..ttlength
    loop
      str:=substr(TT,i,1);--？？？？？？？
      idx:=INSTR(bytes,str,1,1)-1;--？？？？？？？？？？？？
      res:=res+idx*33**(ttlength-i);
    end loop;
 return res;
end;


/

