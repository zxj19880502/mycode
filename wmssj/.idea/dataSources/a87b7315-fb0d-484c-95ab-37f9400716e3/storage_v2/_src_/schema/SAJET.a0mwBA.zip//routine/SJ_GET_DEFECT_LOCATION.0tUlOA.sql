create function        sj_get_defect_location(trecid in number) return varchar2 is
	c_i number;
	k   varchar2(300);
	v   varchar2(100);
	cursor defectlc is
		select nvl(location, ' ') location
		from   sajet.g_sn_repair_location
		where  recid = trecid and reason_id is null
		group  by location;
	cur_lc defectlc%rowtype;
begin
	k := ' ';
	for cur_lc in defectlc loop
		if (cur_lc.location <> ' ') then
			k := k;
			k := k || cur_lc.location;
		end if;
		if (k <> ' ') and (cur_lc.location <> ' ') then
			k := k || ',';
		end if;
		k := ltrim(k);
	end loop;
	return k;
end;


/

