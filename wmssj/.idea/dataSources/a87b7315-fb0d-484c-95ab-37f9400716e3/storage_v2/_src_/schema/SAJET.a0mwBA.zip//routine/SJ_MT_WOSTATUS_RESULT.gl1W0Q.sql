create function       
       SJ_MT_WOStatus_Result(svalue in varchar2) return varchar2 is
str varchar2(16); s number; i number;
begin
  if svalue = '0' then
    str := 'Initial';
  elsif svalue = '1' then
    str := 'Off-Line';
  elsif svalue = '2' then
    str := 'Complete';
  else
    str := 'N/A';
  end if;

  return str;
end;


/

