create procedure       csbg_repair(trev        in varchar2
											 ,tdefect     in varchar2
											 ,tnow        in date
											 ,temp        in varchar2
											 ,tterminalid in number
											 ,tres        out varchar2
											 ,tnextproc   out varchar2) is
	cnext_processid number;
begin
	--紀錄收到待修品時間
	if tdefect = 'N/A' then
		sajet.csbg_repair_time(trev, tnow, tres);
	else
		--補DEFECT 紀錄
		sajet.csbg_chk_sn_in_repair(trev, tres, cnext_processid);
		if tres = 'OK' then
			sajet.csbg_function_error_go(tterminalid, trev, tdefect, tnow, temp, tres, tnextproc, cnext_processid);
			tnextproc := '';
		end if;
	end if;
exception
	when others then
		tres := 'CSBG_CHK_SHIPPING_OUT error';
end;


/

