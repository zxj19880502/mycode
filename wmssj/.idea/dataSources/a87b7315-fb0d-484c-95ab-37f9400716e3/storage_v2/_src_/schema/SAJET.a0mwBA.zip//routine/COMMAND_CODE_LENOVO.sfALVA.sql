create procedure command_code_lenovo(tlineid     in number
											   ,tstageid    in number
											   ,tprocessid  in number
											   ,tterminalid in number
											   ,tnow        in date
											   ,trev        in varchar2
											   ,tres        out varchar2
											   ,tnextproc   out varchar2) is
	tsajet1      varchar2(25);
	tsajet2      varchar2(40);
	tsajet3      varchar2(256);
	tsajet4      varchar2(256);
	tsajet4ton   varchar2(4096);
	tsajet5ton   varchar2(4096);
	c_buffer     varchar2(4096);
	c_head       number;
	cmd          number;
	c_number     number;
	c_start      number;
	c_end        number;
	c_psn        varchar2(35);
	c_temp       varchar2(255);
	c_item       sajet.sys_spc.spc_item%type;
	c_value      sajet.g_spc.spc_value%type;
	c_defect     sajet.sys_defect.defect_code%type;
	c_wo         sajet.g_sn_status.work_order%type;
	c_wo_seq     smt.g_wo_msl.wo_sequence%type;
	c_datecode   smt.g_smt_status.datecode%type;
	c_dbid       varchar2(20);
	c_type       number;
	c_eventid    number;
	t_type       varchar2(25);
	check_status varchar2(10);
	msl_status   varchar2(30);
	c_factory    number;
	cnt          number;
	cnt2         number;
	cvalue       number;
begin
	tres := 'Fail,Command fail';
	/*   IF SUBSTR(TREV, LENGTH(TREV), 1) = ';' THEN
       c_Buffer := TREV;
    ELSE
       c_Buffer := TREV || ';';
    END IF;
    
    c_Number := 1;
    c_Start := 1;
    c_End := INSTR (c_Buffer, ';', c_Start, c_Number);
    
    IF C_End <= 3 THEN
    BEGIN
       cmd := SUBSTR(c_Buffer, c_Start, C_End-c_Start);
       c_Number := c_Number + 1;
       c_Start := c_End + 1;
    EXCEPTION
       WHEN OTHERS THEN
          cmd := 999;
    END;
    ELSE
       cmd := 999;
    END IF;*/
	select count(*) into cnt from table(f_cus_split(trev, ';'));
	cmd := to_number(trim(f_cus_splitstr(trev, 1, ';'))); --獲取cmd

	if cmd = 1 --檢查用戶
	 then
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;PWD]' || trev || '[' || cnt || ']';
		else
		
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';'));
		
			sajet.sj_cksys_emp(tsajet2, tres);
			if tres = 'OK' then
				select trim(password.decrypt(passwd)) into c_temp from sajet.sys_emp where emp_no = tsajet2;
				if c_temp <> tsajet3 then
					tres := 'NG;密碼錯誤!';
				else
					tres := 'OK;OK;';
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 2 --大小板關聯    檢查大板SN
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --SN
			sajet.map_ckrt_sn(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				sajet.sj_ckrt_route(tterminalid, tsajet2, tres);
			end if;
		end if;
	elsif cmd = 3 then
		--大小板關聯    檢查小板SN
		if cnt < 3 then
			tres := 'NG格式錯誤![大板SN;小板SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --大板SN
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';')); --小板SN
			sajet.cus_ckrt_ssn_rule(tsajet3, tsajet2, tres);
			/*if substr(tres,1,2)='OK' then
              SAJET.MAP_SPLIT_SN_1(tsajet3,tsajet2,tterminalid
            end if;*/
		end if;
	elsif cmd = 4 then
		--大小板關聯
		if cnt < 5 then
			tres := 'NG格式錯誤![工號;大板SN;小板SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --emp
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';')); --大板SN
		
			select instr(trev, ';', 1, 3) into c_number from dual; --獲取第3個分號的位置;
			tsajet4 := trim(substr(trev, c_number + 1, length(trev) - c_number)); --小板SN List
			select rtrim(tsajet4, ';') into tsajet4 from dual; --去掉右邊的分號
		
			cus_dipmapping_cmd(tsajet4, tsajet3, tterminalid, tsajet2, tres);
		end if;
	elsif cmd = 5 --根據SN獲取大小板關聯的所有SN
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --SN
			select count(serial_number) into cnt from g_sn_status a where a.old_sn = tsajet2;
			if cnt = 0 then
				tres := 'NG;SN [' || tsajet2 || '] 不存在!';
			else
				select wm_concat(serial_number)
				into   c_temp
				from   (select serial_number from g_sn_status a where a.old_sn = tsajet2 order by serial_number);
				tres := 'OK;' || c_temp;
			end if;
		end if;
	elsif cmd = 6 then
		--首測站數據上傳
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --emp
			sajet.sj_cksys_emp(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				select instr(trev, ';', 1, 2) into c_number from dual;
				tsajet3 := trim(substr(trev, c_number + 1, length(trev) - c_number));
			
				cus_dipaoi_upload1(tsajet2, tsajet3, tterminalid, tprocessid, tres, 'Y');
			else
				tres := tres || tsajet2;
			end if;
		end if;
	elsif cmd = 7 then
		--複測站數據上傳
		if cnt < 3 then
			tres := 'NG;格式錯誤![EMP;SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --emp
			sajet.sj_cksys_emp(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				select instr(trev, ';', 1, 2) into c_number from dual;
				tsajet3 := trim(substr(trev, c_number + 1, length(trev) - c_number));
			
				cus_dipaoi_upload1(tsajet2, tsajet3, tterminalid, tprocessid, tres, 'N');
			else
				tres := tres || tsajet2;
			end if;
		end if;
	else
		tres := 'NG;[EC102] COMMAND NOT DEFINE.;';
	end if;

	if substr(tres, 1, 2) = 'OK' and length(tres) < 5 then
		tres := 'OK;' || tres;
	end if;
exception
	when others then
		tres := trev || '[' || sqlerrm || ']';
end;
/

