create PROCEDURE Add_Location_Content(cartonno in varchar2,locationno OUT VARCHAR2,res out varchar2)IS
partid number;
BEGIN
  res := 'Y';
  locationno:='N/A';
  partid:=0;
          select pc.part_id INTO partid FROM SAJET.g_Pack_Carton pc WHERE pc.carton_no=cartonno;--？？？？？？？？partid
          begin--？？？？？？？partid
             select ls.location_no into locationno from sajet.g_location_status ls where ls.part_id=partid for update;--？？？？？？？？？？？？partid
             insert into sajet.g_location_content(location_no,carton_no)values(locationno,cartonno); --？？？,？？？？？？？g_location_content？
              commit;
         exception
                when NO_DATA_FOUND then--？？？？？？？？？？？？
                  begin--？？？？？？？？？？？partid
                     select ls.location_no into locationno from sajet.g_location_status ls where ls.part_id is null and rownum=1 order by ls.location_no;--？？？？？？？？
                     update  sajet.g_location_status ls set ls.part_id=partid where ls.location_no=locationno;--？？？？？？
                       insert into sajet.g_location_content(location_no,carton_no)values(locationno,cartonno); --？？？？？？？g_location_content？
                     commit;
                  exception
                    when NO_DATA_FOUND then--？？？？？
                         res:='No empty location for new partid';
                         rollback;
                     when others then
                       res:=SQLERRM;
                       rollback;
                  end;
                WHEN OTHERS THEN--？？？？
                  begin
                      rollback;
                      res:=SQLERRM;
                  end;
          end;
exception
  when NO_DATA_FOUND then
  res:='No partid match this cartonno';
  WHEN OTHERS THEN
  res:=SQLERRM;
end;


/

