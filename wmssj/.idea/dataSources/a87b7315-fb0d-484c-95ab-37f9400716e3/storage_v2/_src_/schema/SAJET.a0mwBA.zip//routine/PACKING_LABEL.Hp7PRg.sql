create FUNCTION       packing_label(label_type in varchar2, pack_type in varchar2,
  pack_value in varchar2) return varchar2
is l_str varchar2(255) default NULL; p_dec number; p_type varchar2(1);
begin
  if label_type = 'Pallet' then
    select SAJET.S_PK_PLT_CODE.NEXTVAL into p_dec from dual;
    p_type := 'P';
  elsif label_type = 'Carton' then
    select SAJET.S_PK_CTN_CODE.NEXTVAL into p_dec from dual;
    p_type := 'C';
  elsif label_type = 'Box' then
    select SAJET.S_PK_BOX_CODE.NEXTVAL into p_dec from dual;
    p_type := 'B';
  else
    select SAJET.S_PK_CSN_CODE.NEXTVAL into p_dec from dual;
    p_type := 'S';
  end if;
  select p_type || trim(to_char(sysdate,'yiw')) || Translate(lpad(sajet.to_base(p_dec, 32),4),' ','0') into l_str from dual;
  return l_str;
end;


/

