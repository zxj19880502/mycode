create FUNCTION       ALARM_LEVEL(svalue in varchar2) return varchar2 is
str varchar2(16); s number; i number;
begin
  if svalue = '0' then
    str := 'Critical';
  elsif svalue = '1' then
    str := 'Major';
  elsif svalue = '2' then
    str := 'Minor';
  elsif svalue='3' then
    str :='Notice';
  else
    str := '';
  end if;
  return str;
end;


/

