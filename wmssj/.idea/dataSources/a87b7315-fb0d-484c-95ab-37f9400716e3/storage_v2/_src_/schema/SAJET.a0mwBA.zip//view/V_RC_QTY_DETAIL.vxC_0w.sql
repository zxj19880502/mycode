create view V_RC_QTY_DETAIL as
  select S.WORK_ORDER,
               B.PART_NO,
               e.route_name,
               P.PROCESS_NAME,
               sum(s.CURRENT_QTY) WIP_QTY,
               B.PART_ID,
               P.PROCESS_ID,
               S.CURRENT_QTY,
               S.RC_NO,
               case
                 when S.IN_PROCESS_TIME is not null AND
                      S.OUT_PROCESS_TIME is null then
                  '待产出'
                 when S.IN_PROCESS_TIME is not null AND
                      S.OUT_PROCESS_TIME is NOT null /*and S.CURRENT_STATUS = 9*/
                  then
                  '已产出'

               end 生产阶段,
               DECODE(S.CURRENT_STATUS,
                      0,
                      '正常',
                      1,
                      '报废',
                      2,
                      '异常放行',
                      3,
                      '锁定',
                      4,
                      '重工') 状态
          FROM SAJET.G_RC_STATUS  S,
               sajet.sys_rc_route e,
               sajet.sys_part     b,
               sajet.g_wo_base    C,
               sajet.SYS_PROCESS  P
         WHERE S.PART_ID = B.PART_ID
           AND S.PROCESS_ID = P.PROCESS_ID
           AND S.ROUTE_ID = E.ROUTE_ID
           and S.WORK_ORDER = C.WORK_ORDER
           and c.WO_OPTION2 = 1
           AND S.IN_PROCESS_TIME is not null
           AND S.OUT_PROCESS_TIME is null --'待产出'
         GROUP BY S.WORK_ORDER,
                  B.PART_NO,
                  e.route_name,
                  P.PROCESS_NAME,
                  B.PART_ID,
                  P.PROCESS_ID,
                  S.CURRENT_QTY,
                  S.RC_NO,
                  S.CURRENT_STATUS,
                  S.IN_PROCESS_TIME,
                  S.OUT_PROCESS_TIME,
                  s.CURRENT_STATUS
        union all
        select S.WORK_ORDER,
               B.PART_NO,
               e.route_name,
               P.PROCESS_NAME,
               sum(s.CURRENT_QTY) WIP_QTY,
               B.PART_ID,
               P.PROCESS_ID,
               S.CURRENT_QTY,
               S.RC_NO,
               case
                 when S.IN_PROCESS_TIME is not null AND
                      S.OUT_PROCESS_TIME is null then
                  '已投入'
                  when S.IN_PROCESS_TIME is not null AND
                      S.OUT_PROCESS_TIME is not null and s.current_qty=0 then
                  '已用完'
                 when S.IN_PROCESS_TIME is not null AND
                      S.OUT_PROCESS_TIME is NOT null /*and S.CURRENT_STATUS = 9*/
                  then
                  '待投入'
               end 生产阶段,
               DECODE(S.CURRENT_STATUS,
                      0,
                      '正常',
                      1,
                      '报废',
                      2,
                      '异常放行',
                      3,
                      '锁定',
                      4,
                      '重工') 状态
          FROM SAJET.G_RC_STATUS  S,
               sajet.sys_rc_route e,
               sajet.sys_part     b,
               sajet.g_wo_base    C,
               sajet.SYS_PROCESS  P
         WHERE S.PART_ID = B.PART_ID
           AND S.NEXT_PROCESS = P.PROCESS_ID
           AND S.ROUTE_ID = E.ROUTE_ID
           and S.WORK_ORDER = C.WORK_ORDER
           and c.WO_OPTION2 = 1
           and S.CURRENT_STATUS<>1
           /*and S.CURRENT_QTY<>0*/
           AND S.IN_PROCESS_TIME is not null
           AND S.OUT_PROCESS_TIME is NOT null --'待投入'
         GROUP BY S.WORK_ORDER,
                  B.PART_NO,
                  e.route_name,
                  P.PROCESS_NAME,
                  B.PART_ID,
                  P.PROCESS_ID,
                  S.CURRENT_QTY,
                  S.RC_NO,
                  S.CURRENT_STATUS,
                  S.IN_PROCESS_TIME,
                  S.OUT_PROCESS_TIME,
                  s.CURRENT_STATUS
        UNION ALL
        select S.WORK_ORDER,
               B.PART_NO,
               e.route_name,
               P.PROCESS_NAME,
               sum(s.CURRENT_QTY) WIP_QTY,
               B.PART_ID,
               P.PROCESS_ID,
               S.CURRENT_QTY,
               S.RC_NO,
               case
                 when S.IN_PROCESS_TIME is not null AND
                      S.OUT_PROCESS_TIME is null then
                  '待产出'
                 when S.IN_PROCESS_TIME is not null AND
                      S.OUT_PROCESS_TIME is NOT null /*and S.CURRENT_STATUS = 9*/
                  then
                  '已产出'
               end 生产阶段,
               DECODE(S.CURRENT_STATUS,
                      0,
                      '正常',
                      1,
                      '报废',
                      2,
                      '异常放行',
                      3,
                      '锁定',
                      4,
                      '重工') 状态
          FROM SAJET.G_RC_STATUS  S,
               sajet.sys_rc_route e,
               sajet.sys_part     b,
               sajet.g_wo_base    C,
               sajet.SYS_PROCESS  P
         WHERE S.PART_ID = B.PART_ID
           AND S.PROCESS_ID = P.PROCESS_ID
           AND S.ROUTE_ID = E.ROUTE_ID
           and S.WORK_ORDER = C.WORK_ORDER
           and c.WO_OPTION2 = 1
           and S.CURRENT_STATUS = 1
           AND S.IN_PROCESS_TIME is not null
           AND S.OUT_PROCESS_TIME is NOT null
          GROUP BY S.WORK_ORDER,
                  B.PART_NO,
                  e.route_name,
                  P.PROCESS_NAME,
                  B.PART_ID,
                  P.PROCESS_ID,
                  S.CURRENT_QTY,
                  S.RC_NO,
                  S.CURRENT_STATUS,
                  S.IN_PROCESS_TIME,
                  S.OUT_PROCESS_TIME,
                  s.CURRENT_STATUS


/

