create procedure       csbg_assy_kpsn_by_rule(trev        in varchar2
														,tterminalid in number
														,tsn         in varchar2
														,tprocessid  in number
														,u_partno    out varchar2
														,u_partid    out varchar2
														,u_partsn    out varchar2
														,tres        out varchar2) as
begin
	--檢查KPSN是否符合設定的規則,並傳出PARTID,PARTNO,PARTSN
	sajet.csbg_assy_chk_part_rule(tprocessid, trev, tsn, u_partno, u_partid, u_partsn, tres);
	--檢查KPNO是否在BOM表內
	if tres = 'OK' then
		sajet.sj_assy_chk_sn_kp(tprocessid, tsn, u_partno, u_partid, tres);
	end if;
	--檢查KPSN是否可用
	if tres = 'OK' then
		sajet.sj_assy_chk_kpsn(trev, tres);
	end if;
end;


/

