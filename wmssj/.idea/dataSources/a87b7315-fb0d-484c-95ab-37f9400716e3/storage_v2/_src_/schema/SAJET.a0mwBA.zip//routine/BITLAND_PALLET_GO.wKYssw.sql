create PROCEDURE       BITLAND_PALLET_GO(TPACKACTION in varchar2,TREV in varchar2,TPALLET in varchar2,TTREMINALID in varchar2,TEMPNO in varchar2,TRES out varchar2)IS
nextprocess varchar2(30);
empid number;
psn varchar2(80);
cursor sn_carton_cursor is
   select serial_number
     from sajet.g_sn_status
       where carton_no = TREV;
sn_carton_record sn_carton_cursor%rowtype;
cursor sn_box_cursor is
   select serial_number
     from sajet.g_sn_status
       where box_no = TREV;
sn_box_record sn_box_cursor%rowtype;
--sncount number;
BEGIN
  TRES:='OK';
 -- nextprocess:='N/A';
  --sncount:=0;
  if TREV is null then
    TRES:='SN Or Carton is null';
    return;
 elsif TPACKACTION is null then
      TRES:='Pack Action Is NUll';
      return;
  elsif TPALLET is null then
    TRES:='Pallet is Null';
    return;
  elsif TTREMINALID is null then
    TRES:='Terminal ID is null';
    return;
  elsif TEMPNO is  null then
    TRES:='Emp no is null';
    return;
  end if;

  sajet.Sj_Get_Empid(TEMPNO,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMPNO||')';
    return;
  end if;
    --select count(*) into sncount from sajet.g_sn_status ss where ss.serial_number=TSN;
  /*  if sncount=0 then
      TRES:='No this sn('||TSN||') record';
      return;
    end if;
   */
  if TPACKACTION='CARTON->PALLET' then
    UPDATE SAJET.G_SN_STATUS SET PALLET_NO = TPALLET
     WHERE CARTON_NO = TREV;
     for sn_carton_record in sn_carton_cursor loop
         sajet.sj_ckrt_sn_psn(sn_carton_record.serial_number,TRES,psn);
         if SUBSTR(TRES,1,2)='OK' then
          sajet.sj_go(TTREMINALID,sn_carton_record.serial_number,sysdate,TRES,TEMPNO);
              if SUBSTR(TRES,1,2)!='OK' then
                rollback;
                return;
              end if;
         else
           return;
          end if;
     end loop;

     commit;
     elsif TPACKACTION='BOX->PALLET' then
      for sn_box_record in sn_box_cursor loop
         sajet.sj_ckrt_sn_psn(sn_box_record.serial_number,TRES,psn);
         if TRES='OK' then
          sajet.sj_go(TTREMINALID,sn_box_record.serial_number,sysdate,TRES,TEMPNO);
              if TRES!='OK' then
                rollback;
                return;
              end if;
         else
           return;
          end if;
     end loop;
     UPDATE SAJET.G_SN_STATUS SET PALLET_NO = TPALLET
     WHERE box_no = TREV;
     commit;
   elsif TPACKACTION='SN->PALLET' then
      sajet.sj_ckrt_sn_psn(TREV,TRES,psn);
         if TRES='OK' then
          sajet.sj_go(TTREMINALID,TREV,sysdate,TRES,TEMPNO);
              if TRES!='OK' then
                rollback;
                return;
              end if;
         else
           return;
          end if;
       UPDATE SAJET.G_SN_STATUS SET PALLET_NO = TPALLET
       WHERE serial_number = TREV;
       commit;
   else
         TRES:='UnKnown Pack Action:'||TPACKACTION;
   end if;
exception
  WHEN OTHERS THEN
   rollback;
  TRES:=SQLERRM;
end;


/

