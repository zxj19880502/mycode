create procedure       cs_cancel_kps(tlineid     in number
											   ,tstageid    in number
											   ,tprocessid  in number
											   ,tterminalid in number
											   ,tsn         in varchar2
											   ,tres        out varchar2
											   ,trev        in varchar2
											   ,pempid      in number
											   ,tnow        in date) is
	csn        sajet.g_sn_status.customer_sn%type;
	c_line     number;
	c_stage    number;
	c_process  number;
	c_terminal number;
	c_now      date;
	c_emp      number;
begin
	select customer_sn, pdline_id, stage_id, process_id, terminal_id, out_process_time, emp_id
	into   csn, c_line, c_stage, c_process, c_terminal, c_now, c_emp
	from   sajet.g_sn_status
	where  serial_number = tsn and rownum = 1;
	if trev = csn then
		update sajet.g_sn_status
		set    customer_sn = 'N/A', emp_id = pempid, out_process_time = tnow, pdline_id = tlineid, stage_id = tstageid,
			   process_id = tprocessid, terminal_id = tterminalid
		where  serial_number = tsn and rownum = 1;
	
		insert into sajet.g_sn_travel
			select * from sajet.g_sn_status where serial_number = tsn and rownum = 1;
	
		update sajet.g_sn_status
		set    emp_id = c_emp, out_process_time = c_now, pdline_id = c_line, stage_id = c_stage, process_id = c_process,
			   terminal_id = c_terminal
		where  serial_number = tsn and rownum = 1;
	
		tres := 'OK';
	else
		tres := 'KPS NG';
	end if;
exception
	when others then
		tres := 'cs_cancel_kps error';
end;


/

