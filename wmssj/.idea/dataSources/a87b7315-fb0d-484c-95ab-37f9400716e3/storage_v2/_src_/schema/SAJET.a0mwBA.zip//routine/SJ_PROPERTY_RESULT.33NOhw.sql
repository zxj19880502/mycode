create function 
       SJ_Property_Result(svalue in varchar2,stype in number) return varchar2 is
str varchar2(16);
begin
  if stype =1 then
     if svalue='V' then
      str := '文字';
     elsif svalue='N' then
      str := '数字';
      end if;
  elsif stype=2 then
     if svalue='K' then
      str := '输入值';
     elsif svalue='S' then
      str := '列表';
     elsif svalue='R' then
      str := '范围';
      end if;
  elsif stype=3 then
     if svalue='Y' then
      str := '必要的';
     elsif svalue='N' then
      str := '不必要的';
      end if;
  elsif stype=4 then
     if svalue='N' then
      str := '不转换';
     elsif svalue='U' then
      str := '转大写';
     elsif svalue='L' then
      str := '转小写';
      end if;
  else
    str := 'N/A';
  end if;

  return str;
end;


/

