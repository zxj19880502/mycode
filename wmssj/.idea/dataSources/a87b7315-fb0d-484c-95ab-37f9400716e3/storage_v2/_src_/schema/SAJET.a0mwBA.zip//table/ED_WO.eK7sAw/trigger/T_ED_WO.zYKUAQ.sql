create trigger T_ED_WO
  before insert
  on ED_WO
  for each row
DECLARE
  C_WOID     VARCHAR2(50);
  C_PARTID   NUMBER;
  C_PARTNAME VARCHAR2(50);
  C_STATUS VARCHAR2(2);
BEGIN
  :NEW.LOG := 'OK';
  BEGIN
    BEGIN
      SELECT PART_ID
        INTO C_PARTID
        FROM SAJET.SYS_PART
       WHERE PART_NO = :NEW.WO_PART;
    EXCEPTION
      WHEN OTHERS THEN
        :NEW.LOG := '廠內料號不存在';
        RETURN;
    END;
    SELECT WO_STATUS
      INTO C_STATUS
      FROM SAJET.G_WO_BASE
     WHERE WORK_ORDER = :NEW.WO_ID;
    BEGIN
      IF C_STATUS='0' THEN 
      UPDATE SAJET.G_WO_BASE
         SET PART_ID       = C_PARTID,
             TARGET_QTY    = :NEW.WO_QTY,
             WO_START_DATE = TO_DATE(:NEW.WO_REL_DATE, 'yyyy/mm/dd'),
             WO_STATUS     = '0',
             MASTER_WO     = :NEW.WO,
             REMARK        = :NEW.WO_SPEC,
             WO_DUE_DATE   = TO_DATE(:NEW.WO_EXPIRE_DATE, 'yyyy/mm/dd'),
             SALES_ORDER   = :NEW.WO_VENDOR,
             PO_NO=:NEW.WO_SO_JOB,
             WO_OPTION10   = :NEW.WO_ORG_CUSTOMER_PART
       WHERE WORK_ORDER = :NEW.WO_ID;
       ELSE
         :NEW.LOG := '非0狀態工單無法修改';
       END IF;
    EXCEPTION
      WHEN OTHERS THEN
        :NEW.LOG := SQLERRM;
        RETURN;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      INSERT INTO SAJET.G_WO_BASE
        (WORK_ORDER,
         PART_ID,
         TARGET_QTY,
         WO_START_DATE,
         WO_STATUS,
         MASTER_WO,
         REMARK,
         WO_DUE_DATE,
         SALES_ORDER,
         PO_NO,
         WO_OPTION10,
         FACTORY_ID)
      VALUES
        (:NEW.WO_ID,
         C_PARTID,
         :NEW.WO_QTY,
         TO_DATE(:NEW.WO_REL_DATE, 'yyyy/mm/dd'),
         '0',
         :NEW.WO,
         :NEW.WO_SPEC,
         TO_DATE(:NEW.WO_EXPIRE_DATE, 'yyyy/mm/dd'),
         :NEW.WO_VENDOR,
         :NEW.WO_SO_JOB,
         :NEW.WO_ORG_CUSTOMER_PART,
         '10010');
  END;
EXCEPTION
  WHEN OTHERS THEN
    :NEW.LOG := SQLERRM;
END;


/

