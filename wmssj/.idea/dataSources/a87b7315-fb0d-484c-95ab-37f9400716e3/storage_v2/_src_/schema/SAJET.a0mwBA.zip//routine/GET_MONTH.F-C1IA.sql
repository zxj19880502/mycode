create function get_month(csn in varchar2) return varchar2 is
	--month1 varchar2(200);
	data1  varchar2(200);
	data2  varchar2(200);
	data3  varchar2(200);
	ccount number;
begin

	select count(*) into ccount from sajet.g_sn_customersn2 a where serial_number = csn or customer_sn = csn;
	if ccount = 0 then
		data3 := '';
		goto endp;
	end if;
	select to_char(out_process_time, 'MM')
	into   data2
	from   sajet.g_sn_customersn2
	where  customer_sn = csn or serial_number = csn;

	--select to_char(to_date(data1, 'yyyy-mm-dd hh24:mi:ss'), 'MM') into data2 from dual;
	if data2 = 01 then
		data3 := 'JAN';
	elsif data2 = 02 then
		data3 := 'FEB';
	elsif data2 = 03 then
		data3 := 'MAR';
	elsif data2 = 04 then
		data3 := 'APR';
	elsif data2 = 05 then
		data3 := 'MAY';
	elsif data2 = 06 then
		data3 := 'JUN';
	elsif data2 = 07 then
		data3 := 'JUL';
	elsif data2 = 08 then
		data3 := 'AUG';
	elsif data2 = 09 then
		data3 := 'SEP';
	elsif data2 = 10 then
		data3 := 'OCT';
	elsif data2 = 11 then
		data3 := 'NOV';
	elsif data2 = 12 then
		data3 := 'DEC';
	end if;
	<<endp>>
	return data3;
exception
	when others then
		return sqlerrm;
end;
/

