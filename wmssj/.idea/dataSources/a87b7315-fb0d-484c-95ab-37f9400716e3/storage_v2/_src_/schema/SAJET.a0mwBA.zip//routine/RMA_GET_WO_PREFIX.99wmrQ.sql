create function       
  RMA_GET_WO_PREFIX(TWO IN VARCHAR2) return boolean is
begin
  IF (SUBSTR(TWO,1,3) ='RMA') THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
end;


/

