create FUNCTION splitclob_new(p_string IN clob, p_delimiter IN VARCHAR2)
RETURN str_split
PIPELINED
AS
C_TEMP_CLOB CLOB;
C_ITEMTEMP  VARCHAR2(100);
lnum number;

BEGIN
  lnum:=1;
  C_TEMP_CLOB:=p_string;
LOOP
   EXIT WHEN DBMS_LOB.GETLENGTH(C_TEMP_CLOB)<=lnum ;
   -- b:=DBMS_LOB.INSTR(C_TEMP_CLOB, p_delimiter,lnum)-lnum;
    C_ITEMTEMP  :=  DBMS_LOB.substr(C_TEMP_CLOB,DBMS_LOB.INSTR(C_TEMP_CLOB, p_delimiter,lnum)-lnum,lnum);
    lnum:=lnum+(LENGTH(C_ITEMTEMP)+1);
    PIPE ROW(C_ITEMTEMP);

END LOOP;

RETURN;
END splitclob_new;


/

