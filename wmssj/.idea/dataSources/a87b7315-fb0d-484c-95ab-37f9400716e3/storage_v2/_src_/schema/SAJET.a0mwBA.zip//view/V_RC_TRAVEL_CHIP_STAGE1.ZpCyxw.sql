create view V_RC_TRAVEL_CHIP_STAGE1 as
select s2.rc_no,
       (case when s1.rc_no is not null then s1.work_order else s2.work_order end) work_order,
       (case when s1.rc_no is not null then s1.current_qty else s2.current_qty end) current_qty,
       (case when s1.rc_no is not null then s1.create_time else s2.create_time end) create_time,
       (case when s1.rc_no is not null then s1.part_id else s2.part_id end) part_id
  from (select rc_no, work_order, current_qty, create_time, part_id
          from (select rc_no, work_order, current_qty, create_time, part_id,
                       row_number() over(partition by rc_no order by travel_id) flag
                  from (select rc_no, a.work_order, current_qty, create_time, a.part_id, a.travel_id
                          from sajet.g_rc_travel a, sajet.g_wo_base b
                         where a.work_order = b.work_order
                           and b.wo_option10 = 1
                           and a.create_time is not null
                           and a.rc_no not like '%.%'))
         where flag = 1) s1,
       (select rc_no, a.work_order, current_qty, create_time, a.part_id, a.travel_id
          from sajet.g_rc_status a, sajet.g_wo_base b
         where a.work_order = b.work_order
           and b.wo_option10 in (1, 2)
           and a.create_time is not null
           and a.rc_no not like '%.%') s2
 where s2.rc_no = s1.rc_no(+)


/

