create function       
       RMA_SN_STATUS(svalue in varchar2) return varchar2 is
str varchar2(16);
begin
  if svalue = '0' then
    str := 'Register';
  elsif svalue = '1' then
    str := 'Receive';
  elsif svalue = '2' then
    str := 'WIP';
  elsif svalue = '4' then
    str := 'Packed';
  elsif svalue = '5' then
    str := 'Return';
  elsif svalue = '3' then
    str :='Finish';
  elsif svalue = 'N/A' then
    str := 'N/A';
  else
    str := 'Unknown';
  end if;
  return str;
end;


/

