create view CP_SN_LASTINFOR as
select a.part_id,
       a.process_id,
       a.out_process_shift,
       a.wip_out_time,
       a.serial_number,
       a.out_process_time,
       row_number() over(partition by a.process_id, a.serial_number order by a.out_process_time desc) rank,
       a.current_status
  from sajet.base_sn_travel a
 where to_char(a.riqi,'yyyymmdd' )= to_char(SYSDATE - 8.5/24,'yyyymmdd')


/

