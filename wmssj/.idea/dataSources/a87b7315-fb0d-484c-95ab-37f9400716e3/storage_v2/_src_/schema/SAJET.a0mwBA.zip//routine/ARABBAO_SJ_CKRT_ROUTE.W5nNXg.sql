create procedure 
-- Modify 2018/04/13
arabbao_sj_ckrt_route(terminalid in varchar2, tsn in varchar2, tres out varchar2) as
	err_result      varchar2(1);
	current_process number;
	processid       number;
	routeid         number;
	workorder       varchar2(25);
	nextprocess     number;
	routename       varchar2(50);
	inputprocess    number;
	nextprocessname varchar2(50);
	processname     varchar2(50);
	v_sn            varchar2(100);
begin
	select nvl((select s.serial_number from sajet.g_sn_status s where s.serial_number = tsn or s.customer_sn = tsn), '')
	into   v_sn
	from   dual;

	select current_status, a.process_id, c.process_name pname, work_order, route_id, next_process, b.process_name
	into   err_result, current_process, processname, workorder, routeid, nextprocess, nextprocessname
	from   sajet.g_sn_status a, sajet.sys_process b, sajet.sys_process c
	where  /* CUSTOMER_SN = TSN OR */
	 serial_number = v_sn and a.next_process = b.process_id(+) and a.process_id = c.process_id(+) and rownum = 1;
	select process_id into inputprocess from sajet.sys_terminal where terminal_id = terminalid and rownum = 1;
	if (nextprocess is null) or (nextprocess = 0) then
		if current_process = 0 then
			select start_process_id into processid from sajet.g_wo_base where work_order = workorder and rownum = 1;
			if processid = inputprocess then
				tres := 'OK';
			else
				begin
					--  Modify 2005/04/28 -----------------------------------------
					--               SELECT NEXT_PROCESS_ID,B.PROCESS_NAME
					--                 INTO ProcessID,NextProcessName
					--                 FROM SAJET.SYS_ROUTE_DETAIL A,
					--                      SAJET.SYS_PROCESS B
					--                 WHERE ROUTE_ID = RouteID AND
					--                       A.NEXT_PROCESS_ID = B.PROCESS_ID And
					--                       A.SEQ = (SELECT MAX(SEQ)
					--                                FROM SAJET.SYS_ROUTE_DETAIL
					--                                WHERE PROCESS_ID=Current_Process AND
					--                                      ROUTE_ID = RouteID AND
					--                                      RESULT = Err_Result );
					---------------------------------------------------------------
					select process_name
					into   nextprocessname
					from   sajet.sys_process
					where  process_id = processid and rownum = 1;
					tres := nextprocessname;
				exception
					-- WHEN NO_DATA_FOUND THEN
					when others then
						select route_name into routename from sajet.sys_route where route_id = routeid and rownum = 1;
						if err_result = '0' then
							tres := 'WO Start Process NG';
						else
							tres := 'REPAIR NG';
						end if;
				end;
			end if;
		else
			begin
				select next_process_id
				into   processid
				from   sajet.sys_route_detail
				where  result = err_result and route_id = routeid and process_id = current_process and
					   next_process_id = inputprocess and rownum = 1;
				tres := 'OK';
			exception
				-- WHEN NO_DATA_FOUND THEN
				when others then
					begin
						select next_process_id, b.process_name
						into   processid, nextprocessname
						from   sajet.sys_route_detail a, sajet.sys_process b
						where  route_id = routeid and a.next_process_id = b.process_id and
							   a.seq =
							   (select max(seq)
								from   sajet.sys_route_detail
								where  process_id = current_process and route_id = routeid and result = err_result);
						tres := nextprocessname;
					exception
						-- WHEN NO_DATA_FOUND THEN
						when others then
							/*                     SELECT ROUTE_NAME INTO RouteName
                                                    FROM SAJET.SYS_ROUTE
                                                    WHERE ROUTE_ID = RouteID AND
                                                          ROWNUM = 1;
                            */
							if err_result = '0' then
								tres := 'ROUTE END (' || processname || ')';
							else
								tres := 'REPAIR NG';
							end if;
					end;
			end;
		end if;
	else
		if nextprocess = inputprocess then
			tres := 'OK';
		else
			tres := nextprocessname;
		end if;
	end if;
exception
	when others then
		tres := 'SN Error!!';
end;


/

