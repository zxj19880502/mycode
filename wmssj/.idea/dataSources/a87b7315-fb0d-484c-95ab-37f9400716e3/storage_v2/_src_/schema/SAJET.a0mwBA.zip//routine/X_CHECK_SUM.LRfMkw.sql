create FUNCTION       x_check_sum(svalue in varchar2) return varchar is
str varchar2(1); s varchar2(1); i number;
  l_hex varchar2(32) default '0123456789ABCDEFGHJKLMNPQRSTVWXY';
begin
  s := chr(124);
  for i in 1 .. length(svalue) loop
    if substr(svalue,i,1) <> 'X' then
      s := s + instr(l_hex,upper(substr(svalue,i,1)));
    else
       s := s + chr(124);
    end if;
  end loop;
  return s;
end;


/

