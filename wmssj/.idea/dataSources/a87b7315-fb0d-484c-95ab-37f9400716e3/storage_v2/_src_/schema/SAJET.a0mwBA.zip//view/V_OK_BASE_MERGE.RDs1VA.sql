create view V_OK_BASE_MERGE as
select a.wip_out_time,a.serial_number, b.rc_no,a.sizespec
from sajet.base_sn_travel a,sajet.g_rc_merge b
where
a.process_id = '100026'
and a.work_flag = 0
and a.current_status in (0,2)
and b.process_id = '100011'
and b.merge_rc_no = a.serial_number


/

