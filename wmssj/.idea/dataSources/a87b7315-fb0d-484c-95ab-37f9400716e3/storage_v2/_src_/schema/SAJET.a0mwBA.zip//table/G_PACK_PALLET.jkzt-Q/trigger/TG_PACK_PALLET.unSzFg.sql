create trigger TG_PACK_PALLET
  before update
  on G_PACK_PALLET
  for each row
declare
	-- local variables here
	n_cnt number;
begin
	select count(*) into n_cnt from sys_part p where p.part_id = :old.part_id and p.label_file = 'Y';
	if n_cnt > 0 then
		if (:old.close_flag <> :new.close_flag) and (:new.close_flag = 'Y') then
			insert into cus_packing_print
				(terminal_id, packing_code, packing_lev, record_time)
			values
				(:new.terminal_id, :new.pallet_no, 'P', sysdate);
		end if;
	end if;
end tg_pack_pallet;


/

