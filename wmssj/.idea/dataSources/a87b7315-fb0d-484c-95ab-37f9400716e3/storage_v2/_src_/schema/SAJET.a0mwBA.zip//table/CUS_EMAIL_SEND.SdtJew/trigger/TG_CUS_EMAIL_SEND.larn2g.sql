create trigger TG_CUS_EMAIL_SEND
  before insert
  on CUS_EMAIL_SEND
  for each row
declare
	-- local variables here
begin
	select sys_guid() into :new.keyid from dual;
	select replace(:new.email_addr, ',', ';') into :new.email_addr from dual;
end tg_cus_email_send;


/

