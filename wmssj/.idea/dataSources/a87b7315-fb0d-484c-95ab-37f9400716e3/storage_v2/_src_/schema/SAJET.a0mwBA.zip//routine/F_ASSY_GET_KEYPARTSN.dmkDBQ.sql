create FUNCTION F_ASSY_GET_KEYPARTSN(I_INPUT IN VARCHAR2)
  RETURN VARCHAR2 IS
  C_SEQ          VARCHAR2(5);
  C_ITEM_PART_SN VARCHAR2(60);
  C_RES          VARCHAR2(60);
  C_QTY          NUMBER;
  --------------------------------------------------------
  --CREATED BY : NANCY.ZHU (2017.1.16)
  --如果条码的数量为1,则返回条码本身;如果大于1,则拆分一次
  --------------------------------------------------------
BEGIN
  --检查输入SN的数量,如果为1,则不需要拆分,如果大于1,则拆出来
  SELECT REEL_QTY INTO C_QTY FROM SAJET.G_MATERIAL WHERE REEL_NO = I_INPUT;

  IF C_QTY = 1 THEN
    C_RES := I_INPUT;
  ELSE
    SELECT NVL(MAX(ITEM_PART_SN), '-1')
      INTO C_ITEM_PART_SN
      FROM SAJET.G_SN_KEYPARTS
     WHERE ITEM_PART_SN LIKE I_INPUT || '%';

    IF C_ITEM_PART_SN = '-1' THEN
      C_RES := I_INPUT || '-' ||'0001';
    ELSE
      C_SEQ := TO_CHAR(TO_NUMBER(SUBSTR(C_ITEM_PART_SN,
                                        LENGTH(C_ITEM_PART_SN) - 3)) + 1);
      C_RES := I_INPUT || '-' || LPAD(C_SEQ, 4, '0');
    END IF;
  END IF;

  RETURN C_RES;
EXCEPTION
  WHEN OTHERS THEN
    RETURN '-1';
END;


/

