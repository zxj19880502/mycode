create trigger TG_G_PDDMDASHBOARD_PROCESS
  before insert
  on G_PDDMDASHBOARD_PROCESS
  for each row
declare
	-- local variables here
begin
	select seq_g_pddmdashboard_process.nextval into :new.id from dual;
end tg_g_pddmdashboard_process;


/

