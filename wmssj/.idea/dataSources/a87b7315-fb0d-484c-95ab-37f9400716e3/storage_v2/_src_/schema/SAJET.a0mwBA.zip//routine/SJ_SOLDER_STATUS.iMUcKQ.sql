create function sj_solder_status(svalue in varchar2) return varchar2 is
	str varchar2(16);
begin

	/*F    入冰庫
    M    攪拌
    O    開封
    R    回冰
    S    報廢
    T    用完  ---下料时，没有余量，将锡膏状态修改为用完
    U    上料--开封状态才可以上料，或者锡膏是上料，但是物料那边是下料，还可以上，锡膏就不用修改状态了
    W    回溫*/

	if svalue = 'W' then
		str := 'Wait';
	elsif svalue = 'F' then
		str := 'Forzen';
	elsif svalue = 'S' then
		str := 'Scrap';
	elsif svalue = 'T' then
		str := 'Terminate';
	elsif svalue = 'M' then
		str := 'Mix';
	elsif svalue = 'U' then
		str := 'Used';
	elsif svalue = 'O' then
		str := 'Open';
	
	else
		str := 'Unknown';
	end if;
	return str;
end;
/

