create procedure       csbg_chk_wo_qty2(two  in varchar2
												  ,tres out varchar2) is
	cnt        number;
	cinputqqty number;

begin
	--select work_order into cwo from g_sn_status where serial_number=TREV;
	select target_qty into cnt from g_wo_base where work_order = two;
	select count(*) into cinputqqty from g_sn_status where work_order = two;
	if cinputqqty >= cnt then
		tres := 'OVER WO TARTGET QTY !!';
	else
		tres := 'OK(' || cinputqqty || ')';
	end if;
exception
	when others then
		tres := 'CSBG_CHK_WO_QTY error';
end;


/

