create FUNCTION       Wms_Get_Location(TPARTID   IN NUMBER,
                                            TDATECODE IN VARCHAR2,
                                            TPARAM    IN VARCHAR2,
                                            TWHID     IN NUMBER)
  RETURN STRING IS
  STR        VARCHAR2(100);
  C_DATECODE SAJET.WMS_STOCK.DATECODE%TYPE;
  C_LOCATION NUMBER;
  C_SQL      VARCHAR2(4000);
  C_FLAG     VARCHAR2(100);
  CPILOT     VARCHAR2(20);
  box_no     VARCHAR2(100);
  --先抓出工單退料或雜收的料
BEGIN
  -- 工單退料,雜收優先使用
  -- TDATECODE 強制使用此Date Code
  -- TPILOT 是否可使用特殊倉 Use_Flag = 3
  C_FLAG := 'AND USE_FLAG = 0 ';
  IF NVL(CPILOT, 'N') = 'Y' THEN
    C_FLAG := 'AND (USE_FLAG = 0 OR USE_FLAG = 3) ';
  END IF;
  --工單退料/雜收
  BEGIN
    IF TWHID IS NOT NULL THEN
      --如果指定仓库
      C_SQL := 'SELECT MIN(LOCATION_NO), DATECODE ' ||
               'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B, SAJET.WMS_LOCATION C ' ||
               'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID AND INTERFACE_TYPE IN (''WORETURN'',''IN'') ' ||
               'AND A.LOCATION_ID = C.LOCATION_ID AND B.OPERATION_TYPE = :OPERATION_TYPE ' ||
               'AND A.WAREHOUSE_ID = :TWHID ' || C_FLAG;
    ELSE
      C_SQL := 'SELECT MIN(LOCATION_NO), DATECODE ' ||
               'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B, SAJET.WMS_LOCATION C ' ||
               'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID AND INTERFACE_TYPE IN (''WORETURN'',''IN'') ' ||
               'AND A.LOCATION_ID = C.LOCATION_ID AND B.OPERATION_TYPE = :OPERATION_TYPE ' ||
               C_FLAG;
    END IF;

    IF TDATECODE IS NOT NULL THEN
      --指定DateCode
      C_SQL := C_SQL || 'AND DATECODE = :TDATECODE ' ||
               'GROUP BY DATECODE ';
      IF TWHID IS NOT NULL THEN
        EXECUTE IMMEDIATE C_SQL
          INTO STR, C_DATECODE
          USING TPARTID, TPARAM, TWHID, TDATECODE;
      ELSE
        EXECUTE IMMEDIATE C_SQL
          INTO STR, C_DATECODE
          USING TPARTID, TPARAM, TDATECODE;
      END IF;
    ELSE
      --先進先出
      IF TWHID IS NOT NULL THEN
        --如果指定仓库
        C_SQL := C_SQL ||
                 'AND DATECODE = (SELECT MIN(DATECODE) FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                 'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID AND B.OPERATION_TYPE = :OPERATION_TYPE ' ||
                 'AND A.WAREHOUSE_ID = :TWHID ' || C_FLAG ||
                 'AND (INTERFACE_TYPE = ''WORETURN'' OR INTERFACE_TYPE = ''IN''))  ' ||
                 'GROUP BY DATECODE ';
        EXECUTE IMMEDIATE C_SQL
          INTO STR, C_DATECODE
          USING TPARTID, TPARAM, TWHID, TPARTID, TPARAM, TWHID;
      ELSE
        C_SQL := C_SQL ||
                 'AND DATECODE = (SELECT MIN(DATECODE) FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                 'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID AND B.OPERATION_TYPE = :OPERATION_TYPE ' ||
                 C_FLAG ||
                 'AND (INTERFACE_TYPE = ''WORETURN'' OR INTERFACE_TYPE = ''IN''))  ' ||
                 'GROUP BY DATECODE ';

        EXECUTE IMMEDIATE C_SQL
          INTO STR, C_DATECODE
          USING TPARTID, TPARAM, TPARTID, TPARAM;
      END IF;
    END IF;
    SELECT LOCATION_ID
      INTO C_LOCATION
      FROM SAJET.WMS_LOCATION
     WHERE LOCATION_NO = STR; --STR 儲位 TPARAM 棧板
    RETURN STR || ',' || SAJET.Wms_Location_Qty(TPARTID,
                                                C_LOCATION,
                                                C_DATECODE,
                                                C_FLAG ||
                                                'AND INTERFACE_TYPE IN (''WORETURN'',''IN'')',
                                                TPARAM);
    --RETURN C_SQL;

    --都沒有工單退料或雜收時
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        IF TWHID IS NOT NULL THEN
          C_SQL := 'SELECT MIN(LOCATION_NO), DATECODE ' ||
                   'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B, SAJET.WMS_LOCATION C ' ||
                   'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' ||
                   'AND A.LOCATION_ID = C.LOCATION_ID AND B.OPERATION_TYPE = :OPERATION_TYPE ' ||
                   'AND A.WAREHOUSE_ID = :TWHID ' || C_FLAG;
        ELSE
          C_SQL := 'SELECT MIN(LOCATION_NO), DATECODE ' ||
                   'FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B, SAJET.WMS_LOCATION C ' ||
                   'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' ||
                   'AND A.LOCATION_ID = C.LOCATION_ID AND B.OPERATION_TYPE = :OPERATION_TYPE ' ||
                   C_FLAG;
        END IF;
        IF TDATECODE IS NOT NULL THEN
          --指定DateCode
          C_SQL := C_SQL || 'AND DATECODE = :TDATECODE ' ||
                   'GROUP BY DATECODE ';
          IF TWHID IS NOT NULL THEN
            EXECUTE IMMEDIATE C_SQL
              INTO STR, C_DATECODE
              USING TPARTID, TPARAM, TWHID, TDATECODE;
          ELSE
            EXECUTE IMMEDIATE C_SQL
              INTO STR, C_DATECODE
              USING TPARTID, TPARAM, TDATECODE;
          END IF;
        ELSE
          --先進先出
          IF TWHID IS NOT NULL THEN
            --如果指定仓库
            C_SQL := C_SQL ||
                     'AND DATECODE = (SELECT MIN(DATECODE) FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                     'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' ||
                     'AND B.OPERATION_TYPE = :OPERATION_TYPE ' ||
                     'AND A.WAREHOUSE_ID = :TWHID ' || C_FLAG || ') ' ||
                     'GROUP BY DATECODE ';
            EXECUTE IMMEDIATE C_SQL
              INTO STR, C_DATECODE
              USING TPARTID, TPARAM, TWHID, TPARTID, TPARAM, TWHID;
          ELSE
            C_SQL := C_SQL ||
                     'AND DATECODE = (SELECT MIN(DATECODE) FROM SAJET.WMS_STOCK A, SAJET.WMS_WAREHOUSE_OPERATION B ' ||
                     'WHERE PART_ID = :TPARTID AND A.WAREHOUSE_ID = B.WAREHOUSE_ID ' ||
                     'AND B.OPERATION_TYPE = :OPERATION_TYPE ' || C_FLAG || ') ' ||
                     'GROUP BY DATECODE ';
            EXECUTE IMMEDIATE C_SQL
              INTO STR, C_DATECODE
              USING TPARTID, TPARAM, TPARTID, TPARAM;
          END IF;
        END IF;
        SELECT LOCATION_ID
          INTO C_LOCATION
          FROM SAJET.WMS_LOCATION
         WHERE LOCATION_NO = STR;

         SELECT f.box_no into BOX_NO
           FROM SAJET.wms_STOCK f
          WHERE f.DATECODE = C_DATECODE
            and f.part_id = TPARTID
            and rownum = 1
          order by box_qty;
        RETURN STR ||  ','|| BOX_NO || ',' || SAJET.Wms_Location_Qty(TPARTID,
                                                    C_LOCATION,
                                                    C_DATECODE,
                                                    C_FLAG,
                                                    TPARAM); --抓出該儲位中該料號和DateCode的數量
        --RETURN STR;
      EXCEPTION
        WHEN OTHERS THEN
          RETURN ',';
      END;
  END;
END;


/

