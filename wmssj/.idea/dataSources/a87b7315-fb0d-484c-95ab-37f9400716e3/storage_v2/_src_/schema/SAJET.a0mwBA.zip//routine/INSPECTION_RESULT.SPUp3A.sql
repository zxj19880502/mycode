create function       
       Inspection_Result(svalue in varchar2) return varchar2 is
str varchar2(16); s number; i number;
begin
  if svalue = '0' then
    str := 'Pass';
  elsif svalue = '1' then
    str := 'Reject';
  elsif svalue = '2' then
    str := 'Waive';
  elsif svalue = '4' then
    str := 'By Pass';
  elsif svalue = '3' then
    str :='Sorting';
  elsif svalue = '6' then
    str :='Partial Waive';
  elsif svalue = '7' then
    str :='Sepcial Waive';
  elsif svalue = 'N/A' then
    str := 'N/A';
  else
    str := 'Unknown';
  end if;
  return str;
end;


/

