create procedure       csbg_chk_rbom_kp(tsn        in varchar2
												  ,tkpid      in varchar2
												  ,tprocessid number
												  ,tres       out varchar2) is
	c_partid number;
	cwo      varchar2(25);
	--clineid number; cstageid number; cprocessid number;
begin
	--sajet.sj_get_place(tterminalid,clineid,cstageid,cprocessid);
	select work_order into cwo from sajet.g_sn_status where serial_number = tsn;
	select part_id
	into   c_partid
	from   sajet.g_wo_bom
	where  work_order = cwo and item_part_id = tkpid and process_id = tprocessid and rownum = 1;
	tres := 'OK';
exception
	when others then
		tres := 'KP ERR';
end;


/

