create procedure       cs_update_next(psn        in varchar2
												,tprocessid in number
												,tres       out varchar2) is
begin
	update sajet.g_sn_status set next_process = tprocessid where serial_number = psn and rownum = 1;
	tres := 'OK';
end;


/

