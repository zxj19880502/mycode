create trigger T_ED_PRH
  before insert
  on ED_PRH
  for each row
DECLARE
  C_RTID        NUMBER;
  C_PARTID      NUMBER;
  C_COUNT       NUMBER;
  C_LOCATION    NUMBER;
  C_WAREHOUSE   NUMBER;
  C_VENDOR      NUMBER;
  C_VENDORPART  VARCHAR2(50);
  C_SAMPLEID    NUMBER;
  C_INCOMQTY NUMBER;
  C_QC_RESULT   VARCHAR2(5);
BEGIN
  --?取供?商
  BEGIN
    SELECT VENDOR_ID
      INTO C_VENDOR
      FROM SAJET.SYS_VENDOR
     WHERE VENDOR_CODE = :NEW.PRH_VENDER
       AND ROWNUM = 1;
  EXCEPTION
    WHEN OTHERS THEN
      :NEW.LOG := '供應商不存在';
      RETURN;
  END;
  --?取料?
  BEGIN
    SELECT PART_ID
      INTO C_PARTID
      FROM SAJET.SYS_PART
     WHERE PART_NO = :NEW.PRH_PART;
  EXCEPTION
    WHEN OTHERS THEN
      :NEW.LOG := '料號不存在';
      RETURN;
  END;
  BEGIN
    SELECT RT_ID
      INTO C_RTID
      FROM SAJET.G_ERP_RTNO
     WHERE RT_NO = :NEW.PRH_RTNO
       AND ROWNUM = 1;
  
    BEGIN
      --更新G_ERP_RTNO
      UPDATE SAJET.G_ERP_RTNO
         SET VENDOR_ID    = C_VENDOR,
             PO_NO        = :NEW.PRH_PO,
             RECEIVE_TIME = TO_DATE(:NEW.PRH_REC_DATE, 'yyyy/mm/dd'),
             UPDATE_TIME  = SYSDATE
       WHERE RT_ID = C_RTID;
      UPDATE SAJET.WMS_STORAGE
         SET PART_ID = C_PARTID, QTY = :NEW.PRH_QTY, UPDATE_TIME = SYSDATE
       WHERE REQUEST_ID = :NEW.PRH_RTNO;
    EXCEPTION
      WHEN OTHERS THEN
        :NEW.LOG := SQLERRM;
        RETURN;
    END;
  
  EXCEPTION
    WHEN OTHERS THEN
      SELECT DECODE(MAX(RT_ID), '', 10000001, MAX(RT_ID) + 1)
        INTO C_RTID
        FROM SAJET.G_ERP_RTNO;
    
      INSERT INTO SAJET.G_ERP_RTNO
        (RT_ID, RT_NO, VENDOR_ID, PO_NO, RECEIVE_TIME)
      VALUES
        (C_RTID,
         :NEW.PRH_RTNO,
         C_VENDOR,
         :NEW.PRH_PO,
         TO_DATE(:NEW.PRH_REC_DATE, 'yyyy/mm/dd'));
      INSERT INTO SAJET.WMS_STORAGE
        (REQUEST_ID, PART_ID, QTY,INTERFACE_TYPE, UPDATE_TIME)
      VALUES
        (:NEW.PRH_RTNO,
         C_PARTID,
         :NEW.PRH_QTY,
         'RTIN',
         TO_DATE(:NEW.PRH_REC_DATE, 'yyyy/mm/dd'));
  END;

  /*--?取??、?位ID
  SJ_GET_WAREHOUSE_LOCATION(:NEW.WH,
                            :NEW.LOCATION,
                            C_WAREHOUSE,
                            C_LOCATION,
                            :NEW.LOG);
  IF :NEW.LOG <> 'OK' THEN
    :NEW.LOG := '??不存在';
    GOTO ENDP;
  END IF;*/
  --更新G_ERP_RT_ITEM
/*  BEGIN
    SELECT VENDOR_PART_NO
      INTO C_VENDORPART
      FROM SAJET.SYS_VENDOR_PART
     WHERE VENDOR_ID = C_VENDOR
       AND PART_ID = C_PARTID;
  EXCEPTION
    WHEN OTHERS THEN
      :NEW.LOG := '供應商料號錯誤';
      RETURN;
  END;*/
  BEGIN
    SELECT A.INCOMING_QTY
      INTO C_INCOMQTY
      FROM SAJET.G_ERP_RT_ITEM A
     WHERE RT_ID = C_RTID
       AND A.PART_ID = C_PARTID;
  
    IF C_INCOMQTY > 0 THEN
      :NEW.LOG := '已有接收數據，無法修改';
      RETURN;
    END IF;
  
    BEGIN
      UPDATE SAJET.G_ERP_RT_ITEM
         SET TOTAL_QTY  = :NEW.PRH_QTY,
             UPDATE_TIME = TO_DATE(:NEW.PRH_REC_DATE, 'yyyy/mm/dd'),
             PO_NO         = :NEW.PRH_PO,
             PO_SEQ        = :NEW.PRH_POITEM
             --VENDOR_PARTNO = C_VENDORPART
       WHERE RT_ID = C_RTID
         AND PART_ID = C_PARTID;
    EXCEPTION
      WHEN OTHERS THEN
        :NEW.LOG := SQLERRM;
        RETURN;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      INSERT INTO SAJET.G_ERP_RT_ITEM
        (RT_ID,
         RT_SEQ,
         PART_ID,
         TOTAL_QTY,
         UPDATE_TIME,
         PO_NO,
         PO_SEQ,
         UPDATE_USERID,
         --VENDOR_PARTNO,
         LOT_NO)
      VALUES
        (C_RTID,
         '1',
         C_PARTID,
         :NEW.PRH_QTY,
         TO_DATE(:NEW.PRH_REC_DATE, 'yyyy/mm/dd'),
         :NEW.PRH_PO,
         :NEW.PRH_POITEM,
         '10000001',
         --C_VENDORPART,
         :NEW.PRH_RTNO||'-1');
         --INSERT INTO SAJET.WMS_STORAGE(REQUEST_ID,PART_ID,DATECODE,QTY,INTERFACE_TYPE,UPDATE_USERID)VALUES()
  END;

  /*IF :NEW.ENABLED = 'N' THEN
    GOTO ENDP;
  END IF;
  
  --?取抽???
  BEGIN
    SELECT SAMPLING_PLAN_ID
      INTO C_SAMPLEID
      FROM SAJET.G_IQC_SAMPLING_PLAN
     WHERE PART_ID = C_PARTID
       AND VENDOR_ID = C_VENDOR
       AND ROWNUM = 1;
  EXCEPTION
    WHEN OTHERS THEN
      C_SAMPLEID := '';
  END;
  
  --更新G_IQC_LOT
  BEGIN
    SELECT QC_RESULT
      INTO C_QC_RESULT
      FROM SAJET.G_IQC_LOT
     WHERE LOT_NO = :NEW.RT_NO || '-' || :NEW.RT_ITEM
       AND PART_ID = C_PARTID;
  
    UPDATE SAJET.G_IQC_LOT
       SET PART_ID     = C_PARTID,
           VENDOR_ID   = C_VENDOR,
           PO_NO       = :NEW.PO,
           RT_ID       = C_RTID,
           RT_SEQ      = :NEW.RT_ITEM,
           SAMPLING_ID = C_SAMPLEID,
           LOT_SIZE    = :NEW.QTY,
           INSP_DATE   = :NEW.RECEIVE_TIME
     WHERE LOT_NO = :NEW.RT_NO || '-' || :NEW.RT_ITEM;
  EXCEPTION
    WHEN OTHERS THEN
      INSERT INTO SAJET.G_IQC_LOT
        (LOT_NO,
         PART_ID,
         VENDOR_ID,
         PO_NO,
         RT_ID,
         RT_SEQ,
         SAMPLING_ID,
         LOT_SIZE,
         INSP_DATE)
      VALUES
        (:NEW.RT_NO || '-' || :NEW.RT_ITEM,
         C_PARTID,
         C_VENDOR,
         :NEW.PO,
         C_RTID,
         :NEW.RT_ITEM,
         C_SAMPLEID,
         :NEW.QTY,
         :NEW.RECEIVE_TIME);
  END;*/

  <<ENDP>>
  NULL;
EXCEPTION
  WHEN OTHERS THEN
    :NEW.LOG := SQLERRM;
END;


/

