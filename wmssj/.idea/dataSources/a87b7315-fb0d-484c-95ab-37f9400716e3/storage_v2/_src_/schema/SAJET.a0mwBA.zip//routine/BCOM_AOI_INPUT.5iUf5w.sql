create procedure bcom_aoi_input(tpdlineid   in varchar2
										  ,tstageid    in varchar2
										  ,tprocessid  in varchar2
										  ,tterminalid in varchar2
										  ,temp        in varchar2
										  ,tsajet1     in varchar2
										  , --COMMAND
										   tsajet2     in varchar2
										  , --SN or PANEL
										   tsajet3     in varchar2
										  ,tsajet4     in varchar2
										  , --USER
										   tsajet5     in varchar2
										  , --TYPE
										   tsajet6     in varchar2
										  , --TIME
										   tdefectdata in varchar2
										  ,tnow        in date
										  ,tres        out varchar2
										  ,ptype       out varchar2) is
	v_step       varchar2(10);
	cmd          number;
	v_sn         sajet.g_sn_status.serial_number%type;
	v_panel      sajet.g_sn_status.panel_no%type;
	v_defect     sajet.sys_defect.defect_code%type;
	v_defectid   number;
	v_loc        sajet.g_sn_defect.location%type;
	v_recid      sajet.g_sn_defect.recid%type;
	istart       number;
	iend         number;
	istart_1     number;
	iend_1       number;
	v_now        date;
	v_empid      number;
	v_count      number;
	v_wflag      varchar2(5);
	v_wo         sajet.g_sn_status.work_order%type;
	v_partid     sajet.g_sn_status.part_id%type;
	v_snqty      number;
	v_defectdata varchar2(4000);

	v_testtime_1 varchar2(30);
	v_result     varchar2(10);
	v_errorqty   number;
	v_errordata  varchar2(200);
	v_cycledata  varchar2(200);
	v_defectcode varchar2(40);
	v_rec_id     number;
	v_defect_id  number;
	v_model      varchar2(100);
	v_testtime   date;
	v_errpoint   number;
begin

	tres    := 'Command Fail';
	ptype   := 'N/A';
	cmd     := tsajet1;
	v_panel := tsajet2;
	v_sn    := tsajet2;

	v_now := tnow;
	sajet.sj_get_empid(temp, v_empid);
	if cmd = '01' then
		--检查序号的流程
		sajet.sj_ckrt_sn_psn(v_panel, tres, v_sn);
		if tres = 'OK' then
			select nvl(panel_no, 'N/A') into v_panel from sajet.g_sn_status where serial_number = v_sn and rownum = 1;
			if v_panel <> 'N/A' then
				tres := 'MUST INPUT PANEL';
				goto endp;
			end if;
			sajet.sj_ckrt_route(tterminalid, v_sn, tres);
			if tres <> 'OK' then
				goto endp;
			end if;
			ptype := 'SN';
			sajet.sj_panel_clear_sntemp(tterminalid, v_sn, tres);
		else
			sajet.sj_panel_ckrt_panel(tterminalid, v_panel, tres);
			if tres <> 'OK' then
				goto endp;
			end if;
			ptype := 'PANEL';
			sajet.sj_panel_clear_sntemp_1(tterminalid, v_panel, tres);
		end if;
	elsif cmd = '02' then
		tres := 'OK';
		if tsajet5 = 'SN' then
			v_panel := 'N/A';
		end if;
		v_defectdata := tsajet4;
		v_testtime   := v_now;
	
		if (v_defectdata is null) then
			v_defectdata := 'N/A';
		end if;
		if (v_defectdata <> 'N/A') then
			select mod(length(translate(v_defectdata, '@' || v_defectdata, '@')), 3) into v_count from dual;
		
			begin
				istart := 0;
				iend   := 0;
				loop
					istart := iend + 1;
					iend   := instr(v_defectdata, '@', istart, 1);
					exit when(iend = 0) or substr(tres, 1, 2) <> 'OK';
					v_sn         := substr(v_defectdata, istart, iend - istart);
					istart       := iend + 1;
					iend         := instr(v_defectdata, '@', istart, 1);
					v_defectcode := substr(v_defectdata, istart, iend - istart);
					istart       := iend + 1;
					iend         := instr(v_defectdata, '@', istart, 1);
				
					v_loc := substr(v_defectdata, istart, iend - istart);
					/* ISTART :=IEND+1; */
					/*IEND := INSTR(V_DEFECTDATA,'@',ISTART,1);*/
					/*V_ERRPOINT := SUBSTR(V_DEFECTDATA,ISTART ,IEND-ISTART);*/
				
					sajet.sj_get_defectid(v_defectcode, v_defect_id);
				
					if v_defect_id = 0 then
						tres := 'NG;NOT FOUNT DEFERECT CODE';
					
						goto endp;
					end if;
				
					begin
						select rpad(nvl(param_value, '1'), 2, '0') || to_char(v_now, 'YYMMDD') ||
								lpad(sajet.s_def_code.nextval, 5, '0')
						into   v_rec_id
						from   sajet.sys_base
						where  param_name = 'DBID';
						insert into sajet.g_sn_defect_temp
							(recid, defect_id, terminal_id, panel_no, serial_number, update_time, location, err_point)
						values
							(v_rec_id, v_defect_id, tterminalid, v_panel, v_sn, v_now, v_loc, v_errpoint);
						exit when(iend = 0) or substr(tres, 1, 2) <> 'OK';
						commit;
					
					exception
						when others then
							tres := 'SJ_PANEL_CKRT_DEFECT ERROR';
						
					end;
				end loop; --DEFECT
			
			exception
				when others then
					tres := 'GET DEFECT DATA ERROR' || sqlerrm || ',' || v_defectdata;
				
					goto endp;
			end;
		end if;
		/* IF (SUBSTR(TRES,1,2)='OK' AND TSAJET5='SN') THEN
        SAJET.S1_Transfer(TTERMINALID,V_SN, V_TESTTIME,TEMP,TRES,'N/A');
        END IF;*/
	
		if (substr(tres, 1, 2) = 'OK' and tsajet5 = 'PANEL') then
			sajet.sj_panel_go_aoi(tterminalid, v_panel, v_testtime, v_empid, tres);
		end if;
	end if;
	<<endp>>
	null;

	if substr(tres, 1, 2) = 'OK' then
		commit;
	else
		rollback;
		-- add dean 2015/9/12 IO 停
		-- sajet.wms_check_iostop(tterminalid, tpdlineid, temp);
	end if;
exception
	when others then
		tres := 'AOI_TEST ERROR - ' || v_step || ',' || sqlerrm;
		--add dean 2015/9/12 IO 停
		--sajet.wms_check_iostop(tterminalid, tpdlineid, temp);
		rollback;
end;


/

