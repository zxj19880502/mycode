create procedure       csbg_wo_output_qty(tprocessid in number
													,tsn        in varchar2
													,tqty       in number
													,tnow       in date
													,tempid     in varchar2
													,bflag      out boolean
													,tres       out varchar2) is
	cstartp    number;
	cinpdline  date;
	coutpdline date;
	cendp      number;
	cwo        varchar2(25);
	cstatus    varchar2(1);
	ctarget    number;
	coutput    number;
begin
	bflag := false;
	tres  := 'OK';
	select b.work_order, start_process_id, end_process_id, wo_status, target_qty, output_qty, in_pdline_time,
		   out_pdline_time
	into   cwo, cstartp, cendp, cstatus, ctarget, coutput, cinpdline, coutpdline
	from   sajet.g_wo_base a, sajet.g_sn_status b
	where  b.serial_number = tsn and a.work_order = b.work_order and rownum = 1;
	--是工單的最後一站
	if (cendp = tprocessid) /*and (coutpdline is null)*/
	 then
		bflag := true;
		if coutput + tqty >= ctarget then
			update sajet.g_sn_status set out_pdline_time = tnow where serial_number = tsn and rownum = 1;
			update sajet.g_wo_base
			set    output_qty = output_qty + tqty, wo_status = '6', wo_close_date = tnow, update_time = tnow,
				   update_userid = tempid
			where  work_order = cwo;
			insert into sajet.g_ht_wo_base
				select * from sajet.g_wo_base where work_order = cwo;
		else
			update sajet.g_wo_base set output_qty = output_qty + tqty where work_order = cwo;
		end if;
	end if;
exception
	when no_data_found then
		tres := 'OK';
	when others then
		tres := 'CSBG_WO_OUTPUT_QTY ERROR';
end;


/

