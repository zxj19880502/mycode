create procedure chk_input_time(trev       in varchar2
										  ,tlineid    in varchar2
										  ,tprocessid in varchar2
										  ,terminalid in varchar2
										  ,tempid     in varchar2
										  ,tres       out varchar2) is
	partid     number;
	limit_time number;
	outputtime date;
	c_wo       varchar2(25);
	c_count    number;


begin
	tres := 'OK';
	--CHECK SAJET.G_SN_DIP_HOLD
	begin
		select count(serial_number) into c_count from sajet.g_sn_dip_hold where serial_number = trev;
		if c_count > 0 then
			select count(serial_number)
			into   c_count
			from   sajet.g_sn_dip_hold
			where  serial_number = trev and status = 'HOLD';
			if c_count > 0 then
				tres := 'SN HOLD!';
			else
				tres := 'OK';
			end if;
		
		else
			--CHECK TIMEOUT
			begin
				--select part_id, out_process_time, work_order
				select part_id, in_pdline_time, work_order
				into   partid, outputtime, c_wo
				from   sajet.g_sn_travel
				where  serial_number = trev --and in_process_time is null 
					   and in_pdline_time is not null and rownum = 1
				order  by out_process_time;
				select nvl(option6, 0) into limit_time from sajet.sys_part where part_id = partid;
				if (sysdate - outputtime) * 24 * 60 < limit_time * 60 or limit_time = 0 then
					tres := 'OK';
					insert into sajet.g_sn_dip_hold
						(work_order, serial_number, input_time, over_time, status, update_time, pdline_id, process_id,
						 terminal_id, update_user_id)
						(select work_order, serial_number, out_process_time, (sysdate - out_process_time) * 24 * 60,
								'OK', sysdate, tlineid, tprocessid, terminalid, tempid
						 from   sajet.g_sn_travel
						 where  in_process_time is null and out_process_time is not null and serial_number = trev);
				else
					insert into sajet.g_sn_dip_hold
						(work_order, serial_number, input_time, over_time, status, update_time, pdline_id, process_id,
						 terminal_id, update_user_id)
						(select work_order, serial_number, out_process_time, (sysdate - out_process_time) * 24 * 60,
								'HOLD', sysdate, tlineid, tprocessid, terminalid, tempid
						 from   sajet.g_sn_travel
						 where  serial_number not in
								(select serial_number from sajet.g_sn_dip_hold where work_order = c_wo) and
								work_order = c_wo and in_process_time is null and out_process_time is not null and
								(sysdate - out_process_time) * 24 * 60 > limit_time * 60);
					tres := 'SN HOLD!';
				end if;
			
			end;
		end if;
	end;


exception
	when others then
		tres := 'HOLD SN ERROR!' || sqlerrm;
end;


/

