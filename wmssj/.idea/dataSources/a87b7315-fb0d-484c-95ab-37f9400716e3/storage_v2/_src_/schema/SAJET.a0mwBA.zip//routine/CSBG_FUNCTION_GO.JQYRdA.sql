create procedure       csbg_function_go(tterminalid in number
												  ,tsn         in varchar2
												  ,tnow        in date
												  ,temp        in varchar2
												  ,tdefect     in varchar2
												  ,tres        out varchar2
												  ,tnextproc   out varchar2) is
	icount  number;
	sdefect varchar2(100);
	istart  number;
	sdata   varchar2(100);
begin
	sdata := tdefect;
	if substr(sdata, length(sdata), 1) <> ';' then
		sdata := sdata || ';';
	end if;
	istart := 1;
	for icount in 1 .. length(sdata) loop
		if substr(sdata, icount, 1) = ';' then
			sdefect := substr(sdata, istart, icount - istart);
			if sdefect = '000' then
				sdefect := 'N/A';
			end if;
			istart := icount + 1;
			sajet.sj_transfer(tterminalid, tsn, sdefect, tnow, temp, tres, tnextproc);
		end if;
	end loop;
	tres := 'OK';
exception
	when others then
		tres := 'csbg_function_go error';
end;


/

