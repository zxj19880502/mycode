create view V_WO_PICK_INFO as
SELECT A1."PART_ID",A1."WORK_ORDER",A1."OLD_QTY",A1."QTY",A1."PICK_QTY",A1."UNPICK_QTY",A1."STATUS",A1."INTERFACE_TYPE",A1."ITEM_TYPE",A1."GROUP_ID",A1."DATECODE",A1."ROW_ID",A1."WAREHOUSE_ID", A2.PART_NO, A2.SPEC1, A3.WAREHOUSE_NO,A1.ORG_ID,A1.Wo_Status
  FROM (SELECT A.PART_ID,
               A.WORK_ORDER,
               A.QTY OLD_QTY,
               B.TARGET_QTY QTY,
               A.PICK_QTY,
               A.QTY - A.PICK_QTY UNPICK_QTY,
               A.STATUS,
               A.INTERFACE_TYPE,
               A.ITEM_TYPE,
               A.GROUP_ID,
               A.DATECODE,
               a.rowid row_id,
               A.WAREHOUSE_ID,B.ORG_ID,B.Wo_Status
          FROM (SELECT *
                  FROM SAJET.WMS_PICK_INFO
                 WHERE INTERFACE_TYPE = 'WO'
                   AND WORK_ORDER <> 'N/A'
                   AND (GROUP_ID = 'N/A' OR GROUP_ID IS NULL)) A,
               (SELECT D.WORK_ORDER,
                       D.TARGET_QTY CNT,
                      -- E.ITEM_PART_ID,
                     --  E.ITEM_COUNT,
                    --   E.ITEM_COUNT *
                    D.TARGET_QTY TARGET_QTY,
                    D.ORG_ID,D.wo_status
                  FROM SAJET.G_WO_BASE D
                  --, SAJET.G_WO_BOM E
                 WHERE --D.WORK_ORDER = E.WORK_ORDER AND
                 D.WO_STATUS<5) B
         WHERE A.WORK_ORDER = B.WORK_ORDER
           --AND A.PART_ID = B.ITEM_PART_ID
           ) A1,
       SAJET.SYS_PART A2,
       SAJET.WMS_WAREHOUSE A3
 WHERE A1.PART_ID = A2.PART_ID
   --AND A2.SEND_TYPE = '推式'
   AND A1.WAREHOUSE_ID = A3.WAREHOUSE_ID(+)
 ORDER BY A1.PICK_QTY, A2.PART_NO, A1.WORK_ORDER


/

