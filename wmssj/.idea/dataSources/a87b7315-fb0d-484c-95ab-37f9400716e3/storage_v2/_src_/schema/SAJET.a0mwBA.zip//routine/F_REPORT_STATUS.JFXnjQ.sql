create function f_report_status(sin_pdline_time  in date
										  ,sout_pdline_time in date
										  ,swork_falg       in varchar2) return varchar2 is

	cstatus varchar2(10);
begin
	cstatus := 'WIP';
	if sin_pdline_time is null then
		cstatus := 'RELEASE';
		goto endp;
	end if;
	if sout_pdline_time is not null then
		cstatus := 'OUTPUT';
		goto endp;
	end if;
	if swork_falg = '1' then
		cstatus := 'SCRAP';
		goto endp;
	end if;

	<<endp>>
	null;
	return cstatus;
exception
	when others then
		return '';
end;
/

