create view V_RC_SORTING as
select a.machine_code,
         a.insp_type,
         a.size_code,
         a.testnum,
         a.rc_no,
         a.serial_number,
         a.load_cassette,
         a.load_slot,
         a.load_seq,
         a.load_time,
         a.unload_cassette,
         a.unload_slot,
         a.unload_seq,
         a.unload_time,
         a.level_code,
         a.nbow,
         a.sori,
         a.ttv,
         a.ltv,
         a.thickness,
         a.tir,
         a.warp,
         a.tbow,
         a.get_order,
         c.part_no,
         d.work_order,
         A.FLAG
    from sajet.g_rc_sorting a, sajet.sys_part c, sajet.g_rc_status d
   where a.rc_no = d.rc_no
     and d.part_id = c.part_id
     and a.flag <> 'O'


/

