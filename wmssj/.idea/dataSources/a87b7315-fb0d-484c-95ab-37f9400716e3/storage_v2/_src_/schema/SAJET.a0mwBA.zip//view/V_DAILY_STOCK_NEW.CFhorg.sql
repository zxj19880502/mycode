create view V_DAILY_STOCK_NEW as
select query_date, a.sizespec, stock_qty, p.store_plan_number plan_stock,wo_type
  from (select query_date, sizespec, count(box_no) stock_qty,wo_type
          from (select distinct box_no,
                                to_char(t.update_time - 8.5 / 24, 'yyyymmdd') query_date,
                                substr(c.model_name, 4, 4) sizespec,
                                wo_type
                  from sajet.WMS_STOCK_TRACK t,
                       sajet.sys_part        b,
                       sajet.sys_model       c,
                       sajet.g_wo_base w
                 where interface_type = 'WOSTOCK'
                   and t.box_qty > 0
                   and t.part_id = b.part_id(+)
                   and b.model_id = c.model_id
                   and t.work_order=w.work_order)
         group by sizespec, query_date,wo_type) a,
       (select to_char(a.date_time, 'yyyymmdd') plan_date,
               a.store_plan_number,
               substr(c.model_name, 4, 4) sizespec
          from sajet.G_SCHEDULE_PLAN a, sajet.sys_part b, sajet.sys_model c
         where a.part_id = b.part_id
           and b.model_id = c.model_id) p
 where a.query_date = p.plan_date(+)
   and a.sizespec = p.sizespec(+)


/

