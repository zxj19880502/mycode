create trigger TG_G_PDDMDASHBOARD_SETTING
  before insert
  on G_PDDMDASHBOARD_SETTING
  for each row
declare
	-- local variables here
begin
	select seq_g_pddmdashboard_setting.nextval into :new.dashboard_id from dual;
end tg_g_pddmdashboard_setting;


/

