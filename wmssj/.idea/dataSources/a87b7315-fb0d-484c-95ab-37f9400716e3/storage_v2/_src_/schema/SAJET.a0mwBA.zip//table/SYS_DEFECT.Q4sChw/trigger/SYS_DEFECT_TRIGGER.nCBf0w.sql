create trigger SYS_DEFECT_TRIGGER
  after insert or update or delete
  on SYS_DEFECT
  for each row
declare
    ncount number;
begin
    if inserting then
        insert into sajet.g_tri_data
            (data_id, data_table, update_user, update_time)
        values
            (:new.defect_id, 'SAJET.SYS_DEFECT', :new.update_userid, sysdate);

    end if;

exception
    when others then
        insert into sajet.g_tri_log
            (table_name, param1, param2, param3, clog, row_id, update_time)
        values
            ('sajet.SYS_DEFECT', 'defect_id', :new.defect_id, null, 'SYS_DEFECT_trigger error', null, sysdate);

end;

/

