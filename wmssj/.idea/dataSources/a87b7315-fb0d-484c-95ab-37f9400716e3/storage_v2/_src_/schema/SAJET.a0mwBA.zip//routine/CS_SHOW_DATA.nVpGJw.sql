create procedure       cs_show_data(tlineid     in number
											  ,tstageid    in number
											  ,tprocessid  in number
											  ,tterminalid in number
											  ,tsn         in varchar2
											  ,tnow        in date
											  ,tres        out varchar2
											  ,temp        in varchar2
											  ,trev        in varchar2
											  ,tdefect     in varchar2) is
	cwo      varchar2(25);
	cmodelid number;
	ok       varchar2(25);
	tempid   number;
begin
	tres := trev;
	--   select b.work_order,b.model_id
	--      into cwo,cmodelid
	--         from sajet.g_sn_status b
	--            where b.serial_number = tsn and rownum = 1;
	--   sajet.SJ_CHK_WO_INPUT(cwo, OK);
	--   if OK <> 'OK' then
	--      tres := OK;
	--   else
	--     sajet.sj_get_empid(temp,tempid);
	--     sajet.sj_wo_input_qty(tlineid,tstageid,tprocessid,tterminalid,tsn,tnow,tres,tempid);
	--     if tdefect = 'N/A' then
	--        sajet.sj_wo_output_qty(tlineid,tstageid,tprocessid,tterminalid,tsn,tnow,tres,tempid);
	--     end if;
	--     sajet.sj_update_sn(tlineid,tstageid,tprocessid,tterminalid,tsn,tdefect,tnow,tres,tempid,cwo,cmodelid);
	--     sajet.sj_transation_count(tlineid,tstageid,tprocessid,tempid,tnow,tsn,cwo,cmodelid,tres,0);
	--   end if;
exception
	when others then
		tres := 'cs_transfer error';
end;


/

