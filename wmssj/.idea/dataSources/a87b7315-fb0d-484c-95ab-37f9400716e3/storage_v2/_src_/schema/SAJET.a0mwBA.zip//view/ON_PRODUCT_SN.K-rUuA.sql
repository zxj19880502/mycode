create view ON_PRODUCT_SN as
  select b.work_order,b.rc_no serial_number,b.part_id,'200001'process_id,'成型待投' process_name,c.part_no,d.route_name,b.out_process_time
  from sajet.g_rc_status b,sajet.sys_part c,sajet.sys_rc_route d
 where b.process_id = 100011 and b.current_status !='1'
   and b.out_process_time is not null and b.next_process=0 and b.part_id=c.part_id(+) and b.route_id=d.route_id
   and b.rc_no in (select distinct t.rc_no
                     from sajet.g_rc_status t
                    where t.process_id = 100011
                   minus
                   select a.sn
                     from sajet.g_transfer_wo_log a
                    where a.process_id in( 100011,100033))
   union
--成品前
   select b.work_order,b.serial_number,b.part_id,'200002' process_id,'成品前待投' process_name,c.part_no,d.route_name,b.out_process_time
  from sajet.g_sn_status b,sajet.sys_part c,sajet.sys_rc_route d
 where b.process_id = 100031 and b.current_status !='1'
   and b.out_process_time is not null and b.next_process=0 and b.part_id=c.part_id(+) and b.route_id=d.route_id
   and b.serial_number in (select distinct t.serial_number
                     from sajet.g_sn_status t
                    where t.process_id = 100031
                   minus
                   select a.sn
                     from sajet.g_transfer_wo_log a
                    where a.process_id = 100034)
    union
--成品后
 select b.work_order,b.serial_number,b.part_id,'200003' process_id,'成品后待投' process_name,c.part_no,d.route_name,b.out_process_time
  from sajet.g_sn_status b,sajet.sys_part c,sajet.sys_rc_route d
 where b.process_id = 100020 and b.current_status!='1'
   and b.out_process_time is not null and b.next_process=0 and b.part_id=c.part_id and b.route_id=d.route_id
   and b.serial_number in (select distinct t.serial_number
                     from sajet.g_sn_status t
                    where t.process_id = 100020
                   minus
                   select a.sn
                     from sajet.g_transfer_wo_log a
                    where a.process_id in(100022,100023))
   union
 ---已投入工单，但没有投入工序：待投入水浴、待投烘干、待投包装或喷涂、客返待投返厂检
   select t.work_order,
         t.serial_number,
         t.part_id,
         decode(a.route_desc,
                '成型段','100012',
                '成品前段','100018',
                '成品后段喷','100022',
                '成品后段包','100024',
                '客返厂段','100036',
                'v') process_id,
          decode(a.route_desc,
                '成型段','水浴',
                '成品前段','烘干',
                '成品后段喷','喷涂',
                '成品后段包','包装',
                '客返厂段','返厂检',
                'vname') process_name,
         b.part_no,
         a.route_name,t.update_time out_process_time
    from sajet.g_sn_status t, sajet.sys_rc_route a, sajet.sys_part b
   where t.process_id = '0'
     and t.route_id = a.route_id
     and t.part_id = b.part_id
    union all
----各工序在制品
   select S.WORK_ORDER,s.serial_number,B.PART_ID,to_char(P.PROCESS_ID) process_id,P.PROCESS_NAME,
               B.PART_NO, e.route_name,s.wip_in_time out_process_time
          FROM SAJET.G_SN_STATUS  S,
               sajet.sys_rc_route e,
               sajet.sys_part     b,
               sajet.g_wo_base    C,
               sajet.SYS_PROCESS  P
         WHERE S.PART_ID = B.PART_ID
           AND S.PROCESS_ID = P.PROCESS_ID
           AND S.ROUTE_ID = E.ROUTE_ID
           and S.WORK_ORDER = C.WORK_ORDER
           and c.WO_OPTION2 in ('2', '3')
           AND S.IN_PROCESS_TIME is not null
           AND S.OUT_PROCESS_TIME is null --'待产出'
       /*  GROUP BY S.WORK_ORDER,
                  B.PART_NO,
                  e.route_name,
                  P.PROCESS_NAME,
                  B.PART_ID,
                  P.PROCESS_ID*/
        union all
        select S.WORK_ORDER,s.serial_number,B.PART_ID,to_char(P.PROCESS_ID) process_id,P.PROCESS_NAME,
               B.PART_NO,
               e.route_name,s.out_process_time
          FROM SAJET.G_SN_STATUS  S,
               sajet.sys_rc_route e,
               sajet.sys_part     b,
               sajet.g_wo_base    C,
               sajet.SYS_PROCESS  P
         WHERE S.PART_ID = B.PART_ID
           AND S.NEXT_PROCESS = P.PROCESS_ID
           AND S.ROUTE_ID = E.ROUTE_ID
           and S.WORK_ORDER = C.WORK_ORDER
           and c.WO_OPTION2 in ('2', '3')
           and S.CURRENT_STATUS != 1 --没有报废
           and s.current_status !='4'--没有返工
           AND S.IN_PROCESS_TIME is not null
           AND S.OUT_PROCESS_TIME is NOT null

           union all
   ----半检、终检，oqc检 判返工
         select t.work_order,
                t.serial_number,
                t.part_id,
                to_char(t.process_id) process_id,
                c.process_name,
                a.part_no,
                b.route_name,
                t.out_process_time
           from sajet.g_sn_status  t,
                sajet.sys_part     a,
                sajet.sys_rc_route b,
                sajet.sys_process  c
          where t.current_status = '4'
            and t.part_id = a.part_id
            and a.route_id = b.route_id
            and t.process_id = c.process_id and t.process_id in(100031,100026,100029)
          union all
---出库未投工单
select d.work_order,
       a.serial_number,
       a.part_id,
       '200004' process_id,
       '仓库出库待投' process_name,
       b.part_no,
       c.route_name,
       a.out_process_time
  from sajet.g_sn_status a,
       sajet.sys_part b,
       sajet.sys_rc_route c,
       (select t.work_order,
               t.material_no,
               row_number() over(partition by t.material_no order by t.update_time desc) rank
          from sajet.wms_pick_list t, sajet.sys_part a
         where t.part_id = a.part_id
           and a.part_type = '成品') d
 where a.serial_number in (select t.material_no
                             from sajet.wms_pick_list t, sajet.sys_part a
                            where t.part_id = a.part_id
                              and a.part_type = '成品'  minus
                              select serial_number from sajet.g_shipping_sn)
   and a.process_id = 100024
   and a.next_process = '0'
   AND SAJET.Wait_input_wms_to_product(a.serial_number) = 'Y'
   and a.part_id = b.part_id
   and a.route_id = c.route_id
   and d.rank = 1
   and a.serial_number = d.material_no(+)

union all
----包装后未入库
select WORK_ORDER,
       SERIAL_NUMBER,
       PART_ID,
      TO_CHAR(PROCESS_ID) PROCESS_ID,
       PROCESS_NAME,
       PART_NO,
       ROUTE_NAME,
       OUT_PROCESS_TIME from sajet.g_temptab_pack t where t.flag='Y'


/

