create view V_WO_PART_PROPERTY as
select a.work_order,
       A.PART_ID,
       b.property_id,
       c.property_name,
       B.property_value,
       b.property_value default_value,
       b.inherit_rc,
       b.inherit_sn,
       c.value_type,
       c.input_type,
       c.value_list,
       c.necessary,
       c.convert_type,
       b.seq
  from sajet.g_wo_base a, sajet.sys_part_property b, sajet.sys_property c
 where a.part_id = b.part_id
   and b.property_id = c.property_id
   and b.enabled = 'Y'


/

