create function f_get_machine_1(svalue in varchar2) return varchar2 is
	v_machine varchar2(50);
begin
	select machine_code into v_machine from sajet.sys_machine where machine_id = svalue;

	return v_machine;
exception
	when others then
		return 'error';
end;


/

