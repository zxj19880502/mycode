create view V_SN_WIP_PROPERTY as
select a1."RC_NO",a1."SERIAL_NUMBER",a1."PROPERTY_ID",a1."PROPERTY_VALUE",a1."SEQ",
       a2.property_name, a2.value_type, a2.input_type, a2.value_list, a1.work_order, a1.part_id
  from (select b.rc_no,
               b.serial_number,
               b.part_id,
               a.property_id,
               a.property_value,
               a.seq,
               b.work_order
          from sajet.g_sn_property     a,
               sajet.g_sn_status       b
         where a.serial_number = b.serial_number) a1,
       sajet.sys_property a2
 where a1.property_id = a2.property_id


/

