create function       cus_getspc(trev in varchar2) return nvarchar2 is
	sdate nvarchar2(32767);
	tres  nvarchar2(32767);
begin
	select spc_id
	into   sdate
	from   (select to_char(wm_concat(z.spc_id)) spc_id
			 from   sys_part x, cus_zd_spc_setting y, sys_spc z
			 where  y.spc_id = z.spc_id and x.part_no = "TREV" and x.part_id = y.part_id);
	tres := 'SELECT n.*,m.* FROM (select y.part_id,z.spc_item,z.spc_id from sys_part x,cus_zd_spc_setting y,sys_spc z
  where y.spc_id=z.spc_id and x.part_no=''' || trev ||
			''' and x.part_id=y.part_id) pivot (max(spc_item) for spc_id in (' || sdate ||
			')) m
   left join cus_zd_tmp_log a on to_char(m.part_id)=a.serial_number,
  (select to_char(wm_concat(z.spc_id)) spc_id from sys_part x,cus_zd_spc_setting y,sys_spc z
  where y.spc_id=z.spc_id and x.part_id=y.part_id and x.part_no=''' || trev ||
			''') n where a.serial_number is null';
	return tres;
end cus_getspc;


/

