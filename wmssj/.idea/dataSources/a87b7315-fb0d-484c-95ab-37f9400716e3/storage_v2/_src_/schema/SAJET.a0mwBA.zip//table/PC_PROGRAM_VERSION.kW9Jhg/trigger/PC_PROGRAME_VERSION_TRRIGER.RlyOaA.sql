create trigger PC_PROGRAME_VERSION_TRRIGER
  after insert
  on PC_PROGRAM_VERSION
  for each row
declare
	-- local variables here
	cspc_time date;
begin
	--1分钟之前
	update sajet.sys_spc t
	set    t.program = :new.upload_name,
		   t.version = :new.version_1 || '.' || :new.version_2 || '.' || :new.version_3 || '.' || :new.version_4
	where  t.program is null and t.update_time between :new.update_time - 2 / 1440 and :new.update_time;
end;


/

