create FUNCTION       convertstr(sStr in varchar2, sConn in varchar2, sData out varchar2) return varchar2 is
str varchar2(255); s varchar2(255); i number;
begin
  s := substr(sStr,1,instr(sStr,sConn,1)-1);
  sData := substr(sStr,instr(sStr,sConn,1) + 1, length(sStr));
  if (s = '') or (s is null) then
    s := sData;
  end if;
  return s;
end;


/

