create function REWOER_PERCENT_BJ_ZJ(Sdate in varchar2) return varchar2 is
  Result varchar2(10);
   x_count number;
  y_count number;
begin
   x_count := 0;
  y_count := 0;
  result:='0';
  select count(t.SERIAL_NUMBER)
    into x_count
    from sajet.v_sn_travel_simple t
   where t.PROCESS_ID in('100026','100031')
     and t.output_date = Sdate
     and t.CURRENT_STATUS = '4';
     
   if x_count=0 then 
     Result:='0';
   ELSE
     select count(t.SERIAL_NUMBER)
    into y_count
    from sajet.v_sn_travel_simple t
   where t.PROCESS_ID in ('100026','100031')
     and t.output_date = Sdate; 
   Result:=to_char(round((x_count/y_count)*100,2))||'%';
   end if;
  return(Result);
end REWOER_PERCENT_BJ_ZJ;


/

