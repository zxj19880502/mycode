create procedure command_code_smt(tlineid     in number
											,tstageid    in number
											,tprocessid  in number
											,tterminalid in number
											,tnow        in date
											,trev        in varchar2
											,tres        out varchar2
											,tnextproc   out varchar2) is
	tsajet1      varchar2(25);
	tsajet2      varchar2(40);
	tsajet3      varchar2(256);
	tsajet4      varchar2(256);
	tsajet4ton   varchar2(4096);
	tsajet5ton   varchar2(4096);
	c_buffer     varchar2(4096);
	c_head       number;
	cmd          number;
	c_number     number;
	c_start      number;
	c_end        number;
	c_psn        varchar2(35);
	c_temp       varchar2(255);
	c_item       sajet.sys_spc.spc_item%type;
	c_value      sajet.g_spc.spc_value%type;
	c_defect     sajet.sys_defect.defect_code%type;
	c_wo         sajet.g_sn_status.work_order%type;
	c_wo_seq     smt.g_wo_msl.wo_sequence%type;
	c_datecode   smt.g_smt_status.datecode%type;
	c_dbid       varchar2(20);
	c_type       number;
	c_eventid    number;
	t_type       varchar2(25);
	check_status varchar2(10);
	msl_status   varchar2(30);
	c_factory    number;
	cnt          number;
	cvalue       number;
	psn          varchar2(64);
	c_mac        varchar2(24);
	cempid       number;

begin
	tres := 'Fail,Command fail';
	/*   IF SUBSTR(TREV, LENGTH(TREV), 1) = ';' THEN
       c_Buffer := TREV;
    ELSE
       c_Buffer := TREV || ';';
    END IF;

    c_Number := 1;
    c_Start := 1;
    c_End := INSTR (c_Buffer, ';', c_Start, c_Number);

    IF C_End <= 3 THEN
    BEGIN
       cmd := SUBSTR(c_Buffer, c_Start, C_End-c_Start);
       c_Number := c_Number + 1;
       c_Start := c_End + 1;
    EXCEPTION
       WHEN OTHERS THEN
          cmd := 999;
    END;
    ELSE
       cmd := 999;
    END IF;*/
	select count(*) into cnt from table(f_cus_split(trev, ';'));

	begin
		cmd := to_number(trim(f_cus_splitstr(trev, 1, ';'))); --獲取cmd
	exception
		when others then
			tres := 'NG;CMD ERR!' || ' ' || trev;
			return;
	end;

	if cmd = 1 --檢查用戶
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![EMP]' || trev || '[' || cnt || ']';
		else

			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));

			sajet.sj_cksys_emp(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				tres := 'OK;' || tres;
			end if;
		end if;
	elsif cmd = 2 --檢查SN
	 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![SN]';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			--SAJET.SJ_CKRT_SN(tsajet2,TRES);
			sajet.sj_ckrt_sn_psn(tsajet2, tres, c_psn);
			if tres = 'OK' then
				sajet.sj_ckrt_route(tterminalid, c_psn, tres);

				if substr(tres, 1, 2) = 'OK' then
					tres := 'OK;' || tres;
				end if;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 17 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![EMP;PWD]' || trev || '[' || cnt || ']';
		else

			tsajet2 := trim(f_cus_splitstr(trev, 2, ';'));
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';'));

			sajet.sj_cksys_emp(tsajet2, tres);
			/*       if substr(tres,1,2)='OK' then
              tres:='OK;'||tres;
            end if;*/
			if tres = 'OK' then
				begin
					select trim(sajet.password.decrypt(passwd)) into c_temp from sajet.sys_emp where emp_no = tsajet2;
					if c_temp <> tsajet3 then
						tres := 'NG;密碼錯誤!';
					else
						tres := 'OK;OK;';
					end if;
				exception
					when others then
						tres := 'NG;密碼錯誤';
				end;
			else
				tres := tres || ' [' || tsajet2 || ']';
			end if;
		end if;
	elsif cmd = 18 then
		if cnt < 2 then
			tres := 'NG;格式錯誤![WO]' || trev || '[' || cnt || ']';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --WO
			hipro_wo_input_chk_wo2(tsajet2, tres);
			if tres = 'OK' then
				tres := 'OK;OK';
			end if;
		end if;
	elsif cmd = 19 then
		if cnt < 4 then
			tres := 'NG;格式錯誤![WO;EMP;SN]' || trev || '[' || cnt || ']';
		else
			tsajet2 := trim(f_cus_splitstr(trev, 2, ';')); --WO
			tsajet3 := trim(f_cus_splitstr(trev, 3, ';')); --EMP
			tsajet4 := trim(f_cus_splitstr(trev, 4, ';')); --SN
			hipro_wo_input_chk_wo2(tsajet2, tres);
			if substr(tres, 1, 2) = 'OK' then
				sajet.cus_input2_map_material(tterminalid, tsajet4, tsajet2, tlineid, tprocessid, tsajet3, tnow, tres,
											  c_temp);
				if tres = 'OK' then
					select output_qty, target_qty
					into   cnt, cvalue
					from   sajet.g_wo_base
					where  work_order = substr(tsajet2, 3, length(tsajet2) - 2);
					tres := 'OK;[' || cnt || '/' || cvalue || ']';
					--TRES:='OK;OK';
				end if;
			end if;
		end if;
	else
		tres := 'NG;[EC102] COMMAND NOT DEFINE.;';
	end if;

	if substr(tres, 1, 2) = 'OK' and length(tres) < 5 then
		tres := 'OK;' || tres;
	end if;
	--tres:=f_cus_formatStr(tres,length(trev),' ','N');
exception
	when others then
		tres := trev || '[' || sqlerrm || ']';
end;
/

