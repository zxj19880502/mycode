create trigger TG_CUS_MAC_VENDOR
  before insert
  on CUS_MAC_VENDOR
  for each row
declare
	-- local variables here
begin
	select sys_guid() into :new.keyid from dual;
end tg_cus_mac_vendor;


/

