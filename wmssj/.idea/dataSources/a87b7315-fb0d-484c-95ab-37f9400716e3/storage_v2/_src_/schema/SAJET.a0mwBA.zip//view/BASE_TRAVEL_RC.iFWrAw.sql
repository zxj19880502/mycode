create view BASE_TRAVEL_RC as
select t.rc_no,
       case
         when t.in_process_time <
              to_date(to_char(in_process_time, 'yyyy-mm-dd ') || '8:30:00',
                      'yyyy-mm-dd hh24:mi:ss') then
          to_date(TO_CHAR(t.in_process_time, 'yyyy-mm-dd'), 'yyyy-mm-dd') - 1
         else
          to_date(TO_CHAR(t.in_process_time, 'yyyy-mm-dd'), 'yyyy-mm-dd')
       end riqi,
       case
         when to_date(to_char(in_process_time, 'hh24:mi:ss '), 'hh24:mi:ss') <
              to_date(to_char(in_process_time, 'hh24') || ' 30:00',
                      'hh24:mi:ss') then
          DECODE(to_number(to_char(in_process_time, 'hh24')) - 1,
                 '-1',
                 '23',
                 to_char(abs(to_number(to_char(in_process_time, 'hh24')) - 1),
                         'FM09')) || ':30 - ' ||
          to_char(in_process_time, 'hh24') || ':30'
         else
          to_char(in_process_time, 'hh24') || ':30 - ' ||
          DECODE(to_number(to_char(in_process_time, 'hh24')) + 1,
                 '24',
                 '00',
                 to_char(abs(to_number(to_char(in_process_time, 'hh24')) + 1),
                         'FM09')) || ':30'
       end shiduan,
       c.die_option1,
       a.process_name,
       t.in_process_time out_process_time,t.in_process_shift,t.process_id,t.current_status
  from sajet.g_rc_travel     t,
       sajet.sys_process     a,
       sajet.g_rc_travel_die b,
       sajet.sys_die         c
 where t.process_id = 100011
   and t.process_id = a.process_id
   and t.rc_no = b.rc_no
   and b.die_code = c.die_no


/

