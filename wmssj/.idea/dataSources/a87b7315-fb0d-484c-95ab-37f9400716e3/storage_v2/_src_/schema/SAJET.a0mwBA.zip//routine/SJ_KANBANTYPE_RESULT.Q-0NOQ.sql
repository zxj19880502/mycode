create function       
       SJ_KANBANType_Result(svalue in varchar2) return varchar2 is
str varchar2(16); s number; i number;
begin
  if svalue = '0' then
    str := '生产';
  elsif svalue = '1' then
    str := '保养';
  elsif svalue = '2' then
    str := '休息';
  else
    str := 'N/A';
  end if;

  return str;
end;


/

