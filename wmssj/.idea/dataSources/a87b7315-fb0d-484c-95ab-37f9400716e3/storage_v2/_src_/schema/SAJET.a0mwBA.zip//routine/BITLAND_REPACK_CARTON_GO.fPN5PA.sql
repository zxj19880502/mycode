create PROCEDURE       BITLAND_REPACK_CARTON_GO(TPACKACTION in varchar2,TREV in varchar2,TCARTON in varchar2,TEMPNO in varchar2,TRES out varchar2)IS
empid number;
psn varchar2(80);
oldcarton sajet.g_repacking_sn.carton_no%type;
BEGIN
  TRES:='OK';
  if TREV is null then
    TRES:='SN IS NULL';
    return ;
    elsif TPACKACTION is null then
    TRES:='PACK ACTION IS NULL';
    return;
  elsif TCARTON is null then
      TRES:='CARTON NO IS NULL';
      return;
  elsif TEMPNO is  null then
    TRES:='Emp no is null';
    return;
  end if;
  sajet.Sj_Get_Empid(TEMPNO,empid);
  if empid=0 then
    TRES:='No this EMP No('||TEMPNO||')';
    return;
  end if;
  --sajet.sj_ckrt_sn_psn(TREV,TRES,psn);--？？sn？？？？
  if TPACKACTION='SN->CARTON' then
     begin
          select rs.carton_no into oldcarton from sajet.g_repacking_sn rs where rs.repack_type='REPACK_CARTON' and rs.serial_number=TREV;--找原来的记录
          update sajet.g_repacking_sn rs set rs.carton_no=TCARTON,rs.update_userid=empid,rs.update_time=sysdate where rs.serial_number=TREV;--更新重包记录
          insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
          values('REPACK_CARTON','N/A',oldcarton,'N/A','N/A',TCARTON,'N/A',TREV,empid,sysdate);--插入历史记录
          update sajet.g_sn_status ss set ss.carton_no=TCARTON where ss.serial_number=TREV;--更新箱号
          commit;
     exception
          when NO_DATA_FOUND then--之前没有重包过
               begin
                   insert into sajet.g_repacking_sn(repack_type,serial_number,pallet_no,carton_no,box_no,update_userid,update_time)
                   values('REPACK_CARTON',TREV,'N/A',TCARTON,'N/A',empid,sysdate);--插一笔新纪录
                   insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
                   values('REPACK_CARTON','N/A','N/A','N/A','N/A',TCARTON,'N/A',TREV,empid,sysdate);--插入历史记录
                   update sajet.g_sn_status ss set ss.carton_no=TCARTON where ss.serial_number=TREV;--更新箱号
                   commit;
               exception
                 when others then
                   TRES:=Sqlerrm;
                   rollback;
                   return;
               end;
           when others then
                 TRES:=sqlerrm;
                 rollback;
                 return;
      end;
      elsif TPACKACTION='BOX->CARTON' then
       begin
          select rs.carton_no into oldcarton from sajet.g_repacking_sn rs where rs.repack_type='REPACK_CARTON' and rs.box_no=TREV;--找原来的记录
          update sajet.g_repacking_sn rs set rs.carton_no=TCARTON,rs.update_userid=empid,rs.update_time=sysdate where rs.box_no=TREV;--更新重包记录
          insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
          values('REPACK_CARTON','N/A',oldcarton,'N/A','N/A',TCARTON,TREV,'N/A',empid,sysdate);--插入历史记录
          update sajet.g_sn_status ss set ss.carton_no=TCARTON where ss.box_no=TREV;--更新箱号
          commit;
     exception
          when NO_DATA_FOUND then--之前没有重包过
               begin
                   insert into sajet.g_repacking_sn(repack_type,serial_number,pallet_no,carton_no,box_no,update_userid,update_time)
                   values('REPACK_CARTON','N/A','N/A',TCARTON,TREV,empid,sysdate);--插一笔新纪录
                   insert into sajet.g_repacking_log(repack_type,old_pallet_no,old_carton_no,old_box_no,new_pallet_no,new_carton_no,new_box_no,serial_number,update_userid,update_time)
                   values('REPACK_CARTON','N/A','N/A','N/A','N/A',TCARTON,TREV,'N/A',empid,sysdate);--插入历史记录
                   update sajet.g_sn_status ss set ss.carton_no=TCARTON where ss.box_no=TREV;--更新箱号
                   commit;
               exception
                 when others then
                   TRES:=Sqlerrm;
                   rollback;
                   return;
               end;
           when others then
                 TRES:=sqlerrm;
                 rollback;
                 return;
      end;
      end if;
exception
  WHEN OTHERS THEN
  TRES:=SQLERRM;
  rollback;
end;


/

