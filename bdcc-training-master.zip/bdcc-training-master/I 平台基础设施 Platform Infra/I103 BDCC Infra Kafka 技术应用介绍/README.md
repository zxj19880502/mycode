---
title: 《I103 BDCC Infra Kafka 技术应用介绍》
---

# Big Data Cloud Center Training BDCC 培训课程

![](../images/BDC.jpg) ![](../../封面前言和封底%20Cover%20Preface/resource/M-64.png)

## 课程题目：I103 BDCC Infra Kafka 技术应用介绍

| 课程编号 | 分类         | 等级     | 版本 | 更新日期 |
| :------- | :----------- | :------- | :--- | :------- |
| I103     | 平台基础设施 | 入门级别 | 1.0  | TODO:    |

### 课程受众与目标

- **IT 运维人员**，TODO:
- **大数据方案工程师**，TODO:

### 课程在 BDCC 架构中的映射

![](../../封面前言和封底%20Cover%20Preface/resource/BDCC-traning-infra1.png)

[Toc]

# 课程内容

## 概览

### 详细内容

# 课后内容

### 课后问题

1. 请简述，TODO:

### 讲师联系方式

- 姓名：TODO:
- 邮箱：TODO:
